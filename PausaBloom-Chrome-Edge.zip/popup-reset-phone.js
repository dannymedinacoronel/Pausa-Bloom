// Restablecer datos y conexión del móvil con Telegram.
// ---------- Restablecer ----------

const RESET_MESSAGES = {
  today: "Descansos de hoy reiniciados",
  schedules: "Horarios y rutinas restablecidos",
  settings: "Ajustes restablecidos",
  history: "Historial borrado",
  all: "Todo borrado: la extensión está como nueva"
};

async function runReset(kind) {
  const before = snapshot();
  // "Todo" también borra el tutorial visto, el orden de las frases, etc.: se guarda una copia completa.
  const fullBackup = kind === "all" ? await chrome.storage.local.get(null) : null;

  if (kind === "today") {
    const today = todayKey();
    state.records = state.records.filter((record) => record.day !== today);
    if (state.activeTimer && !state.records.some((record) => record.id === state.activeTimer.recordId)) state.activeTimer = null;
    state.returnQuote = null;
    await persist(["records", "activeTimer", "returnQuote"]);
  } else if (kind === "schedules") {
    Object.assign(state.settings, {
      profiles: [Core.mergeProfile(Core.DEFAULT_PROFILE)],
      defaultProfile: Core.DEFAULT_PROFILE.id,
      weekProfiles: {}
    });
    editingProfileId = Core.DEFAULT_PROFILE.id;
    await persist(["settings"]);
  } else if (kind === "settings") {
    state.settings = Core.mergeSettings({ telegram: state.settings.telegram });
    await persist(["settings"]);
  } else if (kind === "history") {
    Object.assign(state, { records: [], activeTimer: null, daysOff: [], returnQuote: null });
    await persist(["records", "activeTimer", "daysOff", "returnQuote"]);
  } else if (kind === "all") {
    Object.assign(state, { settings: Core.mergeSettings(), records: [], activeTimer: null, daysOff: [], returnQuote: null });
    await chrome.storage.local.clear();
    await persist(["settings"]);
  }

  closeRecordForm();
  renderSettings();
  render();
  const undo = fullBackup
    ? async () => {
      await chrome.storage.local.clear();
      await chrome.storage.local.set(fullBackup);
      await restoreSnapshot(before);
    }
    : () => restoreSnapshot(before);
  showToast(RESET_MESSAGES[kind], undo);
}

function handleResetClick(button) {
  // Las acciones que borran datos piden un segundo clic.
  if (button.dataset.confirm && !button.classList.contains("is-confirming")) {
    const label = button.textContent;
    button.classList.add("is-confirming");
    button.textContent = "¿Seguro?";
    setTimeout(() => {
      button.classList.remove("is-confirming");
      button.textContent = label;
    }, 3500);
    return;
  }
  if (button.classList.contains("is-confirming")) {
    button.classList.remove("is-confirming");
    button.textContent = button.dataset.reset === "all" ? "Borrar todo" : "Borrar";
  }
  runReset(button.dataset.reset);
}

// ---------- Móvil (Telegram) ----------

let linkPoll = null;
let checkingLink = false;

function renderPhone() {
  const telegram = state.settings.telegram;
  const linked = PausaTelegram.isLinked(telegram);
  const waiting = Boolean(telegram.token && telegram.botUsername && !linked);
  $("#phone-setup").hidden = linked || waiting;
  $("#phone-link").hidden = !waiting;
  $("#phone-ready").hidden = !linked;

  const botfatherQr = $("#botfather-qr");
  if (!linked && !waiting && !botfatherQr.firstChild) botfatherQr.append(PausaQR.toSvg("https://t.me/BotFather"));

  if (waiting) {
    const url = PausaTelegram.linkUrl(telegram);
    const box = $("#telegram-qr");
    if (box.dataset.url !== url) {
      box.replaceChildren(PausaQR.toSvg(url));
      box.dataset.url = url;
      box.setAttribute("aria-label", `Código QR para conectar el móvil con @${telegram.botUsername}`);
    }
  }
  if (linked) {
    $("#phone-name").textContent = `Conectado con ${telegram.chatName} · @${telegram.botUsername}`;
    $("#phone-end").checked = telegram.onEnd;
    $("#phone-suggest").checked = telegram.onSuggest;
    $("#phone-overtime").checked = telegram.onOvertime;
  }
  updateLinkPolling();
}

// Mientras se muestra el QR, pregunta a Telegram cada pocos segundos si ya pulsaste "Iniciar".
function updateLinkPolling() {
  const telegram = state.settings.telegram;
  const shouldPoll = view === "settings" && Boolean(telegram.token && telegram.botUsername && !telegram.chatId);
  if (shouldPoll && !linkPoll) linkPoll = setInterval(checkLink, 2500);
  if (!shouldPoll && linkPoll) {
    clearInterval(linkPoll);
    linkPoll = null;
  }
}

async function checkLink() {
  if (checkingLink) return;
  checkingLink = true;
  try {
    const telegram = state.settings.telegram;
    const found = await PausaTelegram.findLink(telegram);
    if (!found) return;
    state.settings.telegram = { ...telegram, ...found, linkCode: "" };
    await persist(["settings"]);
    await PausaTelegram.send(state.settings.telegram, "🌸 ¡Listo! Pausa Bloom ya puede avisarte aquí cuando termine tu descanso o llegue la hora de descansar.");
    $("#phone-error").textContent = "";
    showToast("Móvil conectado");
    renderPhone();
  } catch (error) {
    $("#phone-error").textContent = `No se pudo comprobar la conexión: ${error.message}`;
  } finally {
    checkingLink = false;
  }
}

async function saveTelegramToken() {
  const error = $("#phone-error");
  const button = $("#telegram-save");
  error.textContent = "";
  // El permiso se pide lo primero, mientras Chrome aún considera que viene de tu clic.
  if (!(await PausaTelegram.requestPermission())) {
    error.textContent = "Hace falta permitir la conexión con Telegram para enviarte avisos.";
    return;
  }
  const token = $("#telegram-token").value.trim();
  if (!PausaTelegram.TOKEN_PATTERN.test(token)) {
    error.textContent = "Ese código no parece válido. Cópialo entero desde el mensaje de @BotFather.";
    return;
  }
  button.disabled = true;
  button.textContent = "Comprobando…";
  try {
    const bot = await PausaTelegram.call(token, "getMe");
    state.settings.telegram = {
      ...state.settings.telegram,
      token,
      botUsername: bot.username,
      linkCode: PausaTelegram.newLinkCode(),
      chatId: null,
      chatName: ""
    };
    await persist(["settings"]);
    $("#telegram-token").value = "";
    chrome.storage.local.remove("telegramDraft");
    renderPhone();
  } catch {
    error.textContent = "Telegram no reconoce ese código. Revisa que lo hayas copiado entero.";
  } finally {
    button.disabled = false;
    button.textContent = "Continuar";
  }
}

async function resetTelegram(message) {
  const { onEnd, onSuggest, onOvertime } = state.settings.telegram;
  state.settings.telegram = { ...Core.DEFAULT_SETTINGS.telegram, onEnd, onSuggest, onOvertime };
  $("#phone-error").textContent = "";
  await persist(["settings"]);
  renderPhone();
  if (message) showToast(message);
}

