// Ajustes: tema, horarios, semanas, rutinas, avisos, copias y exportación.
// ---------- Ajustes ----------

async function saveSettings(message = "Cambios guardados") {
  await persist(["settings"]);
  await saveUiState();
  showToast(message);
  render();
}

function renderWeekdayModes() {
  dom.weekdayModes.replaceChildren();
  const profile = editingProfile();
  profile.weekdayModes.forEach((value, index) => {
    const button = element("button", `weekday is-${value}`);
    button.type = "button";
    button.append(element("span", "", WEEKDAY_LETTERS[index]), element("strong", "", WEEKDAY_VALUE_LABEL[value]));
    const dayName = formatDate(new Date(2024, 0, 1 + index), { weekday: "long" });
    button.setAttribute("aria-label", `${dayName}: ${value === "none" ? "sin jornada" : MODE_NAMES[value].toLowerCase()}. Pulsa para cambiar.`);
    button.addEventListener("click", () => {
      profile.weekdayModes[index] = WEEKDAY_CYCLE[value];
      renderWeekdayModes();
      saveSettings();
    });
    dom.weekdayModes.append(button);
  });
}

function fillRoutineInputs(routines) {
  $$(".routine-row input").forEach((input) => {
    input.value = routines[input.dataset.mode][input.dataset.kind][input.dataset.field];
    if (input.dataset.field === "count") updateRoutineCountButtons(input);
  });
}

function updateRoutineCountButtons(input) {
  const count = Number(input.value);
  const control = input.closest(".routine-count-control");
  if (!control) return;
  control.querySelector('[data-routine-step="-1"]').disabled = !Number.isFinite(count) || count <= 0;
  control.querySelector('[data-routine-step="1"]').disabled = !Number.isFinite(count) || count >= 30;
}

function renderShortcuts() {
  const labels = {
    "start-break": "Empezar el descanso sugerido",
    "finish-break": "Ya volví",
    _execute_action: "Abrir Pausa Bloom"
  };
  dom.shortcutList.replaceChildren();
  for (const name of ["start-break", "finish-break", "_execute_action"]) {
    const item = element("li");
    const keys = element("span", "keys");
    const shortcut = shortcuts[name];
    if (shortcut) shortcut.split("+").forEach((key) => keys.append(element("kbd", "", key)));
    else keys.append(element("span", "muted", "Sin asignar"));
    item.append(element("span", "", labels[name]), keys);
    dom.shortcutList.append(item);
  }
}

function renderSettings() {
  const { settings } = state;
  $$('input[name="theme"]').forEach((input) => { input.checked = input.value === settings.theme; });
  dom.longIcon.value = settings.icons.long;
  dom.shortIcon.value = settings.icons.short;
  if (!settings.profiles.some((profile) => profile.id === editingProfileId)) editingProfileId = Core.profileFor(settings, todayKey()).id;
  renderProfiles();
  renderWeeks();
  $("#suggest-lead").value = String(settings.suggestLead);
  $("#overtime-alert").value = String(settings.overtimeAlert);
  dom.timerEnabled.checked = settings.timerEnabled;
  dom.endAlert.checked = settings.endAlert;
  dom.suggestAlert.checked = settings.suggestAlert;
  dom.soundSelect.value = settings.sound;
  dom.hoursError.textContent = "";
  dom.routineError.textContent = "";
  dom.alertsError.textContent = "";
  renderShortcuts();
  renderPhone();
}

// ---------- Horarios (perfiles) y semanas ----------

let editingProfileId = null;
const PLAN_HELP = {
  spread: "Repartimos los descansos de forma equilibrada hasta el final de la jornada; los más largos, hacia la mitad.",
  interval: "Te toca un descanso cada cierto tiempo de trabajo, contando desde el último descanso (o desde el inicio de la jornada).",
  fixed: "Escribe tú a qué hora va cada descanso y cuánto dura. La rutina del día será esta lista."
};

function editingProfile() {
  return state.settings.profiles.find((profile) => profile.id === editingProfileId) || state.settings.profiles[0];
}

function profileOptions(select, selectedId) {
  select.replaceChildren(...state.settings.profiles.map((profile) => new Option(profile.name, profile.id, false, profile.id === selectedId)));
}

function renderProfiles() {
  const profile = editingProfile();
  profileOptions($("#profile-select"), profile.id);
  $("#profile-delete").hidden = state.settings.profiles.length < 2;
  $("#profile-name").value = profile.name;
  $$("[data-hours]").forEach((input) => { input.value = profile.hours[input.dataset.hours][input.dataset.edge]; });
  $$("[data-break-until]").forEach((input) => { input.value = profile.breakUntil[input.dataset.breakUntil]; });
  $$('input[name="plan-mode"]').forEach((input) => { input.checked = input.value === profile.plan.mode; });
  $("#plan-help").textContent = PLAN_HELP[profile.plan.mode];
  $("#interval-row").hidden = profile.plan.mode !== "interval";
  $("#fixed-editor").hidden = profile.plan.mode !== "fixed";
  $("#routines-block").hidden = profile.plan.mode === "fixed";
  $("#plan-interval").value = profile.plan.interval;
  fillRoutineInputs(profile.routines);
  renderFixedList("long");
  renderFixedList("short");
  renderWeekdayModes();
  dom.hoursError.textContent = "";
  dom.routineError.textContent = "";
  renderExtrasSettings();
}

function renderFixedList(routineMode) {
  const list = $(`.fixed-list[data-fixed="${routineMode}"]`);
  const slots = editingProfile().plan.fixed[routineMode];
  list.replaceChildren();
  if (!slots.length) list.append(element("li", "fixed-empty", "Sin horas todavía"));
  slots.forEach((slot, index) => {
    const item = element("li", "fixed-item");
    const time = element("input");
    time.type = "time";
    time.value = slot.time;
    time.setAttribute("aria-label", `Hora del descanso ${index + 1}`);
    const minutes = element("input");
    minutes.type = "number";
    minutes.min = "1";
    minutes.max = "120";
    minutes.value = slot.minutes;
    minutes.setAttribute("aria-label", `Minutos del descanso ${index + 1}`);
    const remove = element("button", "icon-btn icon-btn-sm danger");
    remove.type = "button";
    remove.append(icon("i-x"));
    remove.setAttribute("aria-label", `Quitar el descanso de las ${slot.time}`);
    const update = () => {
      const value = Number(minutes.value);
      if (!time.value || !Number.isInteger(value) || value < 1 || value > 120) {
        dom.routineError.textContent = "Cada hora fija necesita una hora y una duración de 1 a 120 minutos.";
        return;
      }
      dom.routineError.textContent = "";
      const current = editingProfile().plan.fixed[routineMode];
      current[index] = { time: time.value, minutes: value };
      current.sort((a, b) => a.time.localeCompare(b.time));
      saveSettings("Horas fijas guardadas");
      renderFixedList(routineMode);
    };
    time.addEventListener("change", update);
    minutes.addEventListener("change", update);
    remove.addEventListener("click", () => {
      editingProfile().plan.fixed[routineMode].splice(index, 1);
      saveSettings("Hora fija quitada");
      renderFixedList(routineMode);
    });
    item.append(time, minutes, element("span", "muted", "min"), remove);
    list.append(item);
  });
}

function addFixedSlot(routineMode) {
  const profile = editingProfile();
  const slots = profile.plan.fixed[routineMode];
  // Propone una hora después de la última (o una hora después del inicio de la jornada).
  const lastTime = slots.length ? slots[slots.length - 1].time : profile.hours[routineMode].start;
  const [hours, minutes] = lastTime.split(":").map(Number);
  const next = Math.min(23 * 60 + 55, hours * 60 + minutes + 60);
  slots.push({ time: `${String(Math.floor(next / 60)).padStart(2, "0")}:${String(next % 60).padStart(2, "0")}`, minutes: 5 });
  slots.sort((a, b) => a.time.localeCompare(b.time));
  saveSettings("Hora fija añadida");
  renderFixedList(routineMode);
}

function addProfile() {
  const source = editingProfile();
  const id = `p${Date.now().toString(36)}`;
  const copy = { ...structuredClone(source), id, name: `${source.name} (copia)` };
  state.settings.profiles.push(copy);
  editingProfileId = id;
  saveSettings("Horario creado: cámbiale el nombre y ajústalo");
  renderProfiles();
  renderWeeks();
  $("#profile-name").select();
}

async function deleteProfile() {
  if (state.settings.profiles.length < 2) return;
  const before = snapshot();
  const removed = editingProfile();
  state.settings.profiles = state.settings.profiles.filter((profile) => profile.id !== removed.id);
  if (state.settings.defaultProfile === removed.id) state.settings.defaultProfile = state.settings.profiles[0].id;
  for (const [week, id] of Object.entries(state.settings.weekProfiles)) {
    if (id === removed.id) delete state.settings.weekProfiles[week];
  }
  editingProfileId = state.settings.defaultProfile;
  await persist(["settings"]);
  renderProfiles();
  renderWeeks();
  render();
  showToast(`Horario «${removed.name}» borrado`, () => restoreSnapshot(before));
}

function renderWeeks() {
  const { settings } = state;
  profileOptions($("#default-profile"), settings.defaultProfile);
  const list = dom.weekList;
  list.replaceChildren();
  const thisWeek = Core.addDays(Core.weekStart(todayKey()), weekOffset * 7);
  dom.previousWeeks.disabled = weekOffset === 0;
  for (let index = 0; index < 8; index += 1) {
    const week = Core.addDays(thisWeek, index * 7);
    const sunday = Core.dateFromKey(Core.addDays(week, 6));
    const monday = Core.dateFromKey(week);
    const item = element("li", "week-item");
    const label = element("div", "week-label");
    label.append(
      element("strong", "", week === Core.weekStart(todayKey()) ? "Esta semana" : `Semana del ${monday.getDate()} ${formatDate(monday, { month: "short" }).replace(".", "")}`),
      element("span", "", `${monday.getDate()} ${formatDate(monday, { month: "short" }).replace(".", "")} – ${sunday.getDate()} ${formatDate(sunday, { month: "short" }).replace(".", "")}`)
    );
    // Indica de dónde sale el horario de la semana: rotación, por defecto o semana libre.
    const kind = Core.weekKind(settings, week);
    const effective = Core.profileFor(settings, week).name;
    if (kind === "off") label.lastChild.textContent += " · libre";
    else if (kind === "rotation") label.lastChild.textContent += ` · rotación: ${effective}`;
    else if (kind === "default" && settings.profiles.length > 1) label.lastChild.textContent += ` · ${effective}`;
    const select = element("select");
    select.setAttribute("aria-label", `Horario de la semana del ${formatDate(monday, { day: "numeric", month: "long" })}`);
    select.append(new Option("Automático", ""));
    settings.profiles.forEach((profile) => select.append(new Option(profile.name, profile.id)));
    select.append(new Option("Semana libre", Core.OFF));
    select.value = settings.weekProfiles[week] || "";
    select.classList.toggle("is-custom", Boolean(settings.weekProfiles[week]));
    select.addEventListener("change", () => {
      if (select.value) state.settings.weekProfiles[week] = select.value;
      else delete state.settings.weekProfiles[week];
      saveSettings(select.value ? "Horario de la semana guardado" : "La semana usa el horario por defecto");
      renderWeeks();
    });
    item.append(label, select);
    list.append(item);
  }
  dom.nextWeeks.setAttribute("aria-label", `Ver semanas desde ${formatDate(Core.dateFromKey(thisWeek), { day: "numeric", month: "long" })}`);
}

function readRoutineInputs() {
  const routines = structuredClone(editingProfile().routines);
  for (const input of $$(".routine-row input")) {
    const value = Number(input.value);
    const isCount = input.dataset.field === "count";
    if (!Number.isInteger(value) || (isCount ? value < 0 || value > 30 : value < 1 || value > 120)) {
      throw new Error("Usa cantidades de 0 a 30 y duraciones de 1 a 120 minutos.");
    }
    routines[input.dataset.mode][input.dataset.kind][input.dataset.field] = value;
  }
  for (const routineMode of ["long", "short"]) {
    if (![5, 10, 15].some((kind) => routines[routineMode][kind].count > 0)) {
      throw new Error(`Añade al menos un descanso al ${routineMode === "long" ? "día largo" : "día corto"}.`);
    }
  }
  return routines;
}

async function ensureNotificationPermission(checkbox) {
  if (!checkbox.checked) return true;
  // Se pide directamente: si ya estaba concedido, Chrome responde que sí sin preguntar.
  const granted = await chrome.permissions.request({ permissions: ["notifications"] });
  if (!granted) {
    checkbox.checked = false;
    dom.alertsError.textContent = "Para avisarte hace falta el permiso de notificaciones del navegador.";
  }
  return granted;
}

function csvEscape(value) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function download(filename, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportCsv() {
  const header = ["Fecha", "Hora de inicio", "Rutina", "Duracion (min)", "Hora de vuelta", "Tiempo extra (min)"];
  const rows = [...state.records]
    .sort((a, b) => a.startedAt - b.startedAt)
    .map((record) => [
      record.day,
      formatTime(record.startedAt),
      record.mode === "long" ? "Dia largo" : "Dia corto",
      record.plannedMinutes,
      record.completedAt ? formatTime(record.completedAt) : "",
      Core.overtimeMinutes(record)
    ]);
  const content = [header, ...rows].map((row) => row.map(csvEscape).join(",")).join("\r\n");
  download(`pausa-bloom-${todayKey()}.csv`, `﻿${content}`, "text/csv;charset=utf-8");
  showToast("Historial exportado en CSV");
}

// La copia incluye TODO lo guardado: ajustes, historial, días libres, la cuenta de Telegram y el resto de datos.
async function exportBackup() {
  const data = await chrome.storage.local.get(null);
  delete data.activeTimer;
  delete data.telegramDraft;
  const backup = { app: "pausa-bloom", version: 4, exportedAt: new Date().toISOString(), data };
  download(`pausa-bloom-copia-${todayKey()}.json`, JSON.stringify(backup, null, 2), "application/json");
  showToast("Copia completa creada (incluye tu cuenta de Telegram)");
}
function isValidRecord(record) {
  return record && typeof record.id === "string" && /^\d{4}-\d{2}-\d{2}$/.test(record.day)
    && (record.mode === "long" || record.mode === "short")
    && Number.isFinite(record.startedAt) && Number.isInteger(record.plannedMinutes)
    && (record.completedAt === null || record.completedAt === undefined || Number.isFinite(record.completedAt));
}

async function importBackup(file) {
  try {
    const backup = JSON.parse(await file.text());
    if (backup?.app !== "pausa-bloom") throw new Error();
    // Las copias antiguas (versión 3) guardaban los datos sueltos y sin el código de Telegram.
    const data = backup.data || { settings: backup.settings, records: backup.records, daysOff: backup.daysOff };
    if (!Array.isArray(data.records)) throw new Error();
    const known = new Set(state.records.map((record) => record.id));
    const added = data.records.filter(isValidRecord)
      .map((record) => ({ ...record, completedAt: record.completedAt ?? null }))
      .filter((record) => !known.has(record.id));
    state.records = [...state.records, ...added];
    const importedDaysOff = Array.isArray(data.daysOff) ? data.daysOff.filter((day) => /^\d{4}-\d{2}-\d{2}$/.test(day)) : [];
    state.daysOff = [...new Set([...state.daysOff, ...importedDaysOff])];
    if (data.settings) {
      // Si la copia no trae cuenta de Telegram, se conserva la actual.
      const telegram = data.settings.telegram?.token ? data.settings.telegram : state.settings.telegram;
      state.settings = Core.mergeSettings({ ...data.settings, telegram });
    }
    const extra = {};
    for (const key of ["lastMode", "tutorialDone", "quoteDeck", "lastSuggestAt"]) if (key in data) extra[key] = data[key];
    await persist(["records", "daysOff", "settings"]);
    if (Object.keys(extra).length) await chrome.storage.local.set(extra);
    renderSettings();
    render();
    showToast(`Copia restaurada · ${plural(added.length, "descanso nuevo", "descansos nuevos")}`);
  } catch {
    showToast("Ese archivo no es una copia válida de Pausa Bloom");
  }
}
