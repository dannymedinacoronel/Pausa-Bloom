// Avisos al móvil a través de un bot de Telegram propio (sin servidor intermedio).
(function (global) {
  const ORIGIN = "https://api.telegram.org/*";
  const TOKEN_PATTERN = /^\d{5,}:[A-Za-z0-9_-]{30,}$/;

  async function call(token, method, payload) {
    const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {}),
      signal: AbortSignal.timeout(((payload && payload.timeout) || 0) * 1000 + 15000)
    });
    const data = await response.json().catch(() => null);
    if (!data?.ok) throw new Error(data?.description || `Telegram respondió ${response.status}`);
    return data.result;
  }

  function isLinked(telegram) {
    return Boolean(telegram?.token && telegram.chatId);
  }

  function hasPermission() {
    return chrome.permissions.contains({ origins: [ORIGIN] });
  }

  function requestPermission() {
    return chrome.permissions.request({ origins: [ORIGIN] });
  }

  // Código de un solo uso que viaja en el QR para saber que el móvil que pulsa "Iniciar" eres tú.
  function newLinkCode() {
    const bytes = crypto.getRandomValues(new Uint8Array(12));
    return [...bytes].map((byte) => "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"[byte % 56]).join("");
  }

  function linkUrl(telegram) {
    return `https://t.me/${telegram.botUsername}?start=${telegram.linkCode}`;
  }

  // Busca el mensaje "/start <código>" que envía Telegram al pulsar "Iniciar" tras escanear el QR.
  async function findLink(telegram) {
    const updates = await call(telegram.token, "getUpdates", { timeout: 0, allowed_updates: ["message"] });
    const match = updates.find((update) => update.message?.text?.trim() === `/start ${telegram.linkCode}`);
    if (updates.length) {
      // Marca los mensajes como leídos para no procesarlos otra vez.
      await call(telegram.token, "getUpdates", { offset: updates[updates.length - 1].update_id + 1, timeout: 0 });
    }
    if (!match) return null;
    const chat = match.message.chat;
    return { chatId: chat.id, chatName: chat.first_name || chat.username || "tu móvil" };
  }

  // `buttons` es una lista de [texto, dato]: se muestran como botones bajo el mensaje.
  async function send(telegram, text, buttons) {
    if (!isLinked(telegram) || !(await hasPermission())) return false;
    const payload = { chat_id: telegram.chatId, text, disable_web_page_preview: true };
    if (buttons?.length) payload.reply_markup = { inline_keyboard: [buttons.map(([label, data]) => ({ text: label, callback_data: data }))] };
    await call(telegram.token, "sendMessage", payload);
    return true;
  }

  global.PausaTelegram = { TOKEN_PATTERN, call, isLinked, hasPermission, requestPermission, newLinkCode, linkUrl, findLink, send };
})(globalThis);
