// Lógica compartida entre la ventana emergente y el proceso en segundo plano.
(function (global) {
  const MINUTE = 60_000;
  // Si nadie pulsa "Ya volví", el descanso se cierra solo pasado este tiempo extra.
  const STALE_MINUTES = 60;
  const MODE_NAMES = { long: "Día largo", short: "Día corto" };
  const THEME_ACCENT = { pink: "#D6457F", classic: "#2F6690", night: "#8B7CF6", noir: "#E5528F" };
  const THEME_WARN = { pink: "#D9692A", classic: "#C25B22", night: "#E8913F", noir: "#E8913F" };
  const BREAK_ICONS = ["🌸", "💣", "💖", "⏰", "☕", "🪴", "🦋", "✨", "🍓", "🐱"];

  const DEFAULT_ROUTINES = {
    long: { 5: { count: 6, minutes: 5 }, 10: { count: 2, minutes: 10 }, 15: { count: 0, minutes: 15 } },
    short: { 5: { count: 5, minutes: 5 }, 10: { count: 0, minutes: 10 }, 15: { count: 1, minutes: 15 } }
  };
  const DEFAULT_HOURS = { long: { start: "09:00", end: "19:00" }, short: { start: "09:00", end: "15:00" } };
  // Un horario guardado: jornada, rutinas y forma de repartir los descansos.
  //   plan.mode: "spread" (repartir en la jornada), "interval" (cada X minutos) o "fixed" (horas fijas).
  const DEFAULT_PROFILE = {
    id: "normal",
    name: "Normal",
    hours: DEFAULT_HOURS,
    routines: DEFAULT_ROUTINES,
    plan: { mode: "spread", interval: 60, fixed: { long: [], short: [] } }
  };
  const DEFAULT_SETTINGS = {
    theme: "pink",
    icons: { long: "🌸", short: "🌸" },
    timerEnabled: true,
    endAlert: false,
    suggestAlert: false,
    // Minutos de antelación para el aviso de la hora sugerida.
    suggestLead: 0,
    // Minutos de más tras los que avisa al móvil si sigues de descanso.
    overtimeAlert: 5,
    sound: "bell",
    profiles: [DEFAULT_PROFILE],
    defaultProfile: "normal",
    // Horario elegido para semanas concretas: { "2026-11-09": "corta" } (clave = lunes de la semana).
    weekProfiles: {},
    // Lunes a domingo: "none", "long" o "short".
    weekdayModes: ["none", "none", "none", "none", "none", "none", "none"],
    // Avisos al móvil a través de un bot de Telegram propio.
    telegram: { token: "", botUsername: "", linkCode: "", chatId: null, chatName: "", onEnd: true, onSuggest: true, onOvertime: true }
  };

  function dateKey(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${date.getFullYear()}-${month}-${day}`;
  }

  function dateFromKey(key) {
    const [year, month, day] = key.split("-").map(Number);
    return new Date(year, month - 1, day);
  }

  function addDays(key, amount) {
    const date = dateFromKey(key);
    date.setDate(date.getDate() + amount);
    return dateKey(date);
  }

  function timestampFor(day, timeValue) {
    const [hours, minutes] = timeValue.split(":").map(Number);
    const date = dateFromKey(day);
    date.setHours(hours, minutes, 0, 0);
    return date.getTime();
  }

  function weekdayIndex(date) {
    return (date.getDay() + 6) % 7;
  }

  function mergeProfile(saved) {
    const mergeRoutine = (mode) => Object.fromEntries([5, 10, 15].map((kind) => [
      kind,
      { ...DEFAULT_ROUTINES[mode][kind], ...(saved?.routines?.[mode]?.[kind] || {}) }
    ]));
    const validSlots = (list) => (Array.isArray(list) ? list : [])
      .filter((slot) => /^\d{2}:\d{2}$/.test(slot?.time) && Number.isInteger(slot?.minutes) && slot.minutes > 0)
      .map((slot) => ({ time: slot.time, minutes: slot.minutes }));
    return {
      id: saved?.id || DEFAULT_PROFILE.id,
      name: saved?.name || DEFAULT_PROFILE.name,
      hours: {
        long: { ...DEFAULT_HOURS.long, ...(saved?.hours?.long || {}) },
        short: { ...DEFAULT_HOURS.short, ...(saved?.hours?.short || {}) }
      },
      routines: { long: mergeRoutine("long"), short: mergeRoutine("short") },
      plan: {
        mode: ["spread", "interval", "fixed"].includes(saved?.plan?.mode) ? saved.plan.mode : "spread",
        interval: Number.isInteger(saved?.plan?.interval) && saved.plan.interval >= 15 ? saved.plan.interval : 60,
        fixed: { long: validSlots(saved?.plan?.fixed?.long), short: validSlots(saved?.plan?.fixed?.short) }
      }
    };
  }

  function mergeSettings(saved) {
    // Las versiones anteriores guardaban un único horario en settings.hours y settings.routines.
    const profiles = Array.isArray(saved?.profiles) && saved.profiles.length
      ? saved.profiles.map(mergeProfile)
      : [mergeProfile({ ...DEFAULT_PROFILE, hours: saved?.hours, routines: saved?.routines })];
    const defaultProfile = profiles.some((profile) => profile.id === saved?.defaultProfile) ? saved.defaultProfile : profiles[0].id;
    const weekProfiles = Object.fromEntries(Object.entries(saved?.weekProfiles || {})
      .filter(([week, id]) => /^\d{4}-\d{2}-\d{2}$/.test(week) && profiles.some((profile) => profile.id === id)));
    const { hours, routines, ...rest } = saved || {};
    return {
      ...structuredClone(DEFAULT_SETTINGS),
      ...rest,
      theme: THEME_ACCENT[saved?.theme] ? saved.theme : DEFAULT_SETTINGS.theme,
      icons: {
        long: BREAK_ICONS.includes(saved?.icons?.long) ? saved.icons.long : DEFAULT_SETTINGS.icons.long,
        short: BREAK_ICONS.includes(saved?.icons?.short) ? saved.icons.short : DEFAULT_SETTINGS.icons.short
      },
      suggestLead: Number.isInteger(saved?.suggestLead) ? saved.suggestLead : DEFAULT_SETTINGS.suggestLead,
      overtimeAlert: Number.isInteger(saved?.overtimeAlert) ? saved.overtimeAlert : DEFAULT_SETTINGS.overtimeAlert,
      profiles,
      defaultProfile,
      weekProfiles,
      weekdayModes: Array.isArray(saved?.weekdayModes) && saved.weekdayModes.length === 7
        ? saved.weekdayModes
        : [...DEFAULT_SETTINGS.weekdayModes],
      telegram: { ...DEFAULT_SETTINGS.telegram, ...(saved?.telegram || {}) }
    };
  }

  // Lunes de la semana de `day`, que es la clave de settings.weekProfiles.
  function weekStart(day) {
    return addDays(day, -weekdayIndex(dateFromKey(day)));
  }

  // Horario que se aplica a un día: el elegido para su semana o, si no, el de por defecto.
  function profileFor(settings, day = dateKey(new Date())) {
    const id = settings.weekProfiles?.[weekStart(day)] || settings.defaultProfile;
    return settings.profiles.find((profile) => profile.id === id) || settings.profiles[0];
  }

  function recordsFor(records, day, mode) {
    return records
      .filter((record) => record.day === day && (!mode || record.mode === mode))
      .sort((a, b) => a.startedAt - b.startedAt);
  }

  // Agrupa la rutina del día por duración: [{ minutes: 5, count: 6 }, { minutes: 10, count: 2 }].
  // Con horas fijas, la rutina es la propia lista de horas.
  function routineGroups(settings, mode, day) {
    const profile = profileFor(settings, day);
    const groups = new Map();
    if (profile.plan.mode === "fixed") {
      for (const slot of profile.plan.fixed[mode]) groups.set(slot.minutes, (groups.get(slot.minutes) || 0) + 1);
    } else {
      for (const kind of [5, 10, 15]) {
        const { count, minutes } = profile.routines[mode][kind];
        if (count > 0) groups.set(minutes, (groups.get(minutes) || 0) + count);
      }
    }
    return [...groups].sort((a, b) => a[0] - b[0]).map(([minutes, count]) => ({ minutes, count }));
  }

  function routineMinutes(settings, mode, day) {
    return routineGroups(settings, mode, day).reduce((sum, group) => sum + group.minutes * group.count, 0);
  }

  function progressFor(state, mode, day) {
    const dayRecords = recordsFor(state.records, day, mode);
    const groups = routineGroups(state.settings, mode, day).map((group) => {
      const taken = dayRecords.filter((record) => record.plannedMinutes === group.minutes).length;
      return { ...group, taken, remaining: Math.max(0, group.count - taken) };
    });
    const total = groups.reduce((sum, group) => sum + group.count, 0);
    const done = groups.reduce((sum, group) => sum + Math.min(group.taken, group.count), 0);
    return { groups, total, done, extra: dayRecords.length - done, complete: total > 0 && done >= total };
  }

  function dayComplete(state, day) {
    return ["long", "short"].some((mode) => progressFor(state, mode, day).complete);
  }

  // Días que no rompen la racha: marcados como libres o sin jornada en el horario semanal.
  function isRestDay(state, day) {
    if ((state.daysOff || []).includes(day)) return true;
    const modes = state.settings.weekdayModes;
    return modes.some((value) => value !== "none") && modes[weekdayIndex(dateFromKey(day))] === "none";
  }

  // Días completos seguidos que terminan en `day` (los días de descanso no cuentan ni rompen).
  function runLength(state, day) {
    const earliest = state.records.reduce((min, record) => (record.day < min ? record.day : min), day);
    let cursor = day;
    let run = 0;
    while (cursor >= earliest) {
      if (dayComplete(state, cursor)) run += 1;
      else if (!isRestDay(state, cursor)) break;
      cursor = addDays(cursor, -1);
    }
    return run;
  }

  function currentStreak(state, today = dateKey(new Date())) {
    return dayComplete(state, today) ? runLength(state, today) : runLength(state, addDays(today, -1));
  }

  function todayMode(settings, lastMode, date = new Date()) {
    const automatic = settings.weekdayModes[weekdayIndex(date)];
    if (automatic !== "none") return automatic;
    return lastMode === "short" ? "short" : "long";
  }

  function recordEnd(record) {
    return record.completedAt || record.startedAt + record.plannedMinutes * MINUTE;
  }

  // Coloca los descansos más largos en los huecos más cercanos a la mitad de la jornada.
  function assignDurations(slots, remaining, start, end) {
    const middle = start + (end - start) / 2;
    const slotOrder = slots.map((time, index) => index).sort((a, b) => Math.abs(slots[a] - middle) - Math.abs(slots[b] - middle));
    const durations = [...remaining].sort((a, b) => b - a);
    const assigned = [];
    slotOrder.forEach((slotIndex, position) => { assigned[slotIndex] = durations[position]; });
    return slots.map((time, index) => ({ time, minutes: assigned[index] }));
  }

  // Calcula a qué hora tomar cada descanso pendiente según el horario de la semana:
  //   spread   → repartidos de forma equilibrada hasta el final de la jornada;
  //   interval → uno cada X minutos desde el último descanso (o desde el inicio);
  //   fixed    → a las horas que hayas escrito.
  function planDay(state, mode, now = Date.now()) {
    const day = dateKey(new Date(now));
    const profile = profileFor(state.settings, day);
    const hours = profile.hours[mode];
    const start = timestampFor(day, hours.start);
    const end = timestampFor(day, hours.end);
    const progress = progressFor(state, mode, day);
    const taken = recordsFor(state.records, day, mode);
    const remaining = progress.groups.flatMap((group) => Array(group.remaining).fill(group.minutes));
    const base = { start, end, taken, progress, items: [], profile, planMode: profile.plan.mode };

    if (!progress.total) return { ...base, status: "empty" };
    if (!remaining.length) return { ...base, status: "complete" };
    // En días libres no hay sugerencias ni avisos.
    if (isRestDay(state, day)) return { ...base, status: "off", markedOff: (state.daysOff || []).includes(day) };
    if (end <= start) return { ...base, status: "invalid" };
    if (now >= end) return { ...base, status: "after" };

    const last = taken[taken.length - 1];
    const anchor = last ? Math.max(recordEnd(last), start) : start;
    const roundTo5 = (time) => Math.round(time / (5 * MINUTE)) * 5 * MINUTE;
    let items;

    if (profile.plan.mode === "fixed") {
      // Cada descanso tomado "cubre" la primera hora fija pendiente de su misma duración.
      const pendingByMinutes = new Map();
      for (const record of taken) pendingByMinutes.set(record.plannedMinutes, (pendingByMinutes.get(record.plannedMinutes) || 0) + 1);
      items = profile.plan.fixed[mode]
        .map((slot) => ({ time: timestampFor(day, slot.time), minutes: slot.minutes }))
        .sort((a, b) => a.time - b.time)
        .filter((slot) => {
          const covered = pendingByMinutes.get(slot.minutes) || 0;
          if (covered > 0) {
            pendingByMinutes.set(slot.minutes, covered - 1);
            return false;
          }
          return true;
        });
    } else if (profile.plan.mode === "interval") {
      const interval = profile.plan.interval * MINUTE;
      const first = Math.max(anchor + interval, now);
      const slots = [];
      for (let time = first; slots.length < remaining.length && time < end; time += interval) {
        slots.push(slots.length === 0 ? time : roundTo5(time));
      }
      // Si no caben todos antes del final de la jornada, se priorizan los descansos largos.
      items = assignDurations(slots, [...remaining].sort((a, b) => b - a).slice(0, slots.length), start, end);
    } else {
      let gap = (end - anchor) / (remaining.length + 1);
      let first = anchor + gap;
      if (first <= now) {
        first = now;
        gap = (end - now) / remaining.length;
      }
      const slots = remaining.map((_, index) => (index === 0 && first === now ? first : roundTo5(first + gap * index)));
      items = assignDurations(slots, remaining, start, end);
    }

    if (!items.length) return { ...base, status: "after" };
    const late = items[0].time <= now;
    return { ...base, status: "ok", items, late, next: items[0] };
  }

  function createBreak(mode, minutes, timerEnabled, now = Date.now()) {
    const record = {
      id: crypto.randomUUID(),
      day: dateKey(new Date(now)),
      mode,
      startedAt: now,
      plannedMinutes: minutes,
      completedAt: null
    };
    const activeTimer = timerEnabled
      ? { recordId: record.id, startedAt: now, endAt: now + minutes * MINUTE, minutes }
      : null;
    return { record, activeTimer };
  }

  function closeActive(records, activeTimer, completedAt) {
    return records.map((record) =>
      record.id === activeTimer.recordId && !record.completedAt ? { ...record, completedAt } : record
    );
  }

  function overtimeMinutes(record) {
    if (!record.completedAt) return 0;
    return Math.max(0, Math.round((record.completedAt - record.startedAt) / MINUTE - record.plannedMinutes));
  }

  global.PausaCore = {
    MINUTE, STALE_MINUTES, MODE_NAMES, THEME_ACCENT, THEME_WARN, DEFAULT_ROUTINES, DEFAULT_HOURS, DEFAULT_PROFILE, DEFAULT_SETTINGS,
    mergeProfile, weekStart, profileFor,
    dateKey, dateFromKey, addDays, timestampFor, weekdayIndex, mergeSettings, recordsFor, routineGroups,
    routineMinutes, progressFor, dayComplete, isRestDay, runLength, currentStreak, todayMode, recordEnd,
    planDay, createBreak, closeActive, overtimeMinutes
  };
})(globalThis);
