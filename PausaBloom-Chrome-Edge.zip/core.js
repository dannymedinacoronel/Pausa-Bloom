// Lógica compartida entre la ventana emergente y el proceso en segundo plano.
(function (global) {
  const MINUTE = 60_000;
  const DAY = 86_400_000;
  // Valor especial de settings.weekProfiles: la semana entera es libre.
  const OFF = "__off";
  // Si nadie pulsa "Ya volví", el descanso se cierra solo pasado este tiempo extra.
  const STALE_MINUTES = 60;
  const MODE_NAMES = { long: "Día largo", short: "Día corto" };
  const THEME_ACCENT = { pink: "#D6457F", classic: "#2F6690", night: "#8B7CF6", noir: "#E5528F" };
  const THEME_WARN = { pink: "#D9692A", classic: "#C25B22", night: "#E8913F", noir: "#E8913F" };
  const BREAK_ICONS = ["🌸", "💣", "💖", "⏰", "☕", "🪴", "🦋", "✨", "🍓", "🐱"];

  const DEFAULT_ROUTINES = {
    long: { 5: { count: 6, minutes: 5 }, 10: { count: 2, minutes: 10 }, 15: { count: 0, minutes: 15 } },
    short: { 5: { count: 5, minutes: 5 }, 10: { count: 0, minutes: 10 }, 15: { count: 1, minutes: 15 } }
  };
  const DEFAULT_HOURS = { long: { start: "09:00", end: "19:00" }, short: { start: "09:00", end: "15:00" } };
  const DEFAULT_BREAK_UNTIL = { long: "19:00", short: "15:00" };
  // Pausa de comida (jornada partida): vacía = sin pausa. Los descansos no se sugieren dentro de ella.
  const DEFAULT_PAUSE = { long: { start: "", end: "" }, short: { start: "", end: "" } };
  const DEFAULT_WEEKDAY_MODES = ["none", "none", "none", "none", "none", "none", "none"];
  // Un horario guardado: jornada, rutinas y forma de repartir los descansos.
  //   plan.mode: "spread" (repartir en la jornada), "interval" (cada X minutos) o "fixed" (horas fijas).
  const DEFAULT_PROFILE = {
    id: "normal",
    name: "Normal",
    hours: DEFAULT_HOURS,
    breakUntil: DEFAULT_BREAK_UNTIL,
    pause: DEFAULT_PAUSE,
    weekdayModes: [...DEFAULT_WEEKDAY_MODES],
    routines: DEFAULT_ROUTINES,
    plan: { mode: "spread", interval: 60, fixed: { long: [], short: [] } }
  };
  const DEFAULT_SETTINGS = {
    theme: "pink",
    icons: { long: "🌸", short: "🌸" },
    timerEnabled: true,
    endAlert: false,
    suggestAlert: false,
    // Minutos de antelación para el aviso de la hora sugerida.
    suggestLead: 0,
    // Minutos de más tras los que avisa al móvil si sigues de descanso.
    overtimeAlert: 5,
    sound: "bell",
    language: "es",
    // Ajusta las horas sugeridas a las horas en las que sueles descansar.
    learnHabits: true,
    // Copia automática diaria en Descargas.
    autoBackup: true,
    // Resumen de la semana el domingo por la noche.
    weeklySummary: true,
    // Recordatorio 20-20-20 para la vista, cada 20 minutos de jornada.
    eyeReminder: false,
    profiles: [DEFAULT_PROFILE],
    defaultProfile: "normal",
    // Horario elegido para semanas concretas: { "2026-11-09": "corta" } (clave = lunes de la semana).
    weekProfiles: {},
    // Alternar dos horarios semana a semana: la semana que empieza en aWeek usa a, la siguiente b, y así.
    rotation: { enabled: false, a: "normal", b: "normal", aWeek: "" },
    // Horas distintas para un día concreto: { "2026-11-12": { start: "09:00", end: "13:00" } }.
    dayOverrides: {},
    // Lunes a domingo: "none", "long" o "short".
    weekdayModes: ["none", "none", "none", "none", "none", "none", "none"],
    // Avisos al móvil a través de un bot de Telegram propio.
    telegram: { token: "", botUsername: "", linkCode: "", chatId: null, chatName: "", onEnd: true, onSuggest: true, onOvertime: true }
  };

  function dateKey(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${date.getFullYear()}-${month}-${day}`;
  }

  function dateFromKey(key) {
    const [year, month, day] = key.split("-").map(Number);
    return new Date(year, month - 1, day);
  }

  function addDays(key, amount) {
    const date = dateFromKey(key);
    date.setDate(date.getDate() + amount);
    return dateKey(date);
  }

  function timestampFor(day, timeValue) {
    const [hours, minutes] = timeValue.split(":").map(Number);
    const date = dateFromKey(day);
    date.setHours(hours, minutes, 0, 0);
    return date.getTime();
  }

  function weekdayIndex(date) {
    return (date.getDay() + 6) % 7;
  }

  function mergeProfile(saved, legacyWeekdayModes = DEFAULT_WEEKDAY_MODES) {
    const mergeRoutine = (mode) => Object.fromEntries([5, 10, 15].map((kind) => [
      kind,
      { ...DEFAULT_ROUTINES[mode][kind], ...(saved?.routines?.[mode]?.[kind] || {}) }
    ]));
    const validTime = (value) => typeof value === "string" && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
    const hours = {
      long: { ...DEFAULT_HOURS.long, ...(saved?.hours?.long || {}) },
      short: { ...DEFAULT_HOURS.short, ...(saved?.hours?.short || {}) }
    };
    const weekdayModes = Array.isArray(saved?.weekdayModes) && saved.weekdayModes.length === 7
      ? saved.weekdayModes
      : legacyWeekdayModes;
    const validSlots = (list) => (Array.isArray(list) ? list : [])
      .filter((slot) => /^\d{2}:\d{2}$/.test(slot?.time) && Number.isInteger(slot?.minutes) && slot.minutes > 0)
      .map((slot) => ({ time: slot.time, minutes: slot.minutes }));
    return {
      id: saved?.id || DEFAULT_PROFILE.id,
      name: saved?.name || DEFAULT_PROFILE.name,
      hours,
      breakUntil: {
        long: validTime(saved?.breakUntil?.long) ? saved.breakUntil.long : hours.long.end,
        short: validTime(saved?.breakUntil?.short) ? saved.breakUntil.short : hours.short.end
      },
      pause: Object.fromEntries(["long", "short"].map((mode) => {
        const pause = saved?.pause?.[mode];
        return [mode, validTime(pause?.start) && validTime(pause?.end) && pause.start < pause.end ? { start: pause.start, end: pause.end } : { start: "", end: "" }];
      })),
      weekdayModes: Array.from({ length: 7 }, (_, index) =>
        ["none", "long", "short"].includes(weekdayModes?.[index]) ? weekdayModes[index] : "none"),
      routines: { long: mergeRoutine("long"), short: mergeRoutine("short") },
      plan: {
        mode: ["spread", "interval", "fixed"].includes(saved?.plan?.mode) ? saved.plan.mode : "spread",
        interval: Number.isInteger(saved?.plan?.interval) && saved.plan.interval >= 15 ? saved.plan.interval : 60,
        fixed: { long: validSlots(saved?.plan?.fixed?.long), short: validSlots(saved?.plan?.fixed?.short) }
      }
    };
  }

  function mergeSettings(saved) {
    // Las versiones anteriores guardaban un único horario en settings.hours y settings.routines.
    const legacyWeekdayModes = Array.isArray(saved?.weekdayModes) && saved.weekdayModes.length === 7
      ? saved.weekdayModes
      : DEFAULT_WEEKDAY_MODES;
    const profiles = Array.isArray(saved?.profiles) && saved.profiles.length
      ? saved.profiles.map((profile) => mergeProfile(profile, legacyWeekdayModes))
      : [mergeProfile({ ...DEFAULT_PROFILE, hours: saved?.hours, routines: saved?.routines }, legacyWeekdayModes)];
    const defaultProfile = profiles.some((profile) => profile.id === saved?.defaultProfile) ? saved.defaultProfile : profiles[0].id;
    const weekProfiles = Object.fromEntries(Object.entries(saved?.weekProfiles || {})
      .filter(([week, id]) => /^\d{4}-\d{2}-\d{2}$/.test(week) && (id === OFF || profiles.some((profile) => profile.id === id))));
    const validDay = (value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
    const validHour = (value) => typeof value === "string" && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
    const known = (id) => profiles.some((profile) => profile.id === id);
    const rotation = {
      enabled: Boolean(saved?.rotation?.enabled),
      a: known(saved?.rotation?.a) ? saved.rotation.a : profiles[0].id,
      b: known(saved?.rotation?.b) ? saved.rotation.b : (profiles[1] || profiles[0]).id,
      aWeek: validDay(saved?.rotation?.aWeek) ? weekStart(saved.rotation.aWeek) : weekStart(dateKey(new Date()))
    };
    const dayOverrides = Object.fromEntries(Object.entries(saved?.dayOverrides || {})
      .filter(([day, hours]) => validDay(day) && validHour(hours?.start) && validHour(hours?.end) && hours.start !== hours.end)
      .map(([day, hours]) => [day, { start: hours.start, end: hours.end }]));
    const { hours, routines, ...rest } = saved || {};
    return {
      ...structuredClone(DEFAULT_SETTINGS),
      ...rest,
      theme: THEME_ACCENT[saved?.theme] ? saved.theme : DEFAULT_SETTINGS.theme,
      language: saved?.language === "en" ? "en" : "es",
      icons: {
        long: BREAK_ICONS.includes(saved?.icons?.long) ? saved.icons.long : DEFAULT_SETTINGS.icons.long,
        short: BREAK_ICONS.includes(saved?.icons?.short) ? saved.icons.short : DEFAULT_SETTINGS.icons.short
      },
      suggestLead: Number.isInteger(saved?.suggestLead) ? saved.suggestLead : DEFAULT_SETTINGS.suggestLead,
      overtimeAlert: Number.isInteger(saved?.overtimeAlert) ? saved.overtimeAlert : DEFAULT_SETTINGS.overtimeAlert,
      profiles,
      defaultProfile,
      weekProfiles,
      rotation,
      dayOverrides,
      weekdayModes: Array.from({ length: 7 }, (_, index) =>
        ["none", "long", "short"].includes(legacyWeekdayModes[index]) ? legacyWeekdayModes[index] : "none"),
      telegram: { ...DEFAULT_SETTINGS.telegram, ...(saved?.telegram || {}) }
    };
  }

  // Lunes de la semana de `day`, que es la clave de settings.weekProfiles.
  function weekStart(day) {
    return addDays(day, -weekdayIndex(dateFromKey(day)));
  }

  // Horario que toca en una semana por rotación A/B (null si la rotación está desactivada).
  function rotationProfileId(settings, week) {
    const rotation = settings.rotation;
    if (!rotation?.enabled) return null;
    const weeks = Math.round((dateFromKey(week) - dateFromKey(rotation.aWeek)) / (7 * DAY));
    return ((weeks % 2) + 2) % 2 === 0 ? rotation.a : rotation.b;
  }

  // Por qué se aplica un horario a una semana: elegido a mano, por rotación, por defecto o semana libre.
  function weekKind(settings, week) {
    const chosen = settings.weekProfiles?.[week];
    if (chosen === OFF) return "off";
    if (chosen) return "manual";
    return rotationProfileId(settings, week) ? "rotation" : "default";
  }

  // Horario de un día: el elegido a mano para su semana, si no el de la rotación y, si no, el de por defecto.
  function profileFor(settings, day = dateKey(new Date())) {
    const week = weekStart(day);
    const chosen = settings.weekProfiles?.[week];
    const id = (chosen && chosen !== OFF ? chosen : null) || rotationProfileId(settings, week) || settings.defaultProfile;
    return settings.profiles.find((profile) => profile.id === id) || settings.profiles[0];
  }

  // Horas de trabajo de un día (las del horario, o las de un cambio puntual de ese día).
  function hoursFor(settings, mode, day) {
    const override = settings.dayOverrides?.[day];
    return override ? { start: override.start, end: override.end } : profileFor(settings, day).hours[mode];
  }

  // Ventana de trabajo de un día en milisegundos. Si el fin es anterior al inicio, el turno cruza la medianoche.
  // `pause` es la pausa de comida (si cabe dentro de la jornada).
  function shiftWindow(settings, mode, day) {
    const profile = profileFor(settings, day);
    const override = settings.dayOverrides?.[day];
    const hours = hoursFor(settings, mode, day);
    const start = timestampFor(day, hours.start);
    let shiftEnd = timestampFor(day, hours.end);
    if (shiftEnd <= start) shiftEnd += DAY;
    let limit = timestampFor(day, override ? hours.end : profile.breakUntil[mode]);
    if (limit <= start) limit += DAY;
    const end = Math.min(shiftEnd, limit);
    let pause = null;
    const lunch = profile.pause?.[mode];
    if (lunch?.start && lunch?.end) {
      let from = timestampFor(day, lunch.start);
      let until = timestampFor(day, lunch.end);
      if (from < start) { from += DAY; until += DAY; }
      if (from > start && until < end) pause = { start: from, end: until };
    }
    return { start, shiftEnd, limit, end, pause, hours };
  }

  // Día de trabajo al que pertenece un instante: en un turno de noche, la madrugada cuenta como el día en que empezó.
  function workDay(settings, now = Date.now()) {
    const today = dateKey(new Date(now));
    const yesterday = addDays(today, -1);
    const midnight = timestampFor(today, "00:00");
    for (const mode of ["long", "short"]) {
      const { shiftEnd } = shiftWindow(settings, mode, yesterday);
      if (shiftEnd > midnight && now < shiftEnd) return yesterday;
    }
    return today;
  }

  function recordsFor(records, day, mode) {
    return records
      .filter((record) => record.day === day && (!mode || record.mode === mode))
      .sort((a, b) => a.startedAt - b.startedAt);
  }

  // Agrupa la rutina del día por duración: [{ minutes: 5, count: 6 }, { minutes: 10, count: 2 }].
  // Con horas fijas, la rutina es la propia lista de horas.
  function routineGroups(settings, mode, day) {
    const profile = profileFor(settings, day);
    const groups = new Map();
    if (profile.plan.mode === "fixed") {
      for (const slot of profile.plan.fixed[mode]) groups.set(slot.minutes, (groups.get(slot.minutes) || 0) + 1);
    } else {
      for (const kind of [5, 10, 15]) {
        const { count, minutes } = profile.routines[mode][kind];
        if (count > 0) groups.set(minutes, (groups.get(minutes) || 0) + count);
      }
    }
    return [...groups].sort((a, b) => a[0] - b[0]).map(([minutes, count]) => ({ minutes, count }));
  }

  function routineMinutes(settings, mode, day) {
    return routineGroups(settings, mode, day).reduce((sum, group) => sum + group.minutes * group.count, 0);
  }

  function progressFor(state, mode, day) {
    const dayRecords = recordsFor(state.records, day, mode);
    const groups = routineGroups(state.settings, mode, day).map((group) => {
      const taken = dayRecords.filter((record) => record.plannedMinutes === group.minutes).length;
      return { ...group, taken, remaining: Math.max(0, group.count - taken) };
    });
    const total = groups.reduce((sum, group) => sum + group.count, 0);
    const done = groups.reduce((sum, group) => sum + Math.min(group.taken, group.count), 0);
    return { groups, total, done, extra: dayRecords.length - done, complete: total > 0 && done >= total };
  }

  function dayComplete(state, day) {
    return ["long", "short"].some((mode) => progressFor(state, mode, day).complete);
  }

  // Días que no rompen la racha: marcados como libres o sin jornada en el horario semanal.
  function isRestDay(state, day) {
    if ((state.daysOff || []).includes(day)) return true;
    if (state.settings.weekProfiles?.[weekStart(day)] === OFF) return true;
    const modes = profileFor(state.settings, day).weekdayModes;
    return modes.some((value) => value !== "none") && modes[weekdayIndex(dateFromKey(day))] === "none";
  }

  // Días comodín: hasta 2 al mes. Un día fallado dentro de una racha en marcha no la rompe.
  const FREEZES_PER_MONTH = 2;
  const freezeCache = new WeakMap();
  function freezeDays(state) {
    const cached = freezeCache.get(state.records);
    if (cached && cached.settings === state.settings && cached.daysOff === state.daysOff) return cached.set;
    const set = new Set();
    if (state.records.length) {
      const today = dateKey(new Date());
      const used = {};
      let run = 0;
      for (let day = state.records.reduce((min, record) => (record.day < min ? record.day : min), today); day < today; day = addDays(day, 1)) {
        if (dayComplete(state, day)) run += 1;
        else if (isRestDay(state, day)) continue;
        else if (run > 0 && (used[day.slice(0, 7)] || 0) < FREEZES_PER_MONTH) {
          used[day.slice(0, 7)] = (used[day.slice(0, 7)] || 0) + 1;
          set.add(day);
        } else run = 0;
      }
    }
    freezeCache.set(state.records, { settings: state.settings, daysOff: state.daysOff, set });
    return set;
  }

  // Días completos seguidos que terminan en `day` (los días de descanso no cuentan ni rompen).
  function runLength(state, day) {
    const earliest = state.records.reduce((min, record) => (record.day < min ? record.day : min), day);
    const freezes = freezeDays(state);
    let cursor = day;
    let run = 0;
    while (cursor >= earliest) {
      if (dayComplete(state, cursor)) run += 1;
      else if (!isRestDay(state, cursor) && !freezes.has(cursor)) break;
      cursor = addDays(cursor, -1);
    }
    return run;
  }

  function currentStreak(state, today = dateKey(new Date())) {
    return dayComplete(state, today) ? runLength(state, today) : runLength(state, addDays(today, -1));
  }

  function todayMode(settings, lastMode, date = new Date()) {
    const modes = profileFor(settings, dateKey(date)).weekdayModes;
    const automatic = modes[weekdayIndex(date)];
    if (automatic !== "none") return automatic;
    return lastMode === "short" ? "short" : "long";
  }

  function recordEnd(record) {
    return record.completedAt || record.startedAt + record.plannedMinutes * MINUTE;
  }

  // Minuto del día en que sueles tomar el 1.º, 2.º, 3.º… descanso (mediana de los últimos 30 días; solo si se repite 4 días o más).
  function habitMinutes(state, mode, day) {
    const since = addDays(day, -30);
    const days = new Map();
    for (const record of state.records) {
      if (record.mode !== mode || record.day >= day || record.day < since) continue;
      if (!days.has(record.day)) days.set(record.day, []);
      days.get(record.day).push(record);
    }
    const byOrdinal = [];
    for (const list of days.values()) {
      list.sort((a, b) => a.startedAt - b.startedAt).forEach((record, index) => {
        const date = new Date(record.startedAt);
        (byOrdinal[index] ||= []).push(date.getHours() * 60 + date.getMinutes());
      });
    }
    return byOrdinal.map((list) => (list.length >= 4 ? list.sort((a, b) => a - b)[Math.floor(list.length / 2)] : null));
  }

  // Coloca los descansos más largos en los huecos más cercanos a la mitad de la jornada.
  function assignDurations(slots, remaining, start, end) {
    const middle = start + (end - start) / 2;
    const slotOrder = slots.map((time, index) => index).sort((a, b) => Math.abs(slots[a] - middle) - Math.abs(slots[b] - middle));
    const durations = [...remaining].sort((a, b) => b - a);
    const assigned = [];
    slotOrder.forEach((slotIndex, position) => { assigned[slotIndex] = durations[position]; });
    return slots.map((time, index) => ({ time, minutes: assigned[index] }));
  }

  // Calcula a qué hora tomar cada descanso pendiente según el horario de la semana:
  //   spread   → repartidos de forma equilibrada hasta la hora límite o el fin de jornada;
  //   interval → uno cada X minutos desde el último descanso (o desde el inicio);
  //   fixed    → a las horas que hayas escrito.
  // Tiene en cuenta turnos de noche, la pausa de comida y los cambios puntuales de un día.
  function planDay(state, mode, now = Date.now()) {
    const day = workDay(state.settings, now);
    const profile = profileFor(state.settings, day);
    const { start, shiftEnd, limit, end, pause } = shiftWindow(state.settings, mode, day);
    const progress = progressFor(state, mode, day);
    const taken = recordsFor(state.records, day, mode);
    const remaining = progress.groups.flatMap((group) => Array(group.remaining).fill(group.minutes));
    const base = { day, start, end, shiftEnd, limit, pause, taken, progress, items: [], profile, planMode: profile.plan.mode };

    if (!progress.total) return { ...base, status: "empty" };
    if (!remaining.length) return { ...base, status: "complete" };
    // En días libres no hay sugerencias ni avisos.
    if (isRestDay(state, day)) return { ...base, status: "off", markedOff: (state.daysOff || []).includes(day) };
    if (now >= end) return { ...base, status: "after" };
    if (shiftEnd <= start || end <= start) return { ...base, status: "invalid" };

    const last = taken[taken.length - 1];
    const anchor = last ? Math.max(recordEnd(last), start) : start;
    const roundTo5 = (time) => Math.round(time / (5 * MINUTE)) * 5 * MINUTE;
    // "Tiempo de trabajo": la pausa de comida no cuenta, así que los descansos se reparten sin ella.
    const gapLength = pause ? pause.end - pause.start : 0;
    const toWork = (time) => (!pause || time <= pause.start ? time : time >= pause.end ? time - gapLength : pause.start);
    const fromWork = (work) => (!pause || work < pause.start ? work : work + gapLength);
    const outOfPause = (time) => (pause && time >= pause.start && time < pause.end ? pause.end : time);
    let items;
    let learned = false;

    if (profile.plan.mode === "fixed") {
      // Cada descanso tomado "cubre" la primera hora fija pendiente de su misma duración.
      const pendingByMinutes = new Map();
      for (const record of taken) pendingByMinutes.set(record.plannedMinutes, (pendingByMinutes.get(record.plannedMinutes) || 0) + 1);
      items = profile.plan.fixed[mode]
        .map((slot) => {
          let time = timestampFor(day, slot.time);
          if (time < start) time += DAY;
          return { time, minutes: slot.minutes };
        })
        .sort((a, b) => a.time - b.time)
        .filter((slot) => slot.time < end)
        .filter((slot) => {
          const covered = pendingByMinutes.get(slot.minutes) || 0;
          if (covered > 0) {
            pendingByMinutes.set(slot.minutes, covered - 1);
            return false;
          }
          return true;
        });
    } else if (profile.plan.mode === "interval") {
      const interval = profile.plan.interval * MINUTE;
      const slots = [];
      for (let work = Math.max(toWork(anchor) + interval, toWork(now)); slots.length < remaining.length; work += interval) {
        const time = fromWork(work);
        if (time >= end) break;
        slots.push(slots.length === 0 ? time : outOfPause(roundTo5(time)));
      }
      // Si no caben todos antes del final de la jornada, se priorizan los descansos largos.
      items = assignDurations(slots, [...remaining].sort((a, b) => b - a).slice(0, slots.length), start, end);
    } else {
      const anchorWork = toWork(anchor);
      const endWork = toWork(end);
      const nowWork = toWork(now);
      let gap = (endWork - anchorWork) / (remaining.length + 1);
      let firstWork = anchorWork + gap;
      const late = firstWork <= nowWork;
      if (late) {
        firstWork = nowWork;
        gap = (endWork - nowWork) / remaining.length;
      }
      let slots = remaining.map((_, index) => outOfPause(index === 0 && late ? fromWork(firstWork) : roundTo5(fromWork(firstWork + gap * index))));
      if (state.settings.learnHabits !== false) {
        // Acerca cada hora sugerida a la hora en la que sueles tomar ese mismo descanso.
        const habit = habitMinutes(state, mode, day);
        const midnight = timestampFor(day, "00:00");
        let previous = anchor;
        slots = slots.map((time, index) => {
          const usual = habit[taken.length + index];
          let adjusted = usual == null || time <= now ? time : roundTo5((time + midnight + usual * MINUTE) / 2);
          adjusted = outOfPause(Math.min(Math.max(adjusted, previous + 5 * MINUTE, now), end - 5 * MINUTE));
          previous = adjusted;
          if (adjusted !== time) learned = true;
          return adjusted;
        });
      }
      items = assignDurations(slots, remaining, start, end);
    }

    items = items.filter((item) => item.time < end);
    if (!items.length) return { ...base, status: now >= end ? "after" : "no-slots" };
    const late = items[0].time <= now;
    return { ...base, status: "ok", items, late, next: items[0], learned };
  }

  function createBreak(mode, minutes, timerEnabled, now = Date.now(), day = dateKey(new Date(now))) {
    const record = {
      id: crypto.randomUUID(),
      day,
      mode,
      startedAt: now,
      plannedMinutes: minutes,
      completedAt: null
    };
    const activeTimer = timerEnabled
      ? { recordId: record.id, startedAt: now, endAt: now + minutes * MINUTE, minutes }
      : null;
    return { record, activeTimer };
  }

  function closeActive(records, activeTimer, completedAt) {
    return records.map((record) =>
      record.id === activeTimer.recordId && !record.completedAt ? { ...record, completedAt } : record
    );
  }

  function overtimeMinutes(record) {
    if (!record.completedAt) return 0;
    return Math.max(0, Math.round((record.completedAt - record.startedAt) / MINUTE - record.plannedMinutes));
  }

  // Alarga el descanso en curso; si ya te habías pasado, los minutos se cuentan desde ahora.
  function extendTimer(timer, minutes, now = Date.now()) {
    const endAt = Math.max(timer.endAt, now) + minutes * MINUTE;
    return { ...timer, endAt, extraMinutes: Math.round((endAt - timer.startedAt) / MINUTE) - timer.minutes };
  }

  // Resumen de una semana (lunes a domingo) para el aviso del domingo.
  function weekSummary(state, week) {
    const days = Array.from({ length: 7 }, (_, index) => addDays(week, index));
    const records = state.records.filter((record) => days.includes(record.day));
    const finished = records.filter((record) => record.completedAt);
    return {
      week,
      breaks: records.length,
      minutes: records.reduce((sum, record) => sum + record.plannedMinutes, 0),
      completeDays: days.filter((day) => dayComplete(state, day)).length,
      punctual: finished.length ? Math.round((finished.filter((record) => overtimeMinutes(record) === 0).length / finished.length) * 100) : null,
      streak: currentStreak(state, days[6])
    };
  }

  // Retos suaves: cada uno desbloqueado planta una flor dorada en el jardín.
  function challenges(state) {
    const freezes = freezeDays(state);
    const days = [...new Set(state.records.map((record) => record.day))].sort();
    const complete = new Set(days.filter((day) => dayComplete(state, day)));
    let run = 0;
    let bestStreak = 0;
    for (let day = days[0]; day && day <= days[days.length - 1]; day = addDays(day, 1)) {
      if (complete.has(day)) bestStreak = Math.max(bestStreak, (run += 1));
      else if (!isRestDay(state, day) && !freezes.has(day)) run = 0;
    }
    let punctualRun = 0;
    let bestPunctual = 0;
    for (const day of days) {
      const finished = state.records.filter((record) => record.day === day && record.completedAt);
      if (finished.length && finished.every((record) => overtimeMinutes(record) === 0)) bestPunctual = Math.max(bestPunctual, (punctualRun += 1));
      else if (finished.length) punctualRun = 0;
    }
    const list = [
      { id: "streak3", title: "Tres días seguidos", desc: "Completa la rutina 3 días seguidos", value: bestStreak, target: 3 },
      { id: "streak7", title: "Una semana entera", desc: "Completa la rutina 7 días seguidos", value: bestStreak, target: 7 },
      { id: "streak14", title: "Dos semanas", desc: "Completa la rutina 14 días seguidos", value: bestStreak, target: 14 },
      { id: "punctual5", title: "Siempre puntual", desc: "5 días seguidos sin pasarte del tiempo", value: bestPunctual, target: 5 },
      { id: "breaks100", title: "100 descansos", desc: "Registra 100 descansos", value: state.records.length, target: 100 },
      { id: "days30", title: "30 días completos", desc: "Completa la rutina 30 días", value: complete.size, target: 30 }
    ];
    return list.map((item) => ({ ...item, value: Math.min(item.value, item.target), done: item.value >= item.target }));
  }

  global.PausaCore = {
    freezeDays, FREEZES_PER_MONTH,
    OFF, workDay, shiftWindow, hoursFor, rotationProfileId, weekKind,
    extendTimer, weekSummary, challenges, habitMinutes,
    MINUTE, STALE_MINUTES, MODE_NAMES, THEME_ACCENT, THEME_WARN, DEFAULT_ROUTINES, DEFAULT_HOURS, DEFAULT_BREAK_UNTIL, DEFAULT_PROFILE, DEFAULT_SETTINGS,
    mergeProfile, weekStart, profileFor,
    dateKey, dateFromKey, addDays, timestampFor, weekdayIndex, mergeSettings, recordsFor, routineGroups,
    routineMinutes, progressFor, dayComplete, isRestDay, runLength, currentStreak, todayMode, recordEnd,
    planDay, createBreak, closeActive, overtimeMinutes
  };
})(globalThis);
