// 100 frases para la vuelta de cada descanso. Se muestran en orden aleatorio sin repetirse
// hasta que han salido todas.
(function (global) {
  const QUOTES = [
    ["La vida es como montar en bicicleta: para mantener el equilibrio hay que seguir avanzando.", "Albert Einstein"],
    ["El descanso no es ociosidad. Tumbarse en la hierba bajo los árboles en un día de verano no es una pérdida de tiempo.", "John Lubbock"],
    ["Casi todo vuelve a funcionar si lo desconectas unos minutos. Incluido tú.", "Anne Lamott"],
    ["El arte de descansar es una parte del arte de trabajar.", "John Steinbeck"],
    ["Descansa: un campo que ha descansado da una cosecha abundante.", "Ovidio"],
    ["El mejor momento para relajarse es cuando no tienes tiempo para ello.", "Sydney J. Harris"],
    ["El descanso es la dulce salsa del trabajo.", "Plutarco"],
    ["Sonríe, respira y ve despacio.", "Thich Nhat Hanh"],
    ["La paz está en cada paso.", "Thich Nhat Hanh"],
    ["Los sentimientos vienen y van como nubes en un cielo con viento. La respiración consciente es mi ancla.", "Thich Nhat Hanh"],
    ["Todos los grandes pensamientos se conciben caminando.", "Friedrich Nietzsche"],
    ["Caminar es la mejor medicina del ser humano.", "Hipócrates"],
    ["En cada paseo por la naturaleza uno recibe mucho más de lo que busca.", "John Muir"],
    ["Mira profundamente la naturaleza y entonces comprenderás todo mejor.", "Albert Einstein"],
    ["Adopta el ritmo de la naturaleza: su secreto es la paciencia.", "Ralph Waldo Emerson"],
    ["Escribe en tu corazón que cada día es el mejor día del año.", "Ralph Waldo Emerson"],
    ["Nuestra vida se desperdicia en detalles. Simplifica, simplifica.", "Henry David Thoreau"],
    ["Si uno avanza con confianza en la dirección de sus sueños, encontrará un éxito inesperado.", "Henry David Thoreau"],
    ["Menos es más.", "Ludwig Mies van der Rohe"],
    ["La perfección se alcanza no cuando no hay nada más que añadir, sino cuando no queda nada que quitar.", "Antoine de Saint-Exupéry"],
    ["Lo esencial es invisible a los ojos.", "Antoine de Saint-Exupéry"],
    ["Caminante, no hay camino, se hace camino al andar.", "Antonio Machado"],
    ["Hoy es siempre todavía.", "Antonio Machado"],
    ["Un viaje de mil millas comienza con un solo paso.", "Lao-Tse"],
    ["No es que tengamos poco tiempo, sino que perdemos mucho.", "Séneca"],
    ["Mientras esperamos para vivir, la vida pasa.", "Séneca"],
    ["La suerte es lo que sucede cuando la preparación se encuentra con la oportunidad.", "Séneca"],
    ["La felicidad de tu vida depende de la calidad de tus pensamientos.", "Marco Aurelio"],
    ["Tienes poder sobre tu mente, no sobre lo que ocurre fuera. Date cuenta de esto y encontrarás la fuerza.", "Marco Aurelio"],
    ["No nos perturban las cosas, sino las opiniones que tenemos de ellas.", "Epicteto"],
    ["Una vida sin examen no merece la pena ser vivida.", "Sócrates"],
    ["Somos lo que hacemos repetidamente. La excelencia no es un acto, sino un hábito.", "Will Durant"],
    ["Cuida tu cuerpo. Es el único lugar que tienes para vivir.", "Jim Rohn"],
    ["La disciplina es el puente entre las metas y los logros.", "Jim Rohn"],
    ["Mente sana en cuerpo sano.", "Juvenal"],
    ["El genio es un uno por ciento de inspiración y un noventa y nueve por ciento de transpiración.", "Thomas Edison"],
    ["No he fracasado. He encontrado diez mil maneras que no funcionan.", "Thomas Edison"],
    ["La inspiración existe, pero tiene que encontrarte trabajando.", "Pablo Picasso"],
    ["Pies, ¿para qué os quiero si tengo alas para volar?", "Frida Kahlo"],
    ["Pinto flores para que así no mueran.", "Frida Kahlo"],
    ["Siempre hay flores para quienes quieren verlas.", "Henri Matisse"],
    ["Podrán cortar todas las flores, pero no podrán detener la primavera.", "Pablo Neruda"],
    ["Las grandes cosas no se hacen por impulso, sino por una serie de pequeñas cosas reunidas.", "Vincent van Gogh"],
    ["¿Qué sería de la vida si no tuviéramos el valor de intentar algo?", "Vincent van Gogh"],
    ["Bien hecho es mejor que bien dicho.", "Benjamin Franklin"],
    ["Quien tiene paciencia obtendrá lo que desea.", "Benjamin Franklin"],
    ["Haz lo que puedas, con lo que tengas, donde estés.", "Theodore Roosevelt"],
    ["La única manera de hacer un gran trabajo es amar lo que haces.", "Steve Jobs"],
    ["Tu tiempo es limitado, así que no lo malgastes viviendo la vida de otro.", "Steve Jobs"],
    ["La mitad de lo que separa a quien triunfa de quien no lo hace es la perseverancia.", "Steve Jobs"],
    ["La mejor manera de predecir el futuro es inventarlo.", "Alan Kay"],
    ["En lo más profundo del invierno aprendí por fin que había en mí un verano invencible.", "Albert Camus"],
    ["Hay que imaginarse a Sísifo feliz.", "Albert Camus"],
    ["Somos del tamaño de nuestros sueños.", "Fernando Pessoa"],
    ["La vida no es la que uno vivió, sino la que uno recuerda y cómo la recuerda para contarla.", "Gabriel García Márquez"],
    ["La diligencia es madre de la buena ventura.", "Miguel de Cervantes"],
    ["El que lee mucho y anda mucho, ve mucho y sabe mucho.", "Miguel de Cervantes"],
    ["Confía en el tiempo, que suele dar dulces salidas a muchas amargas dificultades.", "Miguel de Cervantes"],
    ["Estamos hechos de la misma materia que los sueños.", "William Shakespeare"],
    ["Nuestras dudas son traidoras y nos hacen perder el bien que podríamos ganar por miedo a intentarlo.", "William Shakespeare"],
    ["Si he visto más lejos es porque estoy sentado sobre hombros de gigantes.", "Isaac Newton"],
    ["Dadme un punto de apoyo y moveré el mundo.", "Arquímedes"],
    ["Nada en la vida debe ser temido, solo comprendido.", "Marie Curie"],
    ["La vida no es fácil para ninguno de nosotros. Hay que perseverar y, sobre todo, tener confianza en uno mismo.", "Marie Curie"],
    ["Lo importante es no dejar de hacerse preguntas.", "Albert Einstein"],
    ["Quien nunca ha cometido un error nunca ha intentado nada nuevo.", "Albert Einstein"],
    ["En medio de la dificultad reside la oportunidad.", "Albert Einstein"],
    ["La imaginación es más importante que el conocimiento.", "Albert Einstein"],
    ["Mira hacia las estrellas y no hacia tus pies.", "Stephen Hawking"],
    ["Si no puedes volar, corre; si no puedes correr, camina; si no puedes caminar, gatea. Pero sigue adelante.", "Martin Luther King Jr."],
    ["Da el primer paso con fe. No tienes que ver toda la escalera, solo el primer peldaño.", "Martin Luther King Jr."],
    ["Una buena cabeza y un buen corazón son siempre una combinación formidable.", "Nelson Mandela"],
    ["En la vida hay más cosas que aumentar su velocidad.", "Mahatma Gandhi"],
    ["La fuerza no proviene de la capacidad física, sino de una voluntad indomable.", "Mahatma Gandhi"],
    ["No cuentes los días: haz que los días cuenten.", "Muhammad Ali"],
    ["Flota como una mariposa, pica como una abeja.", "Muhammad Ali"],
    ["He fallado una y otra vez en mi vida. Por eso tengo éxito.", "Michael Jordan"],
    ["Fallas el cien por cien de los tiros que no intentas.", "Wayne Gretzky"],
    ["Haz de cada día tu obra maestra.", "John Wooden"],
    ["No dejes que lo que no puedes hacer interfiera con lo que puedes hacer.", "John Wooden"],
    ["Nunca te rindas. Nunca, nunca, nunca.", "Winston Churchill"],
    ["No puedes cruzar el mar simplemente mirando el agua.", "Rabindranath Tagore"],
    ["La fe es el pájaro que siente la luz y canta cuando el amanecer aún está oscuro.", "Rabindranath Tagore"],
    ["Quien mira hacia fuera, sueña; quien mira hacia dentro, despierta.", "Carl Jung"],
    ["El optimismo es la fe que conduce al logro.", "Helen Keller"],
    ["La vida es una aventura atrevida o no es nada.", "Helen Keller"],
    ["Nada funcionará a menos que tú lo hagas.", "Maya Angelou"],
    ["Si no te gusta algo, cámbialo. Si no puedes cambiarlo, cambia tu actitud.", "Maya Angelou"],
    ["El secreto para salir adelante es empezar.", "Mark Twain"],
    ["La mejor manera de animarte es intentar animar a otra persona.", "Mark Twain"],
    ["Vivir es lo más raro del mundo. La mayoría de la gente solo existe.", "Oscar Wilde"],
    ["Lo que la oruga llama el fin del mundo, el maestro lo llama mariposa.", "Richard Bach"],
    ["Respira. Suelta. Y recuerda que este momento es el único que sabes con certeza que tienes.", "Oprah Winfrey"],
    ["La calma mental es una de las joyas más hermosas de la sabiduría.", "James Allen"],
    ["La vida es un diez por ciento lo que te ocurre y un noventa por ciento cómo reaccionas.", "Charles R. Swindoll"],
    ["Lo que no me mata me hace más fuerte.", "Friedrich Nietzsche"],
    ["La vida es lo que te pasa mientras estás ocupado haciendo otros planes.", "John Lennon"],
    ["La felicidad no es algo hecho. Proviene de tus propias acciones.", "Dalái Lama"],
    ["Nuestra mayor gloria no está en no caer nunca, sino en levantarnos cada vez que caemos.", "Oliver Goldsmith"],
    ["El hierro se oxida si no se usa; así también la inacción echa a perder el intelecto.", "Leonardo da Vinci"]
  ].map(([text, author]) => ({ text, author }));

  function shuffledOrder() {
    const order = QUOTES.map((_, index) => index);
    for (let index = order.length - 1; index > 0; index -= 1) {
      const swap = Math.floor(Math.random() * (index + 1));
      [order[index], order[swap]] = [order[swap], order[index]];
    }
    return order;
  }

  // Devuelve la siguiente frase y el mazo actualizado. Al acabarse, se baraja de nuevo.
  function drawQuote(deck) {
    let order = Array.isArray(deck?.order) && deck.order.length === QUOTES.length ? deck.order : shuffledOrder();
    let position = Number.isInteger(deck?.position) ? deck.position : 0;
    if (position >= order.length) {
      order = shuffledOrder();
      position = 0;
    }
    const index = order[position];
    return { index, deck: { order, position: position + 1 } };
  }

  global.PausaQuotes = { QUOTES, drawQuote };
})(globalThis);
