importScripts("core.js", "quotes.js", "telegram.js");

const Core = PausaCore;
// Tras un aviso de la hora sugerida, no vuelve a avisar hasta pasado este tiempo.
const SUGGEST_COOLDOWN = 10 * Core.MINUTE;

async function loadState() {
  const saved = await chrome.storage.local.get(["settings", "records", "activeTimer", "daysOff", "lastMode", "lastSuggestAt", "returnQuote"]);
  return {
    settings: Core.mergeSettings(saved.settings),
    records: Array.isArray(saved.records) ? saved.records : [],
    activeTimer: saved.activeTimer || null,
    daysOff: Array.isArray(saved.daysOff) ? saved.daysOff : [],
    lastMode: saved.lastMode,
    lastSuggestAt: saved.lastSuggestAt || 0,
    returnQuote: saved.returnQuote || null
  };
}

async function ensurePeriodicAlarm(name, periodInMinutes) {
  const existing = await chrome.alarms.get(name);
  if (!existing || existing.periodInMinutes !== periodInMinutes) {
    await chrome.alarms.create(name, { delayInMinutes: periodInMinutes, periodInMinutes });
  }
}

async function updateBadge(state) {
  const now = Date.now();
  const accent = Core.THEME_ACCENT[state.settings.theme];
  let text = "";
  let color = accent;

  if (state.activeTimer) {
    const remaining = state.activeTimer.endAt - now;
    if (remaining > 0) {
      text = `${Math.ceil(remaining / Core.MINUTE)}m`;
    } else {
      text = `+${Math.floor(-remaining / Core.MINUTE)}`;
      color = Core.THEME_WARN[state.settings.theme];
    }
  } else {
    const mode = Core.todayMode(state.settings, state.lastMode);
    const progress = Core.progressFor(state, mode, Core.dateKey(new Date()));
    if (progress.total) text = progress.complete ? "✓" : String(progress.total - progress.done);
  }
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
  if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: "#FFFFFF" });
}

function formatTime(timestamp) {
  return new Date(timestamp).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}

function wantsPhone(settings, key) {
  return PausaTelegram.isLinked(settings.telegram) && settings.telegram[key];
}

// Recalcula alarmas e insignia a partir del estado guardado.
async function sync() {
  const state = await loadState();
  const now = Date.now();
  const timer = state.activeTimer;

  if (timer) {
    const staleAt = timer.endAt + Core.STALE_MINUTES * Core.MINUTE;
    if (now >= staleAt) {
      // El cambio en storage vuelve a llamar a sync().
      await closeWithQuote(state, timer.endAt);
      return;
    }
    if (timer.endAt > now) await chrome.alarms.create("break-end", { when: timer.endAt });
    else await chrome.alarms.clear("break-end");
    const overtimeAt = timer.endAt + state.settings.overtimeAlert * Core.MINUTE;
    if (wantsPhone(state.settings, "onOvertime") && overtimeAt > now) await chrome.alarms.create("overtime", { when: overtimeAt });
    else await chrome.alarms.clear("overtime");
    await chrome.alarms.create("break-stale", { when: staleAt });
  } else {
    await chrome.alarms.clear("break-end");
    await chrome.alarms.clear("overtime");
    await chrome.alarms.clear("break-stale");
  }

  await chrome.alarms.clear("suggest");
  if ((state.settings.suggestAlert || wantsPhone(state.settings, "onSuggest")) && !timer) {
    const plan = Core.planDay(state, Core.todayMode(state.settings, state.lastMode), now);
    if (plan.status === "ok") {
      // A la hora exacta (menos la antelación elegida), sin márgenes que lo retrasen.
      const when = Math.max(plan.next.time - state.settings.suggestLead * Core.MINUTE, now + 5000, state.lastSuggestAt + SUGGEST_COOLDOWN);
      if (when < plan.end) await chrome.alarms.create("suggest", { when });
    }
  }

  // Refresca la insignia: cada 30 s durante un descanso y de vez en cuando el resto del día.
  await ensurePeriodicAlarm("tick", timer ? 0.5 : 15);
  await updateBadge(state);
}

async function notify(title, message) {
  const granted = await chrome.permissions.contains({ permissions: ["notifications"] });
  if (granted) chrome.notifications.create({ type: "basic", iconUrl: "icons/icon-128.png", title, message });
}

async function phone(settings, text) {
  try {
    await PausaTelegram.send(settings.telegram, text);
  } catch (error) {
    console.warn("No se pudo enviar el aviso a Telegram:", error.message);
  }
}

async function playSound(sound) {
  if (!sound || sound === "none" || !chrome.offscreen) return;
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (!contexts.length) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Sonido suave al terminar un descanso"
    });
  }
  await chrome.runtime.sendMessage({ target: "offscreen", type: "play", sound }).catch(() => {});
}

async function startSuggestedBreak() {
  const state = await loadState();
  if (state.activeTimer) {
    await notify("Ya tienes un descanso en curso", "Pulsa Alt+Shift+V cuando vuelvas.");
    return;
  }
  const mode = Core.todayMode(state.settings, state.lastMode);
  const plan = Core.planDay(state, mode);
  const minutes = plan.next?.minutes ?? plan.progress.groups.find((group) => group.remaining > 0)?.minutes;
  if (!minutes) {
    await notify("Rutina completa", "Ya registraste todos los descansos de hoy.");
    return;
  }
  const { record, activeTimer } = Core.createBreak(mode, minutes, state.settings.timerEnabled);
  await chrome.storage.local.set({ records: [...state.records, record], activeTimer, returnQuote: null });
  await notify("Descanso iniciado", `${minutes} min · ${Core.MODE_NAMES[mode]}`);
}

// La frase de un descanso se elige una sola vez: la misma llega al móvil y aparece al volver.
async function quoteFor(state, recordId) {
  if (state.returnQuote?.recordId === recordId) return PausaQuotes.QUOTES[state.returnQuote.index];
  const { quoteDeck } = await chrome.storage.local.get("quoteDeck");
  const { index, deck } = PausaQuotes.drawQuote(quoteDeck);
  state.returnQuote = { index, recordId, at: Date.now() };
  await chrome.storage.local.set({ quoteDeck: deck, returnQuote: state.returnQuote });
  return PausaQuotes.QUOTES[index];
}

// Cierra el descanso en curso; la frase queda lista para cuando abras la extensión.
async function closeWithQuote(state, completedAt) {
  const quote = await quoteFor(state, state.activeTimer.recordId);
  await chrome.storage.local.set({
    records: Core.closeActive(state.records, state.activeTimer, completedAt),
    activeTimer: null
  });
  return quote;
}

async function finishBreak() {
  const state = await loadState();
  if (!state.activeTimer) return;
  const quote = await closeWithQuote(state, Date.now());
  await notify("De vuelta", `«${quote.text}» — ${quote.author}`);
}

chrome.runtime.onInstalled.addListener(sync);
chrome.runtime.onStartup.addListener(sync);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.settings || changes.records || changes.activeTimer || changes.lastMode || changes.lastSuggestAt || changes.daysOff)) sync();
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "start-break") startSuggestedBreak();
  else if (command === "finish-break") finishBreak();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const state = await loadState();
  const timer = state.activeTimer;
  if (alarm.name === "break-end") {
    if (!timer) return;
    await playSound(state.settings.sound);
    if (state.settings.endAlert) {
      await notify("Tu descanso terminó", `Han pasado ${timer.minutes} min. Cuando vuelvas, pulsa "Ya volví".`);
    }
    if (wantsPhone(state.settings, "onEnd")) {
      const quote = await quoteFor(state, timer.recordId);
      await phone(state.settings, `⏰ Tu descanso de ${timer.minutes} min terminó.\n\n«${quote.text}»\n— ${quote.author}\n\nCuando vuelvas, pulsa «Ya volví» (Alt+Shift+V).`);
    }
    await updateBadge(state);
  } else if (alarm.name === "overtime") {
    const limit = state.settings.overtimeAlert;
    if (timer && Date.now() >= timer.endAt + limit * Core.MINUTE - 1000 && wantsPhone(state.settings, "onOvertime")) {
      await phone(state.settings, `⌛ Llevas ${limit} min más de lo previsto en tu descanso. ¡Hora de volver!`);
    }
  } else if (alarm.name === "break-stale") {
    await sync();
  } else if (alarm.name === "suggest") {
    const now = Date.now();
    const lead = state.settings.suggestLead * Core.MINUTE;
    const plan = Core.planDay(state, Core.todayMode(state.settings, state.lastMode), now);
    if (!timer && plan.status === "ok" && plan.next.time - lead <= now + 30_000) {
      const { minutes, time } = plan.next;
      const wait = Math.round((time - now) / Core.MINUTE);
      const text = wait >= 1
        ? `En ${wait} min (a las ${formatTime(time)}) te toca un descanso de ${minutes} min.`
        : `Es la hora: te toca un descanso de ${minutes} min.`;
      if (state.settings.suggestAlert) await notify("Buen momento para descansar", text);
      if (wantsPhone(state.settings, "onSuggest")) await phone(state.settings, `🌸 ${text}`);
      await chrome.storage.local.set({ lastSuggestAt: now });
    } else {
      await sync();
    }
  } else if (alarm.name === "tick") {
    await updateBadge(state);
  }
});
