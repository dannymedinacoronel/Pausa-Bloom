importScripts("core.js", "quotes.js", "quotes-en.js", "telegram.js");

const Core = PausaCore;
// Tras un aviso de la hora sugerida, no vuelve a avisar hasta pasado este tiempo.
const SUGGEST_COOLDOWN = 10 * Core.MINUTE;
const SNOOZE_MINUTES = 10;
// Mientras haya un descanso en marcha (o un aviso reciente), se escuchan las respuestas del móvil.
const PHONE_WINDOW = 15 * Core.MINUTE;

// Idioma de los avisos: t("texto en español", "text in English").
let language = "es";
const t = (es, en) => (language === "en" ? en : es);
const quoteText = (quote) => (language === "en" && quote.en ? quote.en : quote.text);
const quoteAuthor = (quote) => (language === "en" && quote.authorEn ? quote.authorEn : quote.author);

async function loadState() {
  const saved = await chrome.storage.local.get(["settings", "records", "activeTimer", "daysOff", "lastMode", "lastSuggestAt", "returnQuote", "snoozeUntil"]);
  const state = {
    settings: Core.mergeSettings(saved.settings),
    records: Array.isArray(saved.records) ? saved.records : [],
    activeTimer: saved.activeTimer || null,
    daysOff: Array.isArray(saved.daysOff) ? saved.daysOff : [],
    lastMode: saved.lastMode,
    lastSuggestAt: saved.lastSuggestAt || 0,
    snoozeUntil: saved.snoozeUntil || 0,
    returnQuote: saved.returnQuote || null
  };
  language = state.settings.language;
  return state;
}

async function ensurePeriodicAlarm(name, periodInMinutes) {
  const existing = await chrome.alarms.get(name);
  if (!existing || existing.periodInMinutes !== periodInMinutes) {
    await chrome.alarms.create(name, { delayInMinutes: periodInMinutes, periodInMinutes });
  }
}

async function updateBadge(state) {
  const now = Date.now();
  const accent = Core.THEME_ACCENT[state.settings.theme];
  let text = "";
  let color = accent;

  if (state.activeTimer) {
    const remaining = state.activeTimer.endAt - now;
    if (remaining > 0) {
      text = `${Math.ceil(remaining / Core.MINUTE)}m`;
    } else {
      text = `+${Math.floor(-remaining / Core.MINUTE)}`;
      color = Core.THEME_WARN[state.settings.theme];
    }
  } else {
    const mode = Core.todayMode(state.settings, state.lastMode);
    const progress = Core.progressFor(state, mode, Core.workDay(state.settings));
    if (progress.total) text = progress.complete ? "✓" : String(progress.total - progress.done);
  }
  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
  if (chrome.action.setBadgeTextColor) await chrome.action.setBadgeTextColor({ color: "#FFFFFF" });
}

function formatTime(timestamp) {
  return new Date(timestamp).toLocaleTimeString(language === "en" ? "en-GB" : "es-ES", { hour: "2-digit", minute: "2-digit" });
}

function wantsPhone(settings, key) {
  return PausaTelegram.isLinked(settings.telegram) && settings.telegram[key];
}

function needsPolling(state, now = Date.now()) {
  return PausaTelegram.isLinked(state.settings.telegram)
    && Boolean(state.activeTimer || now - state.lastSuggestAt < PHONE_WINDOW || state.snoozeUntil > now);
}

// Recalcula alarmas e insignia a partir del estado guardado.
async function sync() {
  const state = await loadState();
  const now = Date.now();
  const timer = state.activeTimer;

  if (timer) {
    const staleAt = timer.endAt + Core.STALE_MINUTES * Core.MINUTE;
    if (now >= staleAt) {
      // El cambio en storage vuelve a llamar a sync().
      await closeWithQuote(state, timer.endAt);
      return;
    }
    if (timer.endAt > now) await chrome.alarms.create("break-end", { when: timer.endAt });
    else await chrome.alarms.clear("break-end");
    const overtimeAt = timer.endAt + state.settings.overtimeAlert * Core.MINUTE;
    if (wantsPhone(state.settings, "onOvertime") && overtimeAt > now) await chrome.alarms.create("overtime", { when: overtimeAt });
    else await chrome.alarms.clear("overtime");
    await chrome.alarms.create("break-stale", { when: staleAt });
  } else {
    await chrome.alarms.clear("break-end");
    await chrome.alarms.clear("overtime");
    await chrome.alarms.clear("break-stale");
  }

  await chrome.alarms.clear("suggest");
  if ((state.settings.suggestAlert || wantsPhone(state.settings, "onSuggest")) && !timer) {
    const plan = Core.planDay(state, Core.todayMode(state.settings, state.lastMode), now);
    if (plan.status === "ok") {
      // A la hora exacta (menos la antelación elegida), sin márgenes que lo retrasen.
      const when = Math.max(plan.next.time - state.settings.suggestLead * Core.MINUTE, now + 5000, state.lastSuggestAt + SUGGEST_COOLDOWN, state.snoozeUntil);
      if (when < plan.end) await chrome.alarms.create("suggest", { when });
    }
  }

  if (needsPolling(state, now)) await ensurePeriodicAlarm("tg-poll", 0.5);
  else await chrome.alarms.clear("tg-poll");
  if (state.settings.eyeReminder) await ensurePeriodicAlarm("eye", 20);
  else await chrome.alarms.clear("eye");
  await ensurePeriodicAlarm("housekeeping", 60);

  // Refresca la insignia: cada 30 s durante un descanso y de vez en cuando el resto del día.
  await ensurePeriodicAlarm("tick", timer ? 0.5 : 15);
  await updateBadge(state);
}

// `buttons` (máximo 2) añade botones a la notificación; ver onButtonClicked más abajo.
async function notify(title, message, { id, buttons } = {}) {
  const granted = await chrome.permissions.contains({ permissions: ["notifications"] });
  if (!granted) return;
  const options = { type: "basic", iconUrl: "icons/icon-128.png", title, message };
  if (buttons) Object.assign(options, { buttons: buttons.map((label) => ({ title: label })), requireInteraction: true });
  if (id) chrome.notifications.create(id, options);
  else chrome.notifications.create(options);
}

// Botones bajo los mensajes de Telegram.
const button = (action) => ({
  back: [t("✅ Ya volví", "✅ I'm back"), "back"],
  plus5: ["➕ 5 min", "plus5"],
  start: [t("▶ Empezar", "▶ Start"), "start"],
  snooze: [t(`⏰ Pospón ${SNOOZE_MINUTES} min`, `⏰ Snooze ${SNOOZE_MINUTES} min`), "snooze"]
}[action]);

async function phone(settings, text, buttons) {
  try {
    await PausaTelegram.send(settings.telegram, text, buttons);
  } catch (error) {
    console.warn("No se pudo enviar el aviso a Telegram:", error.message);
  }
}

async function playSound(sound) {
  if (!sound || sound === "none" || !chrome.offscreen) return;
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (!contexts.length) {
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Sonido suave al terminar un descanso"
    });
  }
  const send = () => chrome.runtime.sendMessage({ target: "offscreen", type: "play", sound });
  // Si el documento aún no estaba listo, se reintenta una vez.
  await send().catch(async () => {
    await new Promise((resolve) => setTimeout(resolve, 300));
    await send().catch(() => {});
  });
}

async function startSuggestedBreak() {
  const state = await loadState();
  if (state.activeTimer) {
    await notify(t("Ya tienes un descanso en curso", "You already have a break running"), t("Pulsa Alt+Shift+V cuando vuelvas.", "Press Alt+Shift+V when you are back."));
    return false;
  }
  const mode = Core.todayMode(state.settings, state.lastMode);
  const plan = Core.planDay(state, mode);
  if (plan.status === "after") {
    await notify(t("Hora límite alcanzada", "Time limit reached"), t(`Ya no puedes iniciar descansos después de las ${formatTime(plan.end)}.`, `You can no longer start breaks after ${formatTime(plan.end)}.`));
    return false;
  }
  if (!["ok", "no-slots"].includes(plan.status)) {
    await notify(t("Sin descansos disponibles", "No breaks available"), t("La rutina está completa o no hay descansos programados.", "Your routine is complete or no breaks are scheduled."));
    return false;
  }
  const minutes = plan.next?.minutes ?? plan.progress.groups.find((group) => group.remaining > 0)?.minutes;
  if (!minutes) {
    await notify(t("Rutina completa", "Routine complete"), t("Ya registraste todos los descansos de hoy.", "You have logged all of today's breaks."));
    return false;
  }
  const { record, activeTimer } = Core.createBreak(mode, minutes, state.settings.timerEnabled, Date.now(), Core.workDay(state.settings));
  await chrome.storage.local.set({ records: [...state.records, record], activeTimer, returnQuote: null, snoozeUntil: 0 });
  await notify(t("Descanso iniciado", "Break started"), `${minutes} min · ${t(Core.MODE_NAMES[mode], mode === "long" ? "Long day" : "Short day")}`);
  return true;
}

// La frase de un descanso se elige una sola vez: la misma llega al móvil y aparece al volver.
async function quoteFor(state, recordId) {
  if (state.returnQuote?.recordId === recordId) return PausaQuotes.QUOTES[state.returnQuote.index];
  const { quoteDeck } = await chrome.storage.local.get("quoteDeck");
  const { index, deck } = PausaQuotes.drawQuote(quoteDeck);
  state.returnQuote = { index, recordId, at: Date.now() };
  await chrome.storage.local.set({ quoteDeck: deck, returnQuote: state.returnQuote });
  return PausaQuotes.QUOTES[index];
}

// Cierra el descanso en curso; la frase queda lista para cuando abras la extensión.
async function closeWithQuote(state, completedAt) {
  const quote = await quoteFor(state, state.activeTimer.recordId);
  await chrome.storage.local.set({
    records: Core.closeActive(state.records, state.activeTimer, completedAt),
    activeTimer: null
  });
  return quote;
}

async function finishBreak() {
  const state = await loadState();
  if (!state.activeTimer) return false;
  const quote = await closeWithQuote(state, Date.now());
  await notify(t("De vuelta", "Welcome back"), `«${quoteText(quote)}» — ${quoteAuthor(quote)}`);
  return true;
}

// ---------- Respuestas desde el móvil (botones de Telegram) ----------

async function runPhoneAction(action, silent = false) {
  const state = await loadState();
  // Si la acción viene de una notificación del ordenador (silent), no se contesta por Telegram.
  const reply = silent ? async () => {} : (text, ...actions) => phone(state.settings, text, actions.map(button));
  if (action === "back") {
    const done = await finishBreak();
    await reply(done ? t("🌿 ¡De vuelta! Descanso registrado.", "🌿 Welcome back! Break logged.") : t("Ya estabas de vuelta ✔", "You were already back ✔"));
  } else if (action === "plus5") {
    if (!state.activeTimer) return reply(t("No hay ningún descanso en curso.", "There is no break running."));
    const timer = Core.extendTimer(state.activeTimer, 5);
    await chrome.storage.local.set({ activeTimer: timer });
    await reply(t(`➕ Descanso alargado: termina a las ${formatTime(timer.endAt)}.`, `➕ Break extended: it ends at ${formatTime(timer.endAt)}.`), "back", "plus5");
  } else if (action === "start") {
    const started = await startSuggestedBreak();
    await reply(started ? t("▶ Descanso iniciado. ¡Disfrútalo!", "▶ Break started. Enjoy it!") : t("No se pudo iniciar el descanso.", "The break could not be started."), ...(started ? ["back", "plus5"] : []));
  } else if (action === "snooze") {
    await chrome.storage.local.set({ snoozeUntil: Date.now() + SNOOZE_MINUTES * Core.MINUTE });
    await reply(t(`⏰ Te aviso de nuevo en ${SNOOZE_MINUTES} minutos.`, `⏰ I'll remind you again in ${SNOOZE_MINUTES} minutes.`));
  }
}

// Pregunta a Telegram si has pulsado algún botón. Va fuera de la cola porque espera hasta 20 s.
let polling = false;
async function pollPhone() {
  if (polling) return;
  polling = true;
  try {
    const state = await loadState();
    const telegram = state.settings.telegram;
    if (!needsPolling(state)) {
      await chrome.alarms.clear("tg-poll");
      return;
    }
    if (!(await PausaTelegram.hasPermission())) return;
    const { tgOffset } = await chrome.storage.local.get("tgOffset");
    const updates = await PausaTelegram.call(telegram.token, "getUpdates", { offset: tgOffset || 0, timeout: 20, allowed_updates: ["callback_query"] });
    for (const update of updates) {
      await chrome.storage.local.set({ tgOffset: update.update_id + 1 });
      const query = update.callback_query;
      // Solo se obedece al chat que conectaste con el QR.
      if (query?.message?.chat?.id !== telegram.chatId) continue;
      await PausaTelegram.call(telegram.token, "answerCallbackQuery", { callback_query_id: query.id }).catch(() => {});
      await PausaTelegram.call(telegram.token, "editMessageReplyMarkup", { chat_id: telegram.chatId, message_id: query.message.message_id, reply_markup: { inline_keyboard: [] } }).catch(() => {});
      enqueue(() => runPhoneAction(query.data));
    }
  } catch (error) {
    console.warn("Telegram:", error.message);
  } finally {
    polling = false;
  }
}

// ---------- Tareas periódicas: copia automática y resumen semanal ----------

async function autoBackup(state) {
  if (!state.settings.autoBackup || !chrome.downloads) return;
  const now = new Date();
  const today = Core.dateKey(now);
  const { lastBackup } = await chrome.storage.local.get("lastBackup");
  const last = lastBackup?.day;
  if (last === today || !(now.getHours() >= 18 || !last || last < Core.addDays(today, -1))) return;
  const data = await chrome.storage.local.get(null);
  for (const key of ["activeTimer", "telegramDraft", "lastBackup"]) delete data[key];
  const json = JSON.stringify({ app: "pausa-bloom", version: 4, exportedAt: now.toISOString(), data }, null, 2);
  const weekday = ["domingo", "lunes", "martes", "miercoles", "jueves", "viernes", "sabado"][now.getDay()];
  // Siete archivos que se van sobrescribiendo: siempre tienes la última semana.
  await chrome.downloads.download({
    url: `data:application/json;charset=utf-8,${encodeURIComponent(json)}`,
    filename: `Pausa Bloom/copia-${weekday}.json`,
    conflictAction: "overwrite",
    saveAs: false
  });
  await chrome.storage.local.set({ lastBackup: { day: today, at: Date.now() } });
}

async function weeklySummary(state) {
  const now = new Date();
  if (!state.settings.weeklySummary || now.getDay() !== 0 || now.getHours() < 20) return;
  const week = Core.weekStart(Core.dateKey(now));
  const { lastWeekly } = await chrome.storage.local.get("lastWeekly");
  if (lastWeekly === week) return;
  await chrome.storage.local.set({ lastWeekly: week });
  const summary = Core.weekSummary(state, week);
  if (!summary.breaks) return;
  const text = t(
    `Tu semana: ${summary.breaks} descansos (${summary.minutes} min), ${summary.completeDays} días con la rutina completa${summary.punctual === null ? "" : `, ${summary.punctual} % puntual`}. Racha: ${summary.streak} días.`,
    `Your week: ${summary.breaks} breaks (${summary.minutes} min), ${summary.completeDays} days with the full routine${summary.punctual === null ? "" : `, ${summary.punctual}% on time`}. Streak: ${summary.streak} days.`
  );
  await notify(t("Resumen de tu semana", "Your weekly summary"), text);
  if (PausaTelegram.isLinked(state.settings.telegram)) await phone(state.settings, `📊 ${text}`);
}

async function housekeeping() {
  const state = await loadState();
  await autoBackup(state).catch((error) => console.warn("Copia automática:", error.message));
  await weeklySummary(state).catch((error) => console.warn("Resumen semanal:", error.message));
}

// ---------- Cola de tareas y eventos ----------

// Todo el trabajo del segundo plano va en cola: dos eventos seguidos no se pisan.
let queue = Promise.resolve();
function enqueue(task) {
  queue = queue.then(task).catch((error) => console.warn("Pausa Bloom:", error));
  return queue;
}
let syncQueued = false;
function requestSync() {
  if (syncQueued) return;
  syncQueued = true;
  enqueue(async () => {
    syncQueued = false;
    await sync();
  });
}
function start() {
  requestSync();
  enqueue(housekeeping);
}

chrome.runtime.onInstalled.addListener(start);
chrome.runtime.onStartup.addListener(start);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.settings || changes.records || changes.activeTimer || changes.lastMode || changes.lastSuggestAt || changes.snoozeUntil || changes.daysOff)) requestSync();
});

// Botones de las notificaciones del ordenador.
chrome.notifications.onButtonClicked.addListener((id, index) => {
  const action = { "pb-end": ["back", "plus5"], "pb-suggest": ["start", "snooze"] }[id]?.[index];
  if (!action) return;
  chrome.notifications.clear(id);
  enqueue(() => runPhoneAction(action, true));
});

chrome.commands.onCommand.addListener((command) => {
  if (command === "start-break") enqueue(startSuggestedBreak);
  else if (command === "finish-break") enqueue(finishBreak);
});

async function handleAlarm(alarm) {
  const state = await loadState();
  const timer = state.activeTimer;
  if (alarm.name === "break-end") {
    if (!timer) return;
    await playSound(state.settings.sound);
    if (state.settings.endAlert) {
      await notify(t("Tu descanso terminó", "Your break is over"), t(`Han pasado ${timer.minutes} min. Cuando vuelvas, pulsa "Ya volví".`, `${timer.minutes} min have passed. When you are back, press "I'm back".`), { id: "pb-end", buttons: [t("✅ Ya volví", "✅ I'm back"), "➕ 5 min"] });
    }
    if (wantsPhone(state.settings, "onEnd")) {
      const quote = await quoteFor(state, timer.recordId);
      await phone(
        state.settings,
        t(`⏰ Tu descanso de ${timer.minutes} min terminó.\n\n«${quoteText(quote)}»\n— ${quoteAuthor(quote)}`, `⏰ Your ${timer.minutes}-min break is over.\n\n«${quoteText(quote)}»\n— ${quoteAuthor(quote)}`),
        [button("back"), button("plus5")]
      );
    }
    await updateBadge(state);
  } else if (alarm.name === "overtime") {
    const limit = state.settings.overtimeAlert;
    if (timer && Date.now() >= timer.endAt + limit * Core.MINUTE - 1000 && wantsPhone(state.settings, "onOvertime")) {
      await phone(
        state.settings,
        t(`⌛ Llevas ${limit} min más de lo previsto en tu descanso. ¡Hora de volver!`, `⌛ You are ${limit} min past your break. Time to get back!`),
        [button("back"), button("plus5")]
      );
    }
  } else if (alarm.name === "break-stale") {
    await sync();
  } else if (alarm.name === "suggest") {
    const now = Date.now();
    const lead = state.settings.suggestLead * Core.MINUTE;
    const plan = Core.planDay(state, Core.todayMode(state.settings, state.lastMode), now);
    if (!timer && plan.status === "ok" && plan.next.time - lead <= now + 30_000) {
      const { minutes, time } = plan.next;
      const wait = Math.round((time - now) / Core.MINUTE);
      const text = wait >= 1
        ? t(`En ${wait} min (a las ${formatTime(time)}) te toca un descanso de ${minutes} min.`, `In ${wait} min (at ${formatTime(time)}) it is time for a ${minutes}-min break.`)
        : t(`Es la hora: te toca un descanso de ${minutes} min.`, `It is time: you are due a ${minutes}-min break.`);
      if (state.settings.suggestAlert) await notify(t("Buen momento para descansar", "Good time for a break"), text, { id: "pb-suggest", buttons: [t("▶ Empezar", "▶ Start"), t(`⏰ Pospón ${SNOOZE_MINUTES} min`, `⏰ Snooze ${SNOOZE_MINUTES} min`)] });
      if (wantsPhone(state.settings, "onSuggest")) await phone(state.settings, `🌸 ${text}`, [button("start"), button("snooze")]);
      await chrome.storage.local.set({ lastSuggestAt: now, snoozeUntil: 0 });
    } else {
      await sync();
    }
  } else if (alarm.name === "eye") {
    const now = Date.now();
    const day = Core.workDay(state.settings, now);
    if (!state.settings.eyeReminder || timer || Core.isRestDay(state, day)) return;
    const { start, shiftEnd, pause } = Core.shiftWindow(state.settings, Core.todayMode(state.settings, state.lastMode), day);
    if (now < start || now > shiftEnd || (pause && now >= pause.start && now < pause.end)) return;
    await notify(t("Descansa la vista", "Rest your eyes"), t("Mira algo a más de 6 metros durante 20 segundos.", "Look at something 6 meters (20 ft) away for 20 seconds."));
  } else if (alarm.name === "housekeeping") {
    await housekeeping();
  } else if (alarm.name === "tick") {
    await updateBadge(state);
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "tg-poll") pollPhone();
  else enqueue(() => handleAlarm(alarm));
});
