// Pantalla Progreso, planta del anillo y jardín de fondo.
// ---------- Progreso ----------

function renderWeekChart() {
  const days = Array.from({ length: 7 }, (_, index) => Core.addDays(todayKey(), index - 6));
  const values = days.map((day) => Core.recordsFor(state.records, day).reduce((sum, record) => sum + record.plannedMinutes, 0));
  const goal = Math.max(Core.routineMinutes(state.settings, "long", todayKey()), Core.routineMinutes(state.settings, "short", todayKey()));
  const scale = Math.max(goal, ...values, 1);
  dom.weekTotal.textContent = `${values.reduce((sum, value) => sum + value, 0)} min`;
  dom.weekChart.replaceChildren();
  dom.weekChart.setAttribute("aria-label", days.map((day, index) => `${formatDate(Core.dateFromKey(day), { weekday: "long" })}: ${values[index]} minutos`).join(". "));

  const goalLine = element("div", "chart-goal");
  goalLine.style.setProperty("--goal", (goal / scale).toFixed(3));
  goalLine.append(element("span", "", `Meta ${goal} min`));
  dom.weekChart.append(goalLine);

  days.forEach((day, index) => {
    const date = Core.dateFromKey(day);
    const column = element("div", "chart-col");
    column.tabIndex = 0;
    if (day === todayKey()) column.classList.add("is-today");
    const plot = element("div", "chart-plot");
    const bar = element("div", "chart-bar");
    bar.style.height = values[index] ? `max(4px, ${(values[index] / scale) * 100}%)` : "0";
    const tip = element("span", "chart-tip", `${formatDate(date, { weekday: "short", day: "numeric" })} · ${values[index]} min`);
    plot.append(bar, tip);
    column.append(plot, element("span", "chart-label", WEEKDAY_LETTERS[Core.weekdayIndex(date)]));
    dom.weekChart.append(column);
  });
}

function renderMonthStats() {
  const monthPrefix = Core.dateKey(visibleMonth).slice(0, 7);
  dom.monthStatsTitle.textContent = formatDate(visibleMonth, { month: "long", year: "numeric" });
  const monthRecords = state.records.filter((record) => record.day.startsWith(monthPrefix));
  const days = new Set(monthRecords.map((record) => record.day));
  let complete = 0;
  for (const day of days) {
    for (const routineMode of ["long", "short"]) if (Core.progressFor(state, routineMode, day).complete) complete += 1;
  }
  const finished = monthRecords.filter((record) => record.completedAt);
  const punctual = finished.filter((record) => Core.overtimeMinutes(record) === 0).length;
  const averageMinute = monthRecords.length
    ? Math.round(monthRecords.reduce((sum, record) => {
      const date = new Date(record.startedAt);
      return sum + date.getHours() * 60 + date.getMinutes();
    }, 0) / monthRecords.length)
    : null;

  $("#m-minutes").textContent = formatDuration(monthRecords.reduce((sum, record) => sum + record.plannedMinutes, 0));
  $("#m-days").textContent = String(days.size);
  $("#m-days").nextElementSibling.textContent = days.size === 1 ? "día con descansos" : "días con descansos";
  $("#m-complete").textContent = String(complete);
  $("#m-complete").nextElementSibling.textContent = complete === 1 ? "rutina completa" : "rutinas completas";
  $("#m-punctual").textContent = finished.length ? `${Math.round((punctual / finished.length) * 100)} %` : "—";
  $("#m-hour").textContent = averageMinute === null ? "—" : `${String(Math.floor(averageMinute / 60)).padStart(2, "0")}:${String(averageMinute % 60).padStart(2, "0")}`;
  $("#m-overtime").textContent = `${monthRecords.reduce((sum, record) => sum + Core.overtimeMinutes(record), 0)} min`;
}

function renderGarden() {
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const offset = (new Date(year, month, 1).getDay() + 6) % 7;
  const today = todayKey();
  let flowers = 0;
  dom.garden.replaceChildren();
  for (let index = 0; index < offset; index += 1) dom.garden.append(element("span", "garden-cell is-empty"));

  for (let dayNumber = 1; dayNumber <= daysInMonth; dayNumber += 1) {
    const key = Core.dateKey(new Date(year, month, dayNumber));
    const cell = element("span", "garden-cell");
    let plant = null;
    let label = "sin descansos";
    if (Core.dayComplete(state, key)) {
      const rare = Core.runLength(state, key) >= 5;
      plant = rare ? "g-rare" : "g-flower";
      label = rare ? "flor especial por racha" : "flor, rutina completa";
      flowers += 1;
    } else if (state.daysOff.includes(key)) {
      plant = "g-rest";
      label = "día libre";
    } else if (Core.recordsFor(state.records, key).length) {
      plant = "g-sprout";
      label = "brote, rutina en camino";
    }
    if (plant) cell.append(icon(plant, "plant"));
    else cell.append(element("i", key > today ? "soil is-future" : "soil"));
    cell.append(element("span", "garden-day", String(dayNumber)));
    cell.title = `${dayNumber}: ${label}`;
    if (key === today) cell.classList.add("is-today");
    dom.garden.append(cell);
  }
  dom.gardenCaption.textContent = flowers
    ? `${plural(flowers, "flor", "flores")} en ${formatDate(visibleMonth, { month: "long" }).toLowerCase()}. Cada rutina completa florece.`
    : "Completa una rutina para plantar tu primera flor.";
}

function renderProgress() {
  renderWeekChart();
  renderMonthStats();
  renderGarden();
  renderChallenges();
  renderGallery();
}

// ---------- Planta y jardín ----------

// La planta del anillo pasa de semilla a flor según los descansos de hoy (0 = semilla, 1 = flor).
let plantGrowth = 0;
let plantTarget = -1;
let plantFrame = null;

const clamp01 = (value) => Math.max(0, Math.min(1, value));
// Pequeño rebote al final para que hojas y flor "broten".
const easeOutBack = (t) => 1 + 2.2 * Math.pow(t - 1, 3) + 1.2 * Math.pow(t - 1, 2);

function setPlantShape(growth) {
  const stage = (from, span) => Math.max(0, easeOutBack(clamp01((growth - from) / span)));
  const bloom = stage(0.96, 0.04);
  const style = dom.growPlant.style;
  style.setProperty("--seed", clamp01(1 - growth * 14).toFixed(3));
  style.setProperty("--stem-on", growth > 0.004 ? "1" : "0");
  style.setProperty("--stem", clamp01(1.15 * Math.pow(growth, 0.6)).toFixed(3));
  style.setProperty("--l1", stage(0.06, 0.14).toFixed(3));
  style.setProperty("--l2", stage(0.3, 0.15).toFixed(3));
  style.setProperty("--l3", stage(0.55, 0.15).toFixed(3));
  style.setProperty("--bud", (stage(0.78, 0.12) * (1 - clamp01(bloom))).toFixed(3));
  style.setProperty("--bloom", bloom.toFixed(3));
  dom.growPlant.classList.toggle("is-bloomed", growth >= 0.999);
}

// Anima la planta hasta `target` fotograma a fotograma. Al abrir la extensión crece desde la semilla.
function growPlantTo(target, duration) {
  const goal = clamp01(target);
  if (Math.abs(goal - plantTarget) < 0.0001) return;
  const first = plantTarget < 0;
  plantTarget = goal;
  cancelAnimationFrame(plantFrame);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
    plantGrowth = goal;
    setPlantShape(goal);
    return;
  }
  const from = plantGrowth;
  const time = duration ?? (first ? 2200 : 1400);
  const smallStep = Math.abs(goal - from) < 0.02;
  const start = performance.now();
  const step = (now) => {
    const t = clamp01((now - start) / time);
    // Los avances segundo a segundo van a velocidad constante; los saltos grandes, con frenada suave.
    const eased = smallStep ? t : 1 - Math.pow(1 - t, 3);
    plantGrowth = from + (goal - from) * eased;
    setPlantShape(plantGrowth);
    if (t < 1) plantFrame = requestAnimationFrame(step);
  };
  plantFrame = requestAnimationFrame(step);
}

// Jardín de fondo: cada día completo planta una flor que con las semanas se convierte en arbusto y árbol.
function gardenEntries() {
  return [...new Set(state.records.map((record) => record.day))].map((day) => ({ day, complete: Core.dayComplete(state, day) }));
}

function renderGardenBackground() {
  const entries = gardenEntries();
  const extras = Core.challenges(state).filter((challenge) => challenge.done).length;
  const signature = `${todayKey()}|${extras}|${entries.map((entry) => `${entry.day}${entry.complete ? 1 : 0}`).join()}`;
  if (dom.gardenBg.dataset.signature === signature) return;
  dom.gardenBg.dataset.signature = signature;
  PausaGarden.render(dom.gardenBg, entries, todayKey(), { animateNew: true, extras });
}

