// Pantalla Calendario: mes, línea del día y registros.
// ---------- Calendario ----------

function renderCalendar() {
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  dom.monthLabel.textContent = formatDate(visibleMonth, { month: "long", year: "numeric" });
  dom.calendarDays.replaceChildren();

  const maxMinutes = Math.max(Core.routineMinutes(state.settings, "long", todayKey()), Core.routineMinutes(state.settings, "short", todayKey()), 1);
  const offset = (new Date(year, month, 1).getDay() + 6) % 7;
  const today = todayKey();
  for (let index = 0; index < 42; index += 1) {
    const date = new Date(year, month, 1 - offset + index);
    const key = Core.dateKey(date);
    const dayRecords = Core.recordsFor(state.records, key);
    const minutes = dayRecords.reduce((sum, record) => sum + record.plannedMinutes, 0);
    const complete = Core.dayComplete(state, key);
    const off = state.daysOff.includes(key);

    const button = element("button", "calendar-day");
    button.type = "button";
    button.setAttribute("role", "gridcell");
    button.style.setProperty("--heat", Math.min(1, minutes / maxMinutes).toFixed(2));
    const dots = element("span", "day-dots");
    for (const routineMode of ["long", "short"]) {
      if (dayRecords.some((record) => record.mode === routineMode)) dots.append(element("i", `dot ${routineMode}`));
    }
    button.append(element("span", "day-number", String(date.getDate())), dots);
    const details = [plural(dayRecords.length, "descanso", "descansos")];
    if (complete) details.push("rutina completa");
    if (off) details.push("día libre");
    button.setAttribute("aria-label", `${formatDate(date)}: ${details.join(", ")}`);
    button.setAttribute("aria-pressed", String(key === selectedDate));
    button.classList.toggle("is-outside", date.getMonth() !== month);
    button.classList.toggle("is-today", key === today);
    button.classList.toggle("is-selected", key === selectedDate);
    button.classList.toggle("is-complete", complete);
    button.classList.toggle("is-off", off);
    button.classList.toggle("is-frozen", Core.freezeDays(state).has(key));
    button.classList.toggle("has-records", dayRecords.length > 0);
    button.addEventListener("click", () => {
      selectedDate = key;
      closeRecordForm();
      if (date.getMonth() !== month) visibleMonth = new Date(date.getFullYear(), date.getMonth(), 1);
      scheduleUiStateSave();
      renderCalendar();
      renderDay();
    });
    dom.calendarDays.append(button);
  }
}

function renderTimeline(dayRecords) {
  dom.timeline.hidden = dayRecords.length === 0;
  dom.timelineTrack.replaceChildren();
  if (!dayRecords.length) return;

  const hourOf = (timestamp) => {
    const date = new Date(timestamp);
    return date.getHours() + date.getMinutes() / 60;
  };
  const starts = dayRecords.map((record) => hourOf(record.startedAt));
  const ends = dayRecords.map((record, index) => starts[index] + Math.max(record.plannedMinutes, actualMinutes(record)) / 60);
  const firstMode = dayRecords[0].mode;
  const dayHours = Core.hoursFor(state.settings, firstMode, dayRecords[0].day);
  const [workStart] = dayHours.start.split(":").map(Number);
  const [workEnd] = dayHours.end.split(":").map(Number);
  // Un turno de noche cruza la medianoche: se muestra el día entero.
  const crossing = dayHours.end <= dayHours.start;
  const from = crossing ? 0 : Math.max(0, Math.min(workStart, Math.floor(Math.min(...starts))));
  const to = crossing ? 24 : Math.min(24, Math.max(workEnd + 1, Math.ceil(Math.max(...ends))));
  const span = Math.max(1, to - from);

  dayRecords.forEach((record, index) => {
    const bar = element("i", `timeline-bar ${record.mode}`);
    if (Core.overtimeMinutes(record) > 0) bar.classList.add("is-overtime");
    bar.style.left = `${((starts[index] - from) / span) * 100}%`;
    bar.style.width = `max(4px, ${((ends[index] - starts[index]) / span) * 100}%)`;
    bar.title = `${formatTime(record.startedAt)} · ${record.plannedMinutes} min · ${MODE_NAMES[record.mode]}`;
    dom.timelineTrack.append(bar);
  });
  dom.timelineFrom.textContent = `${from}:00`;
  dom.timelineMid.textContent = `${Math.round((from + to) / 2)}:00`;
  dom.timelineTo.textContent = `${to}:00`;
}

function renderDay() {
  const dayRecords = Core.recordsFor(state.records, selectedDate);
  const isFuture = Core.dateFromKey(selectedDate) > new Date();
  const off = state.daysOff.includes(selectedDate);
  dom.selectedDateLabel.textContent = selectedDate === todayKey() ? `Hoy, ${formatDate(new Date(), { day: "numeric", month: "long" })}` : formatDate(Core.dateFromKey(selectedDate));
  dom.addRecord.hidden = isFuture;

  if (dayRecords.length) {
    const minutes = dayRecords.reduce((sum, record) => sum + record.plannedMinutes, 0);
    const overtime = dayRecords.reduce((sum, record) => sum + Core.overtimeMinutes(record), 0);
    const parts = [plural(dayRecords.length, "descanso", "descansos"), `${minutes} min`];
    for (const routineMode of ["long", "short"]) {
      if (!dayRecords.some((record) => record.mode === routineMode)) continue;
      const progress = Core.progressFor(state, routineMode, selectedDate);
      parts.push(`${routineMode === "long" ? "largo" : "corto"} ${progress.done}/${progress.total}`);
    }
    if (overtime) parts.push(`+${overtime} min extra`);
    dom.daySummary.textContent = capitalize(parts.join(" · "));
  } else {
    dom.daySummary.textContent = off ? "Día libre." : isFuture ? "Todavía no ha llegado." : "Sin descansos registrados.";
  }

  renderTimeline(dayRecords);
  dom.dayRecords.replaceChildren();
  dayRecords.forEach((record) => {
    const item = element("li", "record");
    const isActive = state.activeTimer?.recordId === record.id;
    const end = record.completedAt ? ` – ${formatTime(record.completedAt)}` : isActive ? " – en curso" : "";
    const info = element("div", "record-info");
    info.append(
      element("strong", "", `${formatTime(record.startedAt)}${end}`),
      element("span", "", `${MODE_NAMES[record.mode]} · ${record.plannedMinutes} min`)
    );
    const overtime = Core.overtimeMinutes(record);
    const tag = element("span", "record-tag", overtime ? `+${overtime} min` : "");
    tag.hidden = !overtime;
    tag.title = "Tiempo extra";
    const edit = element("button", "icon-btn icon-btn-sm");
    edit.type = "button";
    edit.append(icon("i-pencil"));
    edit.setAttribute("aria-label", `Editar descanso de las ${formatTime(record.startedAt)}`);
    edit.title = "Editar";
    edit.addEventListener("click", () => openRecordForm(record));
    const remove = element("button", "icon-btn icon-btn-sm danger");
    remove.type = "button";
    remove.append(icon("i-trash"));
    remove.setAttribute("aria-label", `Borrar descanso de las ${formatTime(record.startedAt)}`);
    remove.title = "Borrar";
    remove.addEventListener("click", () => {
      if (remove.classList.contains("is-confirming")) {
        deleteRecord(record.id);
        return;
      }
      remove.classList.add("is-confirming");
      remove.replaceChildren("¿Borrar?");
      setTimeout(() => {
        if (!remove.isConnected) return;
        remove.classList.remove("is-confirming");
        remove.replaceChildren(icon("i-trash"));
      }, 3000);
    });
    item.append(element("i", `dot ${record.mode}`), info, tag, edit, remove);
    dom.dayRecords.append(item);
  });

  dom.toggleDayOff.hidden = dayRecords.length > 0 && !off;
  dom.toggleDayOff.querySelector("span").textContent = off ? "Quitar día libre" : "Marcar como día libre";
  renderOverride();
}

