// Funciones añadidas a la ventana: idioma, retos, plan al calendario y ajustes nuevos.
// Se carga después de popup.js y comparte sus variables y funciones.

// ---------- Idioma ----------

function locale() {
  return state.settings.language === "en" ? "en-GB" : "es-ES";
}
const quoteText = (quote) => (state.settings.language === "en" && quote.en ? quote.en : quote.text);
const quoteAuthor = (quote) => (state.settings.language === "en" && quote.authorEn ? quote.authorEn : quote.author);

$("#language-select").addEventListener("change", async (event) => {
  state.settings.language = event.target.value;
  await persist(["settings"]);
  // Recargar vuelve a pintar todo desde cero en el idioma elegido.
  location.reload();
});

// El inglés se aplica traduciendo la interfaz al vuelo (ver i18n.js).
chrome.storage.local.get("settings").then(({ settings }) => {
  if (settings?.language === "en") PausaI18n.start();
});

// ---------- Ajustes nuevos ----------

function renderExtrasSettings() {
  const { settings } = state;
  $("#language-select").value = settings.language;
  $("#learn-habits").checked = settings.learnHabits !== false;
  $("#learn-row").hidden = editingProfile().plan.mode !== "spread";
  $("#weekly-summary").checked = settings.weeklySummary;
  $("#eye-reminder").checked = settings.eyeReminder;
  $("#auto-backup").checked = settings.autoBackup;
  $$("[data-pause]").forEach((input) => { input.value = editingProfile().pause[input.dataset.pause][input.dataset.edge]; });
  renderRotation();
  chrome.storage.local.get("lastBackup").then(({ lastBackup }) => {
    $("#auto-backup-info").textContent = lastBackup
      ? `Última copia automática: ${new Date(lastBackup.at).toLocaleString(locale(), { dateStyle: "medium", timeStyle: "short" })}`
      : "Se guarda una copia al día en la carpeta «Pausa Bloom» de Descargas (los siete últimos días).";
  });
}

for (const [selector, key, message] of [
  ["#learn-habits", "learnHabits", "Horas ajustadas a tus hábitos"],
  ["#weekly-summary", "weeklySummary"],
  ["#eye-reminder", "eyeReminder"],
  ["#auto-backup", "autoBackup"]
]) {
  $(selector).addEventListener("change", (event) => {
    state.settings[key] = event.target.checked;
    saveSettings(message);
  });
}

// ---------- Retos ----------

function renderChallenges() {
  const list = $("#challenge-list");
  list.replaceChildren();
  for (const challenge of Core.challenges(state)) {
    const item = element("li", challenge.done ? "challenge is-done" : "challenge");
    const badge = element("span", "challenge-badge");
    badge.append(icon(challenge.done ? "i-check" : "i-flame"));
    const text = element("div", "challenge-text");
    text.append(element("strong", "", challenge.title), element("span", "", challenge.desc));
    const bar = element("div", "challenge-bar");
    const fill = element("i");
    fill.style.width = `${(challenge.value / challenge.target) * 100}%`;
    bar.append(fill);
    item.append(badge, text, element("small", "", challenge.done ? "✓" : `${challenge.value}/${challenge.target}`), bar);
    list.append(item);
  }
}

// ---------- Plan de hoy al calendario del móvil (.ics) ----------

function exportPlanIcs() {
  const plan = Core.planDay(state, mode);
  if (plan.status !== "ok") {
    showToast("No hay descansos pendientes que añadir");
    return;
  }
  const english = state.settings.language === "en";
  const pad = (value) => String(value).padStart(2, "0");
  const stamp = (time) => {
    const date = new Date(time);
    return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}T${pad(date.getHours())}${pad(date.getMinutes())}00`;
  };
  const lead = state.settings.suggestLead;
  const events = plan.items.flatMap((item) => {
    const title = english ? `${item.minutes}-min break` : `Descanso de ${item.minutes} min`;
    return [
      "BEGIN:VEVENT",
      `UID:${crypto.randomUUID()}@pausa-bloom`,
      `DTSTAMP:${stamp(Date.now())}`,
      `DTSTART:${stamp(item.time)}`,
      `DURATION:PT${item.minutes}M`,
      `SUMMARY:${title}`,
      "BEGIN:VALARM",
      "ACTION:DISPLAY",
      `DESCRIPTION:${title}`,
      `TRIGGER:-PT${lead}M`,
      "END:VALARM",
      "END:VEVENT"
    ];
  });
  const content = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Pausa Bloom//ES", ...events, "END:VCALENDAR"].join("\r\n");
  download(`pausa-bloom-plan-${todayKey()}.ics`, content, "text/calendar;charset=utf-8");
  showToast("Plan descargado: ábrelo en el móvil para añadirlo al calendario");
}

$("#plan-ics").addEventListener("click", exportPlanIcs);

// ---------- Ajustes en grupos ----------

const settingsGroups = $$(".group");
// Acordeón: al abrir un grupo se cierran los demás.
settingsGroups.forEach((group) => group.addEventListener("toggle", () => {
  if (!group.open) return;
  settingsGroups.forEach((other) => { if (other !== group) other.open = false; });
  // Deja el grupo abierto arriba para ver sus controles sin desplazarte.
  const area = dom.views.getBoundingClientRect();
  dom.views.scrollTop += group.getBoundingClientRect().top - area.top - 8;
}));

const THEME_NAMES = { pink: "Peonía", classic: "Porcelana", night: "Medianoche", noir: "Rosa Noir" };

// Resumen de una línea que se ve con el grupo cerrado.
function renderGroupSummaries() {
  const { settings } = state;
  const profile = Core.profileFor(settings);
  $("#gs-appearance").textContent = `${THEME_NAMES[settings.theme]} · ${settings.language === "en" ? "English" : "Español"}`;
  $("#gs-schedules").textContent = settings.profiles.length > 1 ? `${profile.name} · ${settings.profiles.length} horarios` : profile.name;
  $("#gs-alerts").textContent = PausaTelegram.isLinked(settings.telegram) ? "Móvil conectado" : "Móvil sin conectar";
  $("#gs-data").textContent = settings.autoBackup ? "Copia automática activada" : "Copia automática desactivada";
  $("#gs-help").textContent = "Tutorial";
  ensureMoreUi();
}

// ---------- Horarios avanzados: pausa de comida, rotación A/B y cambio de un día ----------

// Pausa de comida (jornada partida).
$$("[data-pause]").forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  const mode = input.dataset.pause;
  const start = $(`[data-pause="${mode}"][data-edge="start"]`).value;
  const end = $(`[data-pause="${mode}"][data-edge="end"]`).value;
  const error = $("#pause-error");
  const hours = profile.hours[mode];
  if (!start && !end) {
    profile.pause[mode] = { start: "", end: "" };
  } else if (!start || !end || start >= end) {
    error.textContent = "Escribe el inicio y el fin de la pausa (el fin, después del inicio) o deja las dos horas vacías.";
    return;
  } else if (hours.end > hours.start && (start <= hours.start || end >= hours.end)) {
    error.textContent = "La pausa tiene que quedar dentro de la jornada.";
    return;
  } else {
    profile.pause[mode] = { start, end };
  }
  error.textContent = "";
  saveSettings("Pausa guardada");
}));

// Rotación A/B: semanas alternas con dos horarios distintos.
function renderRotation() {
  const { settings } = state;
  const { rotation } = settings;
  profileOptions($("#rotation-a"), rotation.a);
  profileOptions($("#rotation-b"), rotation.b);
  $("#rotation-enabled").checked = rotation.enabled;
  $("#rotation-box").hidden = !rotation.enabled;
  const weeks = Math.round((Core.dateFromKey(Core.weekStart(todayKey())) - Core.dateFromKey(rotation.aWeek)) / (7 * 86_400_000));
  $("#rotation-now").value = ((weeks % 2) + 2) % 2 === 0 ? "a" : "b";
}

$("#rotation-enabled").addEventListener("change", (event) => {
  if (event.target.checked && state.settings.profiles.length < 2) {
    event.target.checked = false;
    showToast("Crea otro horario para poder alternar semanas");
    return;
  }
  const { rotation } = state.settings;
  // Si A y B eran el mismo horario, la semana B pasa a ser otro distinto.
  if (event.target.checked && rotation.a === rotation.b) rotation.b = state.settings.profiles.find((profile) => profile.id !== rotation.a).id;
  rotation.enabled = event.target.checked;
  saveSettings(event.target.checked ? "Rotación activada" : "Rotación desactivada");
  renderWeeks();
});
for (const [selector, key] of [["#rotation-a", "a"], ["#rotation-b", "b"]]) {
  $(selector).addEventListener("change", (event) => {
    state.settings.rotation[key] = event.target.value;
    saveSettings("Rotación guardada");
    renderWeeks();
  });
}
$("#rotation-now").addEventListener("change", (event) => {
  // La semana actual pasa a ser la A o la B: se mueve el punto de partida de la rotación.
  const thisWeek = Core.weekStart(todayKey());
  state.settings.rotation.aWeek = event.target.value === "a" ? thisWeek : Core.addDays(thisWeek, -7);
  saveSettings("Rotación guardada");
  renderWeeks();
});

// Cambio de horas de un solo día (desde el calendario).
function renderOverride() {
  const current = state.settings.dayOverrides[selectedDate];
  $("#override-toggle").querySelector("span").textContent = current ? `Horas de este día: ${current.start}–${current.end}` : "Cambiar las horas de este día";
  $("#override-form").hidden = true;
}

$("#override-toggle").addEventListener("click", () => {
  const current = state.settings.dayOverrides[selectedDate] || Core.hoursFor(state.settings, mode, selectedDate);
  $("#override-start").value = current.start;
  $("#override-end").value = current.end;
  $("#override-error").textContent = "";
  $("#override-clear").hidden = !state.settings.dayOverrides[selectedDate];
  $("#override-form").hidden = false;
});
$("#override-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const start = $("#override-start").value;
  const end = $("#override-end").value;
  if (!start || !end || start === end) {
    $("#override-error").textContent = "Indica el inicio y el fin (distintos). Si el fin es anterior, el turno cruza la medianoche.";
    return;
  }
  state.settings.dayOverrides[selectedDate] = { start, end };
  saveSettings("Horas de este día guardadas");
});
$("#override-clear").addEventListener("click", () => {
  delete state.settings.dayOverrides[selectedDate];
  saveSettings("El día vuelve a su horario normal");
});
