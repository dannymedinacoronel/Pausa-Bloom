// Generador de códigos QR (modo byte, corrección de errores M, versiones 1 a 10).
// Suficiente para enlaces cortos como https://t.me/bot?start=código.
(function (global) {
  const ECC_PER_BLOCK = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26];
  const NUM_BLOCKS = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
  const ECC_FORMAT_BITS_M = 0;
  const MAX_VERSION = 10;

  function rawDataModules(version) {
    let result = (16 * version + 128) * version + 64;
    if (version >= 2) {
      const numAlign = Math.floor(version / 7) + 2;
      result -= (25 * numAlign - 10) * numAlign - 55;
      if (version >= 7) result -= 36;
    }
    return result;
  }

  function dataCodewords(version) {
    return Math.floor(rawDataModules(version) / 8) - ECC_PER_BLOCK[version] * NUM_BLOCKS[version];
  }

  // ---------- Reed-Solomon sobre GF(256) ----------
  function gfMultiply(x, y) {
    let z = 0;
    for (let i = 7; i >= 0; i -= 1) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    return z;
  }

  function rsDivisor(degree) {
    const result = new Array(degree).fill(0);
    result[degree - 1] = 1;
    let root = 1;
    for (let i = 0; i < degree; i += 1) {
      for (let j = 0; j < result.length; j += 1) {
        result[j] = gfMultiply(result[j], root);
        if (j + 1 < result.length) result[j] ^= result[j + 1];
      }
      root = gfMultiply(root, 0x02);
    }
    return result;
  }

  function rsRemainder(data, divisor) {
    const result = divisor.map(() => 0);
    for (const byte of data) {
      const factor = byte ^ result.shift();
      result.push(0);
      divisor.forEach((coefficient, index) => { result[index] ^= gfMultiply(coefficient, factor); });
    }
    return result;
  }

  function addEccAndInterleave(data, version) {
    const numBlocks = NUM_BLOCKS[version];
    const blockEccLength = ECC_PER_BLOCK[version];
    const rawCodewords = Math.floor(rawDataModules(version) / 8);
    const numShortBlocks = numBlocks - (rawCodewords % numBlocks);
    const shortBlockLength = Math.floor(rawCodewords / numBlocks);
    const divisor = rsDivisor(blockEccLength);
    const blocks = [];
    for (let i = 0, offset = 0; i < numBlocks; i += 1) {
      const block = data.slice(offset, offset + shortBlockLength - blockEccLength + (i < numShortBlocks ? 0 : 1));
      offset += block.length;
      const ecc = rsRemainder(block, divisor);
      if (i < numShortBlocks) block.push(0);
      blocks.push(block.concat(ecc));
    }
    const result = [];
    for (let i = 0; i < blocks[0].length; i += 1) {
      blocks.forEach((block, j) => {
        if (i !== shortBlockLength - blockEccLength || j >= numShortBlocks) result.push(block[i]);
      });
    }
    return result;
  }

  // ---------- Matriz ----------
  function encode(text) {
    const bytes = [...new TextEncoder().encode(text)];
    let version = 1;
    while (version <= MAX_VERSION && 4 + (version <= 9 ? 8 : 16) + bytes.length * 8 > dataCodewords(version) * 8) version += 1;
    if (version > MAX_VERSION) throw new Error("Texto demasiado largo para el código QR");

    const bits = [];
    const append = (value, length) => { for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1); };
    append(0x4, 4);
    append(bytes.length, version <= 9 ? 8 : 16);
    bytes.forEach((byte) => append(byte, 8));
    const capacity = dataCodewords(version) * 8;
    append(0, Math.min(4, capacity - bits.length));
    append(0, (8 - (bits.length % 8)) % 8);
    for (let pad = 0xEC; bits.length < capacity; pad ^= 0xEC ^ 0x11) append(pad, 8);
    const codewords = [];
    for (let i = 0; i < bits.length; i += 8) codewords.push(bits.slice(i, i + 8).reduce((byte, bit) => (byte << 1) | bit, 0));

    const size = version * 4 + 17;
    const modules = Array.from({ length: size }, () => new Array(size).fill(false));
    const isFunction = Array.from({ length: size }, () => new Array(size).fill(false));
    const setFunction = (x, y, dark) => { modules[y][x] = dark; isFunction[y][x] = true; };
    const bit = (value, index) => ((value >>> index) & 1) !== 0;

    for (let i = 0; i < size; i += 1) {
      setFunction(6, i, i % 2 === 0);
      setFunction(i, 6, i % 2 === 0);
    }
    const drawFinder = (cx, cy) => {
      for (let dy = -4; dy <= 4; dy += 1) {
        for (let dx = -4; dx <= 4; dx += 1) {
          const distance = Math.max(Math.abs(dx), Math.abs(dy));
          const x = cx + dx;
          const y = cy + dy;
          if (x >= 0 && x < size && y >= 0 && y < size) setFunction(x, y, distance !== 2 && distance !== 4);
        }
      }
    };
    drawFinder(3, 3);
    drawFinder(size - 4, 3);
    drawFinder(3, size - 4);

    if (version > 1) {
      const numAlign = Math.floor(version / 7) + 2;
      const step = Math.ceil((version * 4 + 4) / (numAlign * 2 - 2)) * 2;
      const positions = [6];
      for (let position = size - 7; positions.length < numAlign; position -= step) positions.splice(1, 0, position);
      positions.forEach((ay, i) => positions.forEach((ax, j) => {
        if ((i === 0 && j === 0) || (i === 0 && j === numAlign - 1) || (i === numAlign - 1 && j === 0)) return;
        for (let dy = -2; dy <= 2; dy += 1) {
          for (let dx = -2; dx <= 2; dx += 1) setFunction(ax + dx, ay + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }));
    }

    const drawFormat = (mask) => {
      const data = (ECC_FORMAT_BITS_M << 3) | mask;
      let remainder = data;
      for (let i = 0; i < 10; i += 1) remainder = (remainder << 1) ^ ((remainder >>> 9) * 0x537);
      const format = ((data << 10) | remainder) ^ 0x5412;
      for (let i = 0; i <= 5; i += 1) setFunction(8, i, bit(format, i));
      setFunction(8, 7, bit(format, 6));
      setFunction(8, 8, bit(format, 7));
      setFunction(7, 8, bit(format, 8));
      for (let i = 9; i < 15; i += 1) setFunction(14 - i, 8, bit(format, i));
      for (let i = 0; i < 8; i += 1) setFunction(size - 1 - i, 8, bit(format, i));
      for (let i = 8; i < 15; i += 1) setFunction(8, size - 15 + i, bit(format, i));
      setFunction(8, size - 8, true);
    };
    drawFormat(0);

    if (version >= 7) {
      let remainder = version;
      for (let i = 0; i < 12; i += 1) remainder = (remainder << 1) ^ ((remainder >>> 11) * 0x1F25);
      const versionBits = (version << 12) | remainder;
      for (let i = 0; i < 18; i += 1) {
        const a = size - 11 + (i % 3);
        const b = Math.floor(i / 3);
        setFunction(a, b, bit(versionBits, i));
        setFunction(b, a, bit(versionBits, i));
      }
    }

    const allCodewords = addEccAndInterleave(codewords, version);
    let index = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vertical = 0; vertical < size; vertical += 1) {
        for (let j = 0; j < 2; j += 1) {
          const x = right - j;
          const upward = ((right + 1) & 2) === 0;
          const y = upward ? size - 1 - vertical : vertical;
          if (!isFunction[y][x] && index < allCodewords.length * 8) {
            modules[y][x] = bit(allCodewords[index >>> 3], 7 - (index & 7));
            index += 1;
          }
        }
      }
    }

    const maskTest = [
      (x, y) => (x + y) % 2 === 0,
      (x, y) => y % 2 === 0,
      (x) => x % 3 === 0,
      (x, y) => (x + y) % 3 === 0,
      (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
      (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
      (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0,
      (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0
    ];
    const applyMask = (mask) => {
      for (let y = 0; y < size; y += 1) {
        for (let x = 0; x < size; x += 1) if (!isFunction[y][x] && maskTest[mask](x, y)) modules[y][x] = !modules[y][x];
      }
    };

    // Penalización simplificada (filas/columnas repetidas, bloques 2×2 y equilibrio de color).
    const penalty = () => {
      let score = 0;
      const runs = (line) => {
        let run = 1;
        for (let i = 1; i <= line.length; i += 1) {
          if (i < line.length && line[i] === line[i - 1]) run += 1;
          else {
            if (run >= 5) score += run - 2;
            run = 1;
          }
        }
      };
      for (let y = 0; y < size; y += 1) runs(modules[y]);
      for (let x = 0; x < size; x += 1) runs(modules.map((row) => row[x]));
      let dark = 0;
      for (let y = 0; y < size; y += 1) {
        for (let x = 0; x < size; x += 1) {
          if (modules[y][x]) dark += 1;
          if (x < size - 1 && y < size - 1) {
            const color = modules[y][x];
            if (color === modules[y][x + 1] && color === modules[y + 1][x] && color === modules[y + 1][x + 1]) score += 3;
          }
        }
      }
      const total = size * size;
      score += Math.ceil(Math.abs(dark * 20 - total * 10) / total - 1) * 10;
      return score;
    };

    let bestMask = 0;
    let bestScore = Infinity;
    for (let mask = 0; mask < 8; mask += 1) {
      applyMask(mask);
      drawFormat(mask);
      const score = penalty();
      if (score < bestScore) {
        bestScore = score;
        bestMask = mask;
      }
      applyMask(mask);
    }
    applyMask(bestMask);
    drawFormat(bestMask);
    return modules;
  }

  // Devuelve un <svg> con el código y un margen blanco de 4 módulos.
  function toSvg(text) {
    const modules = encode(text);
    const border = 4;
    const size = modules.length + border * 2;
    let path = "";
    modules.forEach((row, y) => row.forEach((dark, x) => {
      if (dark) path += `M${x + border},${y + border}h1v1h-1z`;
    }));
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
    svg.setAttribute("shape-rendering", "crispEdges");
    svg.innerHTML = `<rect width="${size}" height="${size}" fill="#FFFFFF"/><path d="${path}" fill="#111111"/>`;
    return svg;
  }

  global.PausaQR = { encode, toSvg };
})(globalThis);
