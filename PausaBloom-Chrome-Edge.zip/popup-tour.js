// Tutorial guiado.
// ---------- Tutorial ----------

const TOUR_STEPS = [
  {
    title: "Te damos la bienvenida a Pausa Bloom",
    text: "Te ayuda a tomar tus descansos a la mejor hora y a llevar un registro sin esfuerzo. Te enseñamos lo básico en menos de un minuto."
  },
  {
    target: ".segmented",
    title: "Elige tu jornada",
    text: "Cambia entre día largo (6 de 5 min y 2 de 10 min) y día corto (5 de 5 min y 1 de 15 min). En Ajustes puedes hacer que se elija sola según el día de la semana."
  },
  {
    target: "#hero",
    title: "Tu progreso de un vistazo",
    text: "Con cada descanso la planta del centro crece hasta florecer al completar la rutina. Durante un descanso, el anillo se convierte en una cuenta atrás."
  },
  {
    demo: true,
    title: "Tu jardín se convierte en bosque",
    text: "Cada día con la rutina completa planta una flor de una especie distinta. Con las semanas se convierte en arbusto y después en árbol, y el paisaje cambia con las estaciones. Así se vería en un año:"
  },
  {
    target: "#suggestion",
    title: "La mejor hora para descansar",
    text: "Según tu horario, repartimos los descansos a lo largo de la jornada y te decimos cuándo tomar el siguiente. Los más largos quedan hacia la mitad del día."
  },
  {
    target: "#choices",
    title: "Un clic y listo",
    text: "Pulsa la duración del descanso que vas a tomar: se guarda la hora y empieza la cuenta atrás. Al volver, pulsa «Ya volví» y te espera una frase para seguir con energía."
  },
  {
    target: "#plan-card",
    title: "Tu plan del día",
    text: "Aquí ves los descansos que ya tomaste y los que te sugerimos, en orden. El plan se recalcula cada vez que descansas."
  },
  {
    target: '[data-view-target="calendar"]',
    title: "Calendario",
    text: "Revisa cualquier día del mes, añade descansos olvidados, corrige horas o marca días libres para no romper tu racha."
  },
  {
    target: '[data-view-target="progress"]',
    title: "Progreso y jardín",
    text: "Mira tus minutos de la semana, tu puntualidad y tu jardín: cada día con la rutina completa florece."
  },
  {
    target: '[data-view-target="settings"]',
    title: "Hazla tuya",
    text: "Ajusta rutinas, horario, tema, iconos, sonido y avisos. Desde aquí también puedes crear copias de seguridad."
  },
  {
    title: "Sin abrir la extensión",
    text: "" // se completa con los atajos reales
  }
];
let tourIndex = 0;
let tourDemoTimer = null;

// Año simulado para la demo del tutorial: unos 8 de cada 10 días laborables con la rutina completa.
function simulatedYear() {
  const start = Core.dateFromKey(todayKey());
  const entries = [];
  for (let offset = 0; offset <= 365; offset += 1) {
    const date = new Date(start);
    date.setDate(start.getDate() + offset);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    const chance = Math.abs((Math.sin(offset * 12.9898) * 43758.5453) % 1);
    if (chance < 0.94) entries.push({ day: Core.dateKey(date), complete: chance < 0.82 });
  }
  return { start, entries };
}

function startTourDemo() {
  if (tourDemoTimer) return;
  const seasons = { spring: "primavera", summer: "verano", autumn: "otoño", winter: "invierno" };
  const { start, entries } = simulatedYear();
  const scene = $("#tour-demo-scene");
  let offset = 0;
  let pause = 0;
  $("#tour-demo").hidden = false;
  const step = () => {
    if (pause > 0) {
      pause -= 1;
      if (pause === 0) offset = 0;
      return;
    }
    const date = new Date(start);
    date.setDate(start.getDate() + offset);
    const info = PausaGarden.render(scene, entries, Core.dateKey(date));
    const trees = info.counts.young + info.counts.tree;
    $("#tour-demo-day").textContent = `Día ${offset + 1}`;
    $("#tour-demo-info").textContent = `${seasons[info.season]} · ${plural(trees, "árbol", "árboles")}`;
    offset += 3;
    // Al terminar el año se queda un momento quieto y vuelve a empezar.
    if (offset > 365) pause = 25;
  };
  step();
  tourDemoTimer = setInterval(step, 70);
}

function stopTourDemo() {
  clearInterval(tourDemoTimer);
  tourDemoTimer = null;
  $("#tour-demo").hidden = true;
}

function startTour() {
  showView("today");
  tourIndex = 0;
  dom.tour.hidden = false;
  renderTourStep();
}

function endTour() {
  stopTourDemo();
  dom.tour.hidden = true;
  chrome.storage.local.set({ tutorialDone: true });
}

function renderTourStep() {
  const step = TOUR_STEPS[tourIndex];
  const last = tourIndex === TOUR_STEPS.length - 1;
  if (last) {
    const start = shortcuts["start-break"] || "Alt+Shift+B";
    const finish = shortcuts["finish-break"] || "Alt+Shift+V";
    step.text = `Pulsa ${start} para empezar el descanso sugerido y ${finish} cuando vuelvas. El icono de la barra muestra cuántos descansos te quedan o los minutos que faltan.`;
  }
  dom.tourStep.textContent = tourIndex === 0 ? "Tutorial" : `Paso ${tourIndex} de ${TOUR_STEPS.length - 1}`;
  dom.tourTitle.textContent = step.title;
  dom.tourText.textContent = step.text;
  dom.tourLogo.toggleAttribute("hidden", Boolean(step.target || step.demo));
  if (step.demo) startTourDemo();
  else stopTourDemo();
  dom.tourBack.hidden = tourIndex === 0;
  dom.tourSkip.hidden = last;
  dom.tourNext.textContent = tourIndex === 0 ? "Empezar" : last ? "Terminar" : "Siguiente";
  dom.tourDots.replaceChildren(...TOUR_STEPS.map((_, index) => element("i", index === tourIndex ? "is-active" : "")));

  const target = step.target ? $(step.target) : null;
  if (target && !target.hidden) {
    revealInViews(target, true);
    positionTour(target);
  } else {
    positionTour(null);
  }
  dom.tourNext.focus();
}

function positionTour(target) {
  const card = dom.tourCard;
  const viewport = { width: document.body.clientWidth, height: document.body.clientHeight };
  if (!target) {
    dom.tourSpot.classList.add("is-center");
    Object.assign(dom.tourSpot.style, { top: `${viewport.height / 2}px`, left: `${viewport.width / 2}px`, width: "0px", height: "0px" });
    card.classList.add("is-center");
    card.style.top = `${Math.max(16, (viewport.height - card.offsetHeight) / 2)}px`;
    return;
  }
  dom.tourSpot.classList.remove("is-center");
  card.classList.remove("is-center");
  const rect = target.getBoundingClientRect();
  const pad = 6;
  Object.assign(dom.tourSpot.style, {
    top: `${rect.top - pad}px`,
    left: `${rect.left - pad}px`,
    width: `${rect.width + pad * 2}px`,
    height: `${rect.height + pad * 2}px`
  });
  const below = rect.bottom + pad + 12;
  const fitsBelow = below + card.offsetHeight < viewport.height - 8;
  card.style.top = `${fitsBelow ? below : Math.max(8, rect.top - pad - 12 - card.offsetHeight)}px`;
}

