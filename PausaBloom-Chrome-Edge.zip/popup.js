const Core = PausaCore;
const { MINUTE, MODE_NAMES } = Core;
const WEEKDAY_LETTERS = ["L", "M", "X", "J", "V", "S", "D"];
const WEEKDAY_CYCLE = { none: "long", long: "short", short: "none" };
const WEEKDAY_VALUE_LABEL = { none: "—", long: "Largo", short: "Corto" };
const RING_CIRCUMFERENCE = 2 * Math.PI * 54;
const BREATH_IN = 4;
const BREATH_OUT = 6;
const TIPS = [
  "Levántate y estira los brazos por encima de la cabeza durante 20 segundos.",
  "Mira algo que esté a más de 6 metros durante 20 segundos para descansar la vista.",
  "Bebe un vaso de agua: la hidratación también es descanso.",
  "Gira los hombros hacia atrás diez veces, despacio.",
  "Inclina la cabeza hacia cada lado y mantén la postura 15 segundos.",
  "Da un pequeño paseo, aunque sea hasta la ventana.",
  "Abre y cierra las manos y estira los dedos uno a uno.",
  "Prueba la respiración guiada: inhala 4 segundos y exhala 6.",
  "Aléjate de la pantalla: este rato es solo para ti."
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const dom = {
  body: document.body,
  views: $("#views"),
  headerDate: $("#header-date"),
  streak: $("#streak"),
  streakCount: $("#streak-count"),
  segments: $$(".segment[data-mode]"),
  scheduleLine: $("#schedule-line"),
  longIcon: $("#long-icon"),
  shortIcon: $("#short-icon"),
  hero: $("#hero"),
  quoteCard: $("#quote-card"),
  quoteText: $("#quote-text"),
  quoteAuthor: $("#quote-author"),
  ringFill: $("#ring-fill"),
  growPlant: $("#grow-plant"),
  gardenBg: $("#garden-bg"),
  ringLabel: $("#ring-label"),
  ringValue: $("#ring-value"),
  ringCaption: $("#ring-caption"),
  breath: $("#breath"),
  heroTitle: $("#hero-title"),
  heroMessage: $("#hero-message"),
  tokens: $("#tokens"),
  suggestion: $("#suggestion"),
  suggestionLabel: $("#suggestion-label"),
  suggestionTime: $("#suggestion-time"),
  suggestionDetail: $("#suggestion-detail"),
  suggestionAction: $("#suggestion-action"),
  choices: $("#choices"),
  breakChoices: $("#break-choices"),
  running: $("#running"),
  tipText: $("#tip-text"),
  breathToggle: $("#breath-toggle"),
  planCard: $("#plan-card"),
  planNote: $("#plan-note"),
  planList: $("#plan-list"),
  monthLabel: $("#month-label"),
  calendarDays: $("#calendar-days"),
  selectedDateLabel: $("#selected-date-label"),
  daySummary: $("#day-summary"),
  addRecord: $("#add-record"),
  timeline: $("#timeline"),
  timelineTrack: $("#timeline-track"),
  timelineFrom: $("#timeline-from"),
  timelineMid: $("#timeline-mid"),
  timelineTo: $("#timeline-to"),
  dayRecords: $("#day-records"),
  recordForm: $("#record-form"),
  recordFormTitle: $("#record-form-title"),
  recordMode: $("#record-mode"),
  recordMinutes: $("#record-minutes"),
  recordStart: $("#record-start"),
  recordEnd: $("#record-end"),
  recordFormMessage: $("#record-form-message"),
  toggleDayOff: $("#toggle-day-off"),
  weekTotal: $("#week-total"),
  weekChart: $("#week-chart"),
  monthStatsTitle: $("#month-stats-title"),
  garden: $("#garden"),
  gardenCaption: $("#garden-caption"),
  weekdayModes: $("#weekday-modes"),
  hoursError: $("#hours-error"),
  routineError: $("#routine-error"),
  alertsError: $("#alerts-error"),
  timerEnabled: $("#timer-enabled"),
  endAlert: $("#end-alert"),
  suggestAlert: $("#suggest-alert"),
  soundSelect: $("#sound-select"),
  shortcutList: $("#shortcut-list"),
  backupFile: $("#backup-file"),
  toast: $("#toast"),
  tour: $("#tour"),
  tourSpot: $("#tour-spot"),
  tourCard: $("#tour-card"),
  tourLogo: $("#tour-logo"),
  tourStep: $("#tour-step"),
  tourTitle: $("#tour-title"),
  tourText: $("#tour-text"),
  tourDots: $("#tour-dots"),
  tourBack: $("#tour-back"),
  tourNext: $("#tour-next"),
  tourSkip: $("#tour-skip")
};

const state = {
  settings: Core.mergeSettings(),
  records: [],
  activeTimer: null,
  daysOff: [],
  returnQuote: null
};
let mode = "long";
let view = "today";
let selectedDate = Core.dateKey(new Date());
let visibleMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let editingId = null;
let breathing = false;
let breathStart = 0;
let tipIndex = Math.floor(Math.random() * TIPS.length);
let tickCount = 0;
let toastTimer = null;
let shortcuts = {};

// ---------- Formato ----------

function todayKey() {
  return Core.dateKey(new Date());
}

function capitalize(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function formatTime(timestamp) {
  return new Intl.DateTimeFormat("es-ES", { hour: "2-digit", minute: "2-digit" }).format(new Date(timestamp));
}

function formatDate(date, options = { weekday: "long", day: "numeric", month: "long" }) {
  return capitalize(new Intl.DateTimeFormat("es-ES", options).format(date));
}

function formatClock(totalSeconds) {
  return `${String(Math.floor(totalSeconds / 60)).padStart(2, "0")}:${String(totalSeconds % 60).padStart(2, "0")}`;
}

function formatDuration(minutes) {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? `${hours} h ${rest} min` : `${hours} h`;
}

function timeInputValue(timestamp) {
  const date = new Date(timestamp);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function plural(count, singular, pluralWord) {
  return `${count} ${count === 1 ? singular : pluralWord}`;
}

function icon(name, className = "icon") {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", className);
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#${name}`);
  svg.append(use);
  return svg;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// Aviso flotante. Con `undo`, muestra un botón "Deshacer" durante unos segundos.
function showToast(message, undo) {
  dom.toast.replaceChildren(element("span", "", message));
  if (undo) {
    const button = element("button", "toast-action", "Deshacer");
    button.type = "button";
    button.addEventListener("click", async () => {
      dom.toast.classList.remove("is-visible");
      await undo();
      showToast("Hecho: se ha deshecho");
    });
    dom.toast.append(button);
  }
  dom.toast.classList.toggle("has-action", Boolean(undo));
  dom.toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => dom.toast.classList.remove("is-visible"), undo ? 6000 : 2600);
}

// Copia del estado para poder deshacer borrados y restablecimientos.
function snapshot() {
  return structuredClone({
    settings: state.settings,
    records: state.records,
    activeTimer: state.activeTimer,
    daysOff: state.daysOff,
    returnQuote: state.returnQuote
  });
}

async function restoreSnapshot(saved, extra = {}) {
  Object.assign(state, structuredClone(saved));
  await chrome.storage.local.set({ ...saved, ...extra });
  renderSettings();
  render();
}

// Desplaza solo el área de contenido; scrollIntoView movería también la ventana entera.
function revealInViews(target, center) {
  document.scrollingElement.scrollTop = 0;
  if (!dom.views.contains(target)) return;
  const area = dom.views.getBoundingClientRect();
  const rect = target.getBoundingClientRect();
  if (center) {
    dom.views.scrollTop += rect.top - area.top - Math.max(0, (area.height - rect.height) / 2);
  } else if (rect.bottom > area.bottom) {
    dom.views.scrollTop += rect.bottom - area.bottom + 12;
  }
}

function actualMinutes(record) {
  if (record.completedAt) return (record.completedAt - record.startedAt) / MINUTE;
  if (state.activeTimer?.recordId === record.id) return (Date.now() - record.startedAt) / MINUTE;
  return record.plannedMinutes;
}

// ---------- Hoy ----------

function setRing(fraction) {
  const clamped = Math.max(0, Math.min(1, fraction));
  dom.ringFill.style.strokeDasharray = String(RING_CIRCUMFERENCE);
  dom.ringFill.style.strokeDashoffset = String(RING_CIRCUMFERENCE * (1 - clamped));
}

function renderHeader() {
  dom.headerDate.textContent = formatDate(new Date());
  const streak = Core.currentStreak(state);
  dom.streak.hidden = streak === 0;
  dom.streakCount.textContent = String(streak);
  dom.streak.title = `Racha: ${plural(streak, "día seguido", "días seguidos")} completando tu rutina`;
}

function renderSegments() {
  dom.segments.forEach((segment) => {
    const selected = segment.dataset.mode === mode;
    segment.classList.toggle("is-active", selected);
    segment.setAttribute("aria-selected", String(selected));
  });
  const profile = Core.profileFor(state.settings, todayKey());
  const hours = profile.hours[mode];
  const planLabel = { spread: "repartidos", interval: `cada ${profile.plan.interval} min`, fixed: "a horas fijas" }[profile.plan.mode];
  const progress = Core.progressFor(state, mode, todayKey());
  dom.scheduleLine.replaceChildren(
    icon("i-clock"),
    `${state.settings.profiles.length > 1 ? `${profile.name} · ` : ""}${hours.start}–${hours.end} · ${plural(progress.total, "descanso", "descansos")} ${planLabel}`
  );
}

function renderHero() {
  const progress = Core.progressFor(state, mode, todayKey());
  const timer = state.activeTimer;
  dom.hero.classList.toggle("is-running", Boolean(timer));
  dom.hero.classList.toggle("is-breathing", Boolean(timer) && breathing);
  dom.hero.classList.toggle("is-complete", !timer && progress.complete);

  if (timer) {
    const remaining = timer.endAt - Date.now();
    const overtime = remaining <= 0;
    dom.hero.classList.toggle("is-overtime", overtime);
    const totalMinutes = timer.minutes + (timer.extraMinutes || 0);
    setRing(overtime ? 1 : remaining / (totalMinutes * MINUTE));
    dom.ringValue.textContent = overtime
      ? `+${formatClock(Math.floor(-remaining / 1000))}`
      : formatClock(Math.ceil(remaining / 1000));
    dom.ringLabel.textContent = "";
    if (breathing) {
      const phase = ((Date.now() - breathStart) / 1000) % (BREATH_IN + BREATH_OUT);
      dom.ringCaption.textContent = phase < BREATH_IN ? "Inhala" : "Exhala";
    } else {
      dom.ringCaption.textContent = overtime ? "tiempo extra" : `de ${totalMinutes} min`;
    }
    // Mientras descansas, la planta sigue creciendo segundo a segundo.
    const activeRecord = state.records.find((record) => record.id === timer.recordId);
    const counted = activeRecord?.mode === mode && activeRecord.day === todayKey() && progress.done > 0 ? 1 : 0;
    const fraction = Math.min(1, (Date.now() - timer.startedAt) / (totalMinutes * MINUTE));
    growPlantTo(progress.total ? (progress.done - counted + fraction) / progress.total : 0, 1000);
    dom.heroTitle.textContent = overtime ? "Es hora de volver" : "Desconecta un momento";
    dom.heroMessage.textContent = overtime
      ? `Tu descanso terminó a las ${formatTime(timer.endAt)}.`
      : `Termina a las ${formatTime(timer.endAt)}.`;
  } else {
    dom.hero.classList.remove("is-overtime");
    setRing(progress.total ? progress.done / progress.total : 0);
    dom.ringLabel.textContent = "";
    dom.ringValue.textContent = `${progress.done}/${progress.total}`;
    dom.ringCaption.textContent = `${progress.done} de ${progress.total}`;
    growPlantTo(progress.total ? progress.done / progress.total : 0);
    const remainingMinutes = progress.groups.reduce((sum, group) => sum + group.remaining * group.minutes, 0);
    dom.heroTitle.textContent = progress.complete
      ? "Rutina completa"
      : progress.done > 0 ? "Buen ritmo" : "Listo para empezar";
    dom.heroMessage.textContent = progress.complete
      ? "Has cuidado tus descansos hoy."
      : `${capitalize(plural(progress.total - progress.done, "descanso pendiente", "descansos pendientes"))} · ${remainingMinutes} min`;
  }

  dom.tokens.replaceChildren();
  progress.groups.forEach((group) => {
    const row = element("div", "token-row");
    row.setAttribute("aria-label", `${group.minutes} minutos: ${group.taken} de ${group.count}`);
    const dots = element("span", "token-dots");
    for (let index = 0; index < group.count; index += 1) dots.append(element("i", index < group.taken ? "is-filled" : ""));
    row.append(element("span", "token-label", `${group.minutes} min`), dots);
    dom.tokens.append(row);
  });
  if (progress.extra > 0) dom.tokens.append(element("span", "token-extra", `+${progress.extra} extra`));
}

function renderSuggestion(plan) {
  const timer = state.activeTimer;
  dom.suggestion.hidden = Boolean(timer) || plan.status === "complete";
  if (timer) return;

  const set = (iconName, label, time, detail, action) => {
    dom.suggestionLabel.textContent = label;
    dom.suggestionTime.textContent = time;
    dom.suggestionDetail.textContent = detail;
    dom.suggestionAction.hidden = !action;
    dom.suggestionAction.replaceChildren();
    if (action) {
      const actionIcon = plan.status === "ok" ? element("span", "choice-icon", state.settings.icons[mode]) : icon(iconName);
      actionIcon.setAttribute("aria-hidden", "true");
      dom.suggestionAction.append(actionIcon, document.createTextNode(action));
    }
  };
  dom.suggestion.classList.toggle("is-now", plan.status === "ok" && plan.late);
  dom.suggestion.classList.toggle("is-done", plan.status === "complete");

  if (plan.status === "ok") {
    const wait = Math.round((plan.next.time - Date.now()) / MINUTE);
    if (plan.late || wait <= 0) {
      set("i-clock", "Buen momento para descansar", "Ahora", `Descanso de ${plan.next.minutes} min`, "Empezar");
    } else {
      set("i-clock", "Siguiente descanso", formatTime(plan.next.time), `${plan.next.minutes} min · dentro de ${formatDuration(wait)}`, "Empezar");
    }
  } else if (plan.status === "complete") {
    set("i-check", "Hoy", "Rutina completa", "Ya tomaste todos tus descansos.", null);
  } else if (plan.status === "after") {
    set("i-moon", "Jornada terminada", `Hasta las ${plan.profile.hours[mode].end}`, "Ya no quedan horas de trabajo hoy.", null);
  } else if (plan.status === "off") {
    set("i-cup", "Hoy", "Día libre", "Sin sugerencias ni avisos hoy. ¡Disfruta!", plan.markedOff ? "Quitar" : "Ajustes");
  } else {
    set("i-sliders", "Horario", "Sin configurar", "Revisa tu horario y tus rutinas en Ajustes.", "Ajustes");
  }
  dom.suggestionAction.onclick = () => {
    if (plan.status === "ok") registerBreak(plan.next.minutes);
    else if (plan.status === "off" && plan.markedOff) toggleDayOff(todayKey());
    else showView("settings");
  };
}

function renderChoices() {
  const progress = Core.progressFor(state, mode, todayKey());
  const timer = state.activeTimer;
  dom.choices.hidden = Boolean(timer);
  dom.running.hidden = !timer;
  $("#today-off").hidden = Core.isRestDay(state, todayKey());
  dom.tipText.textContent = TIPS[tipIndex];
  dom.breathToggle.setAttribute("aria-pressed", String(breathing));
  dom.breathToggle.querySelector("span").textContent = breathing ? "Parar" : "Respirar";
  if (timer) return;

  dom.breakChoices.replaceChildren();
  progress.groups.forEach((group) => {
    const button = element("button", "choice");
    button.type = "button";
    button.disabled = group.remaining === 0;
    const choiceIcon = element("span", "choice-icon", state.settings.icons[mode]);
    choiceIcon.setAttribute("aria-hidden", "true");
    button.append(choiceIcon);
    const amount = element("span", "choice-amount");
    amount.append(element("strong", "", String(group.minutes)), element("span", "", "min"));
    button.append(amount, element("span", "choice-left", group.remaining ? `Quedan ${group.remaining}` : "Completado"));
    button.setAttribute("aria-label", `Empezar descanso de ${group.minutes} minutos. Quedan ${group.remaining}.`);
    button.addEventListener("click", () => registerBreak(group.minutes));
    dom.breakChoices.append(button);
  });
}

function renderPlan(plan) {
  const taken = plan.taken.map((record) => ({ time: record.startedAt, minutes: record.plannedMinutes, record }));
  const upcoming = plan.status === "ok" ? plan.items : [];
  const entries = [...taken, ...upcoming].sort((a, b) => a.time - b.time);
  dom.planCard.hidden = entries.length === 0;
  dom.planNote.textContent = upcoming.length ? `${upcoming.length} por tomar` : "";
  dom.planList.replaceChildren();

  entries.forEach((entry) => {
    const item = element("li", "plan-item");
    const isActive = entry.record && state.activeTimer?.recordId === entry.record.id;
    const isNext = !entry.record && entry === upcoming[0];
    if (entry.record) item.classList.add(isActive ? "is-active" : "is-done");
    if (isNext) item.classList.add("is-next");
    const marker = element("span", "plan-marker");
    if (entry.record && !isActive) marker.append(icon("i-check"));
    const time = element("span", "plan-time", isNext && plan.late ? "Ahora" : formatTime(entry.time));
    const label = element("span", "plan-label", `Descanso de ${entry.minutes} min`);
    const status = element("span", "plan-status", isActive ? "En curso" : entry.record ? "Hecho" : isNext ? "Siguiente" : "Sugerido");
    item.append(marker, time, label, status);
    dom.planList.append(item);
  });
}

function renderToday() {
  renderQuote();
  const plan = Core.planDay(state, mode);
  renderSegments();
  renderHero();
  renderSuggestion(plan);
  renderChoices();
  renderPlan(plan);
}

// ---------- Calendario ----------

function renderCalendar() {
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  dom.monthLabel.textContent = formatDate(visibleMonth, { month: "long", year: "numeric" });
  dom.calendarDays.replaceChildren();

  const maxMinutes = Math.max(Core.routineMinutes(state.settings, "long", todayKey()), Core.routineMinutes(state.settings, "short", todayKey()), 1);
  const offset = (new Date(year, month, 1).getDay() + 6) % 7;
  const today = todayKey();
  for (let index = 0; index < 42; index += 1) {
    const date = new Date(year, month, 1 - offset + index);
    const key = Core.dateKey(date);
    const dayRecords = Core.recordsFor(state.records, key);
    const minutes = dayRecords.reduce((sum, record) => sum + record.plannedMinutes, 0);
    const complete = Core.dayComplete(state, key);
    const off = state.daysOff.includes(key);

    const button = element("button", "calendar-day");
    button.type = "button";
    button.setAttribute("role", "gridcell");
    button.style.setProperty("--heat", Math.min(1, minutes / maxMinutes).toFixed(2));
    const dots = element("span", "day-dots");
    for (const routineMode of ["long", "short"]) {
      if (dayRecords.some((record) => record.mode === routineMode)) dots.append(element("i", `dot ${routineMode}`));
    }
    button.append(element("span", "day-number", String(date.getDate())), dots);
    const details = [plural(dayRecords.length, "descanso", "descansos")];
    if (complete) details.push("rutina completa");
    if (off) details.push("día libre");
    button.setAttribute("aria-label", `${formatDate(date)}: ${details.join(", ")}`);
    button.setAttribute("aria-pressed", String(key === selectedDate));
    button.classList.toggle("is-outside", date.getMonth() !== month);
    button.classList.toggle("is-today", key === today);
    button.classList.toggle("is-selected", key === selectedDate);
    button.classList.toggle("is-complete", complete);
    button.classList.toggle("is-off", off);
    button.classList.toggle("has-records", dayRecords.length > 0);
    button.addEventListener("click", () => {
      selectedDate = key;
      closeRecordForm();
      if (date.getMonth() !== month) visibleMonth = new Date(date.getFullYear(), date.getMonth(), 1);
      renderCalendar();
      renderDay();
    });
    dom.calendarDays.append(button);
  }
}

function renderTimeline(dayRecords) {
  dom.timeline.hidden = dayRecords.length === 0;
  dom.timelineTrack.replaceChildren();
  if (!dayRecords.length) return;

  const hourOf = (timestamp) => {
    const date = new Date(timestamp);
    return date.getHours() + date.getMinutes() / 60;
  };
  const starts = dayRecords.map((record) => hourOf(record.startedAt));
  const ends = dayRecords.map((record, index) => starts[index] + Math.max(record.plannedMinutes, actualMinutes(record)) / 60);
  const firstMode = dayRecords[0].mode;
  const dayHours = Core.profileFor(state.settings, dayRecords[0].day).hours[firstMode];
  const [workStart] = dayHours.start.split(":").map(Number);
  const [workEnd] = dayHours.end.split(":").map(Number);
  const from = Math.max(0, Math.min(workStart, Math.floor(Math.min(...starts))));
  const to = Math.min(24, Math.max(workEnd + 1, Math.ceil(Math.max(...ends))));
  const span = Math.max(1, to - from);

  dayRecords.forEach((record, index) => {
    const bar = element("i", `timeline-bar ${record.mode}`);
    if (Core.overtimeMinutes(record) > 0) bar.classList.add("is-overtime");
    bar.style.left = `${((starts[index] - from) / span) * 100}%`;
    bar.style.width = `max(4px, ${((ends[index] - starts[index]) / span) * 100}%)`;
    bar.title = `${formatTime(record.startedAt)} · ${record.plannedMinutes} min · ${MODE_NAMES[record.mode]}`;
    dom.timelineTrack.append(bar);
  });
  dom.timelineFrom.textContent = `${from}:00`;
  dom.timelineMid.textContent = `${Math.round((from + to) / 2)}:00`;
  dom.timelineTo.textContent = `${to}:00`;
}

function renderDay() {
  const dayRecords = Core.recordsFor(state.records, selectedDate);
  const isFuture = Core.dateFromKey(selectedDate) > new Date();
  const off = state.daysOff.includes(selectedDate);
  dom.selectedDateLabel.textContent = selectedDate === todayKey() ? `Hoy, ${formatDate(new Date(), { day: "numeric", month: "long" })}` : formatDate(Core.dateFromKey(selectedDate));
  dom.addRecord.hidden = isFuture;

  if (dayRecords.length) {
    const minutes = dayRecords.reduce((sum, record) => sum + record.plannedMinutes, 0);
    const overtime = dayRecords.reduce((sum, record) => sum + Core.overtimeMinutes(record), 0);
    const parts = [plural(dayRecords.length, "descanso", "descansos"), `${minutes} min`];
    for (const routineMode of ["long", "short"]) {
      if (!dayRecords.some((record) => record.mode === routineMode)) continue;
      const progress = Core.progressFor(state, routineMode, selectedDate);
      parts.push(`${routineMode === "long" ? "largo" : "corto"} ${progress.done}/${progress.total}`);
    }
    if (overtime) parts.push(`+${overtime} min extra`);
    dom.daySummary.textContent = capitalize(parts.join(" · "));
  } else {
    dom.daySummary.textContent = off ? "Día libre." : isFuture ? "Todavía no ha llegado." : "Sin descansos registrados.";
  }

  renderTimeline(dayRecords);
  dom.dayRecords.replaceChildren();
  dayRecords.forEach((record) => {
    const item = element("li", "record");
    const isActive = state.activeTimer?.recordId === record.id;
    const end = record.completedAt ? ` – ${formatTime(record.completedAt)}` : isActive ? " – en curso" : "";
    const info = element("div", "record-info");
    info.append(
      element("strong", "", `${formatTime(record.startedAt)}${end}`),
      element("span", "", `${MODE_NAMES[record.mode]} · ${record.plannedMinutes} min`)
    );
    const overtime = Core.overtimeMinutes(record);
    const tag = element("span", "record-tag", overtime ? `+${overtime} min` : "");
    tag.hidden = !overtime;
    tag.title = "Tiempo extra";
    const edit = element("button", "icon-btn icon-btn-sm");
    edit.type = "button";
    edit.append(icon("i-pencil"));
    edit.setAttribute("aria-label", `Editar descanso de las ${formatTime(record.startedAt)}`);
    edit.title = "Editar";
    edit.addEventListener("click", () => openRecordForm(record));
    const remove = element("button", "icon-btn icon-btn-sm danger");
    remove.type = "button";
    remove.append(icon("i-trash"));
    remove.setAttribute("aria-label", `Borrar descanso de las ${formatTime(record.startedAt)}`);
    remove.title = "Borrar";
    remove.addEventListener("click", () => {
      if (remove.classList.contains("is-confirming")) {
        deleteRecord(record.id);
        return;
      }
      remove.classList.add("is-confirming");
      remove.replaceChildren("¿Borrar?");
      setTimeout(() => {
        if (!remove.isConnected) return;
        remove.classList.remove("is-confirming");
        remove.replaceChildren(icon("i-trash"));
      }, 3000);
    });
    item.append(element("i", `dot ${record.mode}`), info, tag, edit, remove);
    dom.dayRecords.append(item);
  });

  dom.toggleDayOff.hidden = dayRecords.length > 0 && !off;
  dom.toggleDayOff.querySelector("span").textContent = off ? "Quitar día libre" : "Marcar como día libre";
}

// ---------- Progreso ----------

function renderWeekChart() {
  const days = Array.from({ length: 7 }, (_, index) => Core.addDays(todayKey(), index - 6));
  const values = days.map((day) => Core.recordsFor(state.records, day).reduce((sum, record) => sum + record.plannedMinutes, 0));
  const goal = Math.max(Core.routineMinutes(state.settings, "long", todayKey()), Core.routineMinutes(state.settings, "short", todayKey()));
  const scale = Math.max(goal, ...values, 1);
  dom.weekTotal.textContent = `${values.reduce((sum, value) => sum + value, 0)} min`;
  dom.weekChart.replaceChildren();
  dom.weekChart.setAttribute("aria-label", days.map((day, index) => `${formatDate(Core.dateFromKey(day), { weekday: "long" })}: ${values[index]} minutos`).join(". "));

  const goalLine = element("div", "chart-goal");
  goalLine.style.setProperty("--goal", (goal / scale).toFixed(3));
  goalLine.append(element("span", "", `Meta ${goal} min`));
  dom.weekChart.append(goalLine);

  days.forEach((day, index) => {
    const date = Core.dateFromKey(day);
    const column = element("div", "chart-col");
    column.tabIndex = 0;
    if (day === todayKey()) column.classList.add("is-today");
    const plot = element("div", "chart-plot");
    const bar = element("div", "chart-bar");
    bar.style.height = values[index] ? `max(4px, ${(values[index] / scale) * 100}%)` : "0";
    const tip = element("span", "chart-tip", `${formatDate(date, { weekday: "short", day: "numeric" })} · ${values[index]} min`);
    plot.append(bar, tip);
    column.append(plot, element("span", "chart-label", WEEKDAY_LETTERS[Core.weekdayIndex(date)]));
    dom.weekChart.append(column);
  });
}

function renderMonthStats() {
  const monthPrefix = Core.dateKey(visibleMonth).slice(0, 7);
  dom.monthStatsTitle.textContent = formatDate(visibleMonth, { month: "long", year: "numeric" });
  const monthRecords = state.records.filter((record) => record.day.startsWith(monthPrefix));
  const days = new Set(monthRecords.map((record) => record.day));
  let complete = 0;
  for (const day of days) {
    for (const routineMode of ["long", "short"]) if (Core.progressFor(state, routineMode, day).complete) complete += 1;
  }
  const finished = monthRecords.filter((record) => record.completedAt);
  const punctual = finished.filter((record) => Core.overtimeMinutes(record) === 0).length;
  const averageMinute = monthRecords.length
    ? Math.round(monthRecords.reduce((sum, record) => {
      const date = new Date(record.startedAt);
      return sum + date.getHours() * 60 + date.getMinutes();
    }, 0) / monthRecords.length)
    : null;

  $("#m-minutes").textContent = formatDuration(monthRecords.reduce((sum, record) => sum + record.plannedMinutes, 0));
  $("#m-days").textContent = String(days.size);
  $("#m-days").nextElementSibling.textContent = days.size === 1 ? "día con descansos" : "días con descansos";
  $("#m-complete").textContent = String(complete);
  $("#m-complete").nextElementSibling.textContent = complete === 1 ? "rutina completa" : "rutinas completas";
  $("#m-punctual").textContent = finished.length ? `${Math.round((punctual / finished.length) * 100)} %` : "—";
  $("#m-hour").textContent = averageMinute === null ? "—" : `${String(Math.floor(averageMinute / 60)).padStart(2, "0")}:${String(averageMinute % 60).padStart(2, "0")}`;
  $("#m-overtime").textContent = `${monthRecords.reduce((sum, record) => sum + Core.overtimeMinutes(record), 0)} min`;
}

function renderGarden() {
  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const offset = (new Date(year, month, 1).getDay() + 6) % 7;
  const today = todayKey();
  let flowers = 0;
  dom.garden.replaceChildren();
  for (let index = 0; index < offset; index += 1) dom.garden.append(element("span", "garden-cell is-empty"));

  for (let dayNumber = 1; dayNumber <= daysInMonth; dayNumber += 1) {
    const key = Core.dateKey(new Date(year, month, dayNumber));
    const cell = element("span", "garden-cell");
    let plant = null;
    let label = "sin descansos";
    if (Core.dayComplete(state, key)) {
      const rare = Core.runLength(state, key) >= 5;
      plant = rare ? "g-rare" : "g-flower";
      label = rare ? "flor especial por racha" : "flor, rutina completa";
      flowers += 1;
    } else if (state.daysOff.includes(key)) {
      plant = "g-rest";
      label = "día libre";
    } else if (Core.recordsFor(state.records, key).length) {
      plant = "g-sprout";
      label = "brote, rutina en camino";
    }
    if (plant) cell.append(icon(plant, "plant"));
    else cell.append(element("i", key > today ? "soil is-future" : "soil"));
    cell.append(element("span", "garden-day", String(dayNumber)));
    cell.title = `${dayNumber}: ${label}`;
    if (key === today) cell.classList.add("is-today");
    dom.garden.append(cell);
  }
  dom.gardenCaption.textContent = flowers
    ? `${plural(flowers, "flor", "flores")} en ${formatDate(visibleMonth, { month: "long" }).toLowerCase()}. Cada rutina completa florece.`
    : "Completa una rutina para plantar tu primera flor.";
}

function renderProgress() {
  renderWeekChart();
  renderMonthStats();
  renderGarden();
}

// ---------- Planta y jardín ----------

// La planta del anillo pasa de semilla a flor según los descansos de hoy (0 = semilla, 1 = flor).
let plantGrowth = 0;
let plantTarget = -1;
let plantFrame = null;

const clamp01 = (value) => Math.max(0, Math.min(1, value));
// Pequeño rebote al final para que hojas y flor "broten".
const easeOutBack = (t) => 1 + 2.2 * Math.pow(t - 1, 3) + 1.2 * Math.pow(t - 1, 2);

function setPlantShape(growth) {
  const stage = (from, span) => Math.max(0, easeOutBack(clamp01((growth - from) / span)));
  const bloom = stage(0.96, 0.04);
  const style = dom.growPlant.style;
  style.setProperty("--seed", clamp01(1 - growth * 14).toFixed(3));
  style.setProperty("--stem-on", growth > 0.004 ? "1" : "0");
  style.setProperty("--stem", clamp01(1.15 * Math.pow(growth, 0.6)).toFixed(3));
  style.setProperty("--l1", stage(0.06, 0.14).toFixed(3));
  style.setProperty("--l2", stage(0.3, 0.15).toFixed(3));
  style.setProperty("--l3", stage(0.55, 0.15).toFixed(3));
  style.setProperty("--bud", (stage(0.78, 0.12) * (1 - clamp01(bloom))).toFixed(3));
  style.setProperty("--bloom", bloom.toFixed(3));
  dom.growPlant.classList.toggle("is-bloomed", growth >= 0.999);
}

// Anima la planta hasta `target` fotograma a fotograma. Al abrir la extensión crece desde la semilla.
function growPlantTo(target, duration) {
  const goal = clamp01(target);
  if (Math.abs(goal - plantTarget) < 0.0001) return;
  const first = plantTarget < 0;
  plantTarget = goal;
  cancelAnimationFrame(plantFrame);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
    plantGrowth = goal;
    setPlantShape(goal);
    return;
  }
  const from = plantGrowth;
  const time = duration ?? (first ? 2200 : 1400);
  const smallStep = Math.abs(goal - from) < 0.02;
  const start = performance.now();
  const step = (now) => {
    const t = clamp01((now - start) / time);
    // Los avances segundo a segundo van a velocidad constante; los saltos grandes, con frenada suave.
    const eased = smallStep ? t : 1 - Math.pow(1 - t, 3);
    plantGrowth = from + (goal - from) * eased;
    setPlantShape(plantGrowth);
    if (t < 1) plantFrame = requestAnimationFrame(step);
  };
  plantFrame = requestAnimationFrame(step);
}

// Jardín de fondo: cada día completo planta una flor que con las semanas se convierte en arbusto y árbol.
function gardenEntries() {
  return [...new Set(state.records.map((record) => record.day))].map((day) => ({ day, complete: Core.dayComplete(state, day) }));
}

function renderGardenBackground() {
  const entries = gardenEntries();
  const signature = `${todayKey()}|${entries.map((entry) => `${entry.day}${entry.complete ? 1 : 0}`).join()}`;
  if (dom.gardenBg.dataset.signature === signature) return;
  dom.gardenBg.dataset.signature = signature;
  PausaGarden.render(dom.gardenBg, entries, todayKey(), { animateNew: true });
}

// ---------- Render general ----------

function render() {
  dom.body.dataset.theme = state.settings.theme;
  renderHeader();
  renderToday();
  renderCalendar();
  renderDay();
  renderProgress();
  renderGardenBackground();
}

function showView(name) {
  view = name;
  $$(".view").forEach((section) => {
    const active = section.id === `view-${name}`;
    section.hidden = !active;
    section.classList.toggle("is-active", active);
  });
  $$(".tab").forEach((tab) => {
    const active = tab.dataset.viewTarget === name;
    tab.classList.toggle("is-active", active);
    if (active) tab.setAttribute("aria-current", "page");
    else tab.removeAttribute("aria-current");
  });
  dom.views.scrollTop = 0;
  if (name === "settings") renderSettings();
  updateLinkPolling();
}

function celebrate() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const layer = element("div", "confetti");
  layer.setAttribute("aria-hidden", "true");
  for (let index = 0; index < 36; index += 1) {
    const piece = element("i");
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.animationDelay = `${Math.random() * 0.4}s`;
    piece.style.setProperty("--drift", `${(Math.random() - 0.5) * 140}px`);
    piece.style.setProperty("--spin", `${Math.random() * 720 - 360}deg`);
    piece.dataset.tone = String(index % 3);
    layer.append(piece);
  }
  document.body.append(layer);
  setTimeout(() => layer.remove(), 2400);
}

// ---------- Acciones ----------

async function persist(keys) {
  const payload = {};
  for (const key of keys) payload[key] = state[key];
  await chrome.storage.local.set(payload);
}

async function registerBreak(minutes) {
  if (state.activeTimer) return;
  const wasComplete = Core.progressFor(state, mode, todayKey()).complete;
  const { record, activeTimer } = Core.createBreak(mode, minutes, state.settings.timerEnabled);
  state.records = [...state.records, record];
  state.activeTimer = activeTimer;
  state.returnQuote = null;
  breathing = false;
  tipIndex = (tipIndex + 1) % TIPS.length;
  await persist(["records", "activeTimer", "returnQuote"]);
  // Sin cuenta atrás no hay "Ya volví": la frase aparece al registrar.
  if (!activeTimer) await drawReturnQuote(record.id);
  showToast(`Descanso de ${minutes} min iniciado a las ${formatTime(record.startedAt)}`);
  render();
  if (!wasComplete && Core.progressFor(state, mode, todayKey()).complete) celebrate();
}

// Si el móvil ya recibió una frase para este descanso, se muestra la misma.
async function drawReturnQuote(recordId) {
  if (state.returnQuote?.recordId === recordId) return;
  const { quoteDeck } = await chrome.storage.local.get("quoteDeck");
  const { index, deck } = PausaQuotes.drawQuote(quoteDeck);
  state.returnQuote = { index, recordId, at: Date.now() };
  await chrome.storage.local.set({ quoteDeck: deck, returnQuote: state.returnQuote });
}

function renderQuote() {
  const quote = state.returnQuote && !state.activeTimer ? PausaQuotes.QUOTES[state.returnQuote.index] : null;
  dom.quoteCard.hidden = !quote;
  if (!quote) return;
  dom.quoteText.textContent = quote.text;
  dom.quoteAuthor.textContent = quote.author;
}

async function finishTimer() {
  const timer = state.activeTimer;
  if (!timer) return;
  const now = Date.now();
  state.records = Core.closeActive(state.records, timer, now);
  state.activeTimer = null;
  breathing = false;
  await persist(["records", "activeTimer"]);
  await drawReturnQuote(timer.recordId);
  dom.views.scrollTop = 0;
  const record = state.records.find((item) => item.id === timer.recordId);
  const overtime = record ? Core.overtimeMinutes(record) : 0;
  showToast(overtime ? `De vuelta · ${overtime} min más de lo previsto` : "De vuelta a tiempo");
  render();
}

async function deleteRecord(id, message = "Descanso borrado") {
  const before = snapshot();
  state.records = state.records.filter((item) => item.id !== id);
  if (state.activeTimer?.recordId === id) state.activeTimer = null;
  if (editingId === id) closeRecordForm();
  await persist(["records", "activeTimer"]);
  showToast(message, () => restoreSnapshot(before));
  render();
}

// Alarga el descanso en curso sin cambiar su duración prevista (la rutina sigue contando igual).
async function extendTimer(minutes) {
  if (!state.activeTimer) return;
  const before = snapshot();
  const timer = state.activeTimer;
  // Si ya te habías pasado, los minutos se cuentan desde ahora.
  const endAt = Math.max(timer.endAt, Date.now()) + minutes * MINUTE;
  state.activeTimer = { ...timer, endAt, extraMinutes: Math.round((endAt - timer.startedAt) / MINUTE) - timer.minutes };
  await persist(["activeTimer"]);
  showToast(`Descanso alargado ${minutes} min`, () => restoreSnapshot(before));
  renderToday();
}

// Vuelve a empezar la cuenta atrás desde ahora (por ejemplo, si lo pulsaste antes de levantarte).
async function restartTimer() {
  if (!state.activeTimer) return;
  const before = snapshot();
  const now = Date.now();
  const timer = state.activeTimer;
  state.activeTimer = { ...timer, startedAt: now, endAt: now + timer.minutes * MINUTE, extraMinutes: 0 };
  state.records = state.records.map((record) => (record.id === timer.recordId ? { ...record, startedAt: now } : record));
  await persist(["records", "activeTimer"]);
  showToast(`Cuenta atrás reiniciada a las ${formatTime(now)}`, () => restoreSnapshot(before));
  render();
}

function openRecordForm(record = null) {
  editingId = record?.id || null;
  dom.recordFormTitle.textContent = record ? "Editar descanso" : "Añadir descanso";
  dom.recordMode.value = record?.mode || mode;
  if (record) {
    dom.recordMinutes.value = record.plannedMinutes;
    dom.recordStart.value = timeInputValue(record.startedAt);
    dom.recordEnd.value = record.completedAt ? timeInputValue(record.completedAt) : "";
  } else {
    const progress = Core.progressFor(state, dom.recordMode.value, selectedDate);
    const next = progress.groups.find((group) => group.remaining > 0) || progress.groups[0];
    dom.recordMinutes.value = next?.minutes || 5;
    dom.recordStart.value = selectedDate === todayKey() ? timeInputValue(Date.now()) : "12:00";
    dom.recordEnd.value = "";
  }
  dom.recordFormMessage.textContent = "";
  dom.recordForm.hidden = false;
  revealInViews(dom.recordForm, false);
  dom.recordMinutes.focus();
}

function closeRecordForm() {
  editingId = null;
  dom.recordForm.hidden = true;
  dom.recordFormMessage.textContent = "";
}

async function saveRecordForm(event) {
  event.preventDefault();
  const fail = (message) => { dom.recordFormMessage.textContent = message; };
  const minutes = Number(dom.recordMinutes.value);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 120) return fail("La duración debe ser de 1 a 120 minutos.");
  if (!dom.recordStart.value) return fail("Indica la hora de inicio.");
  const startedAt = Core.timestampFor(selectedDate, dom.recordStart.value);
  if (startedAt > Date.now()) return fail("La hora de inicio no puede estar en el futuro.");
  let completedAt = null;
  if (dom.recordEnd.value) {
    completedAt = Core.timestampFor(selectedDate, dom.recordEnd.value);
    if (completedAt <= startedAt) return fail("La vuelta debe ser posterior al inicio.");
    if (completedAt > Date.now()) return fail("La hora de vuelta no puede estar en el futuro.");
  }

  const fields = { day: selectedDate, mode: dom.recordMode.value, startedAt, plannedMinutes: minutes, completedAt };
  const wasEditing = Boolean(editingId);
  if (editingId) {
    state.records = state.records.map((record) => (record.id === editingId ? { ...record, ...fields } : record));
    if (state.activeTimer?.recordId === editingId) {
      state.activeTimer = completedAt ? null : { ...state.activeTimer, startedAt, endAt: startedAt + minutes * MINUTE, minutes };
    }
  } else {
    state.records = [...state.records, { id: crypto.randomUUID(), ...fields }];
  }
  closeRecordForm();
  await persist(["records", "activeTimer"]);
  showToast(wasEditing ? "Descanso actualizado" : "Descanso añadido");
  render();
}

async function toggleDayOff(day = selectedDate) {
  const before = snapshot();
  const off = state.daysOff.includes(day);
  state.daysOff = off ? state.daysOff.filter((item) => item !== day) : [...state.daysOff, day];
  await persist(["daysOff"]);
  const label = day === todayKey() ? "Hoy" : "El día";
  showToast(off ? `${label} vuelve a ser laborable` : `${label} queda como día libre`, () => restoreSnapshot(before));
  render();
}

function changeMonth(step) {
  visibleMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + step, 1);
  if (selectedDate.slice(0, 7) !== Core.dateKey(visibleMonth).slice(0, 7)) selectedDate = Core.dateKey(visibleMonth);
  closeRecordForm();
  renderCalendar();
  renderDay();
  renderProgress();
}

// ---------- Ajustes ----------

async function saveSettings(message = "Cambios guardados") {
  await persist(["settings"]);
  showToast(message);
  render();
}

function renderWeekdayModes() {
  dom.weekdayModes.replaceChildren();
  state.settings.weekdayModes.forEach((value, index) => {
    const button = element("button", `weekday is-${value}`);
    button.type = "button";
    button.append(element("span", "", WEEKDAY_LETTERS[index]), element("strong", "", WEEKDAY_VALUE_LABEL[value]));
    const dayName = formatDate(new Date(2024, 0, 1 + index), { weekday: "long" });
    button.setAttribute("aria-label", `${dayName}: ${value === "none" ? "sin jornada" : MODE_NAMES[value].toLowerCase()}. Pulsa para cambiar.`);
    button.addEventListener("click", () => {
      state.settings.weekdayModes[index] = WEEKDAY_CYCLE[value];
      renderWeekdayModes();
      saveSettings();
    });
    dom.weekdayModes.append(button);
  });
}

function fillRoutineInputs(routines) {
  $$(".routine-row input").forEach((input) => {
    input.value = routines[input.dataset.mode][input.dataset.kind][input.dataset.field];
  });
}

function renderShortcuts() {
  const labels = {
    "start-break": "Empezar el descanso sugerido",
    "finish-break": "Ya volví",
    _execute_action: "Abrir Pausa Bloom"
  };
  dom.shortcutList.replaceChildren();
  for (const name of ["start-break", "finish-break", "_execute_action"]) {
    const item = element("li");
    const keys = element("span", "keys");
    const shortcut = shortcuts[name];
    if (shortcut) shortcut.split("+").forEach((key) => keys.append(element("kbd", "", key)));
    else keys.append(element("span", "muted", "Sin asignar"));
    item.append(element("span", "", labels[name]), keys);
    dom.shortcutList.append(item);
  }
}

function renderSettings() {
  const { settings } = state;
  $$('input[name="theme"]').forEach((input) => { input.checked = input.value === settings.theme; });
  dom.longIcon.value = settings.icons.long;
  dom.shortIcon.value = settings.icons.short;
  if (!settings.profiles.some((profile) => profile.id === editingProfileId)) editingProfileId = Core.profileFor(settings, todayKey()).id;
  renderProfiles();
  renderWeeks();
  renderWeekdayModes();
  $("#suggest-lead").value = String(settings.suggestLead);
  $("#overtime-alert").value = String(settings.overtimeAlert);
  dom.timerEnabled.checked = settings.timerEnabled;
  dom.endAlert.checked = settings.endAlert;
  dom.suggestAlert.checked = settings.suggestAlert;
  dom.soundSelect.value = settings.sound;
  dom.hoursError.textContent = "";
  dom.routineError.textContent = "";
  dom.alertsError.textContent = "";
  renderShortcuts();
  renderPhone();
}

// ---------- Horarios (perfiles) y semanas ----------

let editingProfileId = null;
const PLAN_HELP = {
  spread: "Repartimos los descansos de forma equilibrada hasta el final de la jornada; los más largos, hacia la mitad.",
  interval: "Te toca un descanso cada cierto tiempo de trabajo, contando desde el último descanso (o desde el inicio de la jornada).",
  fixed: "Escribe tú a qué hora va cada descanso y cuánto dura. La rutina del día será esta lista."
};

function editingProfile() {
  return state.settings.profiles.find((profile) => profile.id === editingProfileId) || state.settings.profiles[0];
}

function profileOptions(select, selectedId) {
  select.replaceChildren(...state.settings.profiles.map((profile) => new Option(profile.name, profile.id, false, profile.id === selectedId)));
}

function renderProfiles() {
  const profile = editingProfile();
  profileOptions($("#profile-select"), profile.id);
  $("#profile-delete").hidden = state.settings.profiles.length < 2;
  $("#profile-name").value = profile.name;
  $$("[data-hours]").forEach((input) => { input.value = profile.hours[input.dataset.hours][input.dataset.edge]; });
  $$('input[name="plan-mode"]').forEach((input) => { input.checked = input.value === profile.plan.mode; });
  $("#plan-help").textContent = PLAN_HELP[profile.plan.mode];
  $("#interval-row").hidden = profile.plan.mode !== "interval";
  $("#fixed-editor").hidden = profile.plan.mode !== "fixed";
  $("#routines-block").hidden = profile.plan.mode === "fixed";
  $("#plan-interval").value = profile.plan.interval;
  fillRoutineInputs(profile.routines);
  renderFixedList("long");
  renderFixedList("short");
  dom.hoursError.textContent = "";
  dom.routineError.textContent = "";
}

function renderFixedList(routineMode) {
  const list = $(`.fixed-list[data-fixed="${routineMode}"]`);
  const slots = editingProfile().plan.fixed[routineMode];
  list.replaceChildren();
  if (!slots.length) list.append(element("li", "fixed-empty", "Sin horas todavía"));
  slots.forEach((slot, index) => {
    const item = element("li", "fixed-item");
    const time = element("input");
    time.type = "time";
    time.value = slot.time;
    time.setAttribute("aria-label", `Hora del descanso ${index + 1}`);
    const minutes = element("input");
    minutes.type = "number";
    minutes.min = "1";
    minutes.max = "120";
    minutes.value = slot.minutes;
    minutes.setAttribute("aria-label", `Minutos del descanso ${index + 1}`);
    const remove = element("button", "icon-btn icon-btn-sm danger");
    remove.type = "button";
    remove.append(icon("i-x"));
    remove.setAttribute("aria-label", `Quitar el descanso de las ${slot.time}`);
    const update = () => {
      const value = Number(minutes.value);
      if (!time.value || !Number.isInteger(value) || value < 1 || value > 120) {
        dom.routineError.textContent = "Cada hora fija necesita una hora y una duración de 1 a 120 minutos.";
        return;
      }
      dom.routineError.textContent = "";
      const current = editingProfile().plan.fixed[routineMode];
      current[index] = { time: time.value, minutes: value };
      current.sort((a, b) => a.time.localeCompare(b.time));
      saveSettings("Horas fijas guardadas");
      renderFixedList(routineMode);
    };
    time.addEventListener("change", update);
    minutes.addEventListener("change", update);
    remove.addEventListener("click", () => {
      editingProfile().plan.fixed[routineMode].splice(index, 1);
      saveSettings("Hora fija quitada");
      renderFixedList(routineMode);
    });
    item.append(time, minutes, element("span", "muted", "min"), remove);
    list.append(item);
  });
}

function addFixedSlot(routineMode) {
  const profile = editingProfile();
  const slots = profile.plan.fixed[routineMode];
  // Propone una hora después de la última (o una hora después del inicio de la jornada).
  const lastTime = slots.length ? slots[slots.length - 1].time : profile.hours[routineMode].start;
  const [hours, minutes] = lastTime.split(":").map(Number);
  const next = Math.min(23 * 60 + 55, hours * 60 + minutes + 60);
  slots.push({ time: `${String(Math.floor(next / 60)).padStart(2, "0")}:${String(next % 60).padStart(2, "0")}`, minutes: 5 });
  slots.sort((a, b) => a.time.localeCompare(b.time));
  saveSettings("Hora fija añadida");
  renderFixedList(routineMode);
}

function addProfile() {
  const source = editingProfile();
  const id = `p${Date.now().toString(36)}`;
  const copy = { ...structuredClone(source), id, name: `${source.name} (copia)` };
  state.settings.profiles.push(copy);
  editingProfileId = id;
  saveSettings("Horario creado: cámbiale el nombre y ajústalo");
  renderProfiles();
  renderWeeks();
  $("#profile-name").select();
}

async function deleteProfile() {
  if (state.settings.profiles.length < 2) return;
  const before = snapshot();
  const removed = editingProfile();
  state.settings.profiles = state.settings.profiles.filter((profile) => profile.id !== removed.id);
  if (state.settings.defaultProfile === removed.id) state.settings.defaultProfile = state.settings.profiles[0].id;
  for (const [week, id] of Object.entries(state.settings.weekProfiles)) {
    if (id === removed.id) delete state.settings.weekProfiles[week];
  }
  editingProfileId = state.settings.defaultProfile;
  await persist(["settings"]);
  renderProfiles();
  renderWeeks();
  render();
  showToast(`Horario «${removed.name}» borrado`, () => restoreSnapshot(before));
}

function renderWeeks() {
  const { settings } = state;
  profileOptions($("#default-profile"), settings.defaultProfile);
  const list = $("#week-list");
  list.replaceChildren();
  const thisWeek = Core.weekStart(todayKey());
  for (let index = 0; index < 8; index += 1) {
    const week = Core.addDays(thisWeek, index * 7);
    const sunday = Core.dateFromKey(Core.addDays(week, 6));
    const monday = Core.dateFromKey(week);
    const item = element("li", "week-item");
    const label = element("div", "week-label");
    label.append(
      element("strong", "", index === 0 ? "Esta semana" : index === 1 ? "La próxima" : `Semana ${index + 1}`),
      element("span", "", `${monday.getDate()} ${formatDate(monday, { month: "short" }).replace(".", "")} – ${sunday.getDate()} ${formatDate(sunday, { month: "short" }).replace(".", "")}`)
    );
    const select = element("select");
    select.setAttribute("aria-label", `Horario de la semana del ${formatDate(monday, { day: "numeric", month: "long" })}`);
    select.append(new Option("Por defecto", ""));
    settings.profiles.forEach((profile) => select.append(new Option(profile.name, profile.id)));
    select.value = settings.weekProfiles[week] || "";
    select.classList.toggle("is-custom", Boolean(settings.weekProfiles[week]));
    select.addEventListener("change", () => {
      if (select.value) state.settings.weekProfiles[week] = select.value;
      else delete state.settings.weekProfiles[week];
      saveSettings(select.value ? "Horario de la semana guardado" : "La semana usa el horario por defecto");
      renderWeeks();
    });
    item.append(label, select);
    list.append(item);
  }
}

function readRoutineInputs() {
  const routines = structuredClone(editingProfile().routines);
  for (const input of $$(".routine-row input")) {
    const value = Number(input.value);
    const isCount = input.dataset.field === "count";
    if (!Number.isInteger(value) || (isCount ? value < 0 || value > 30 : value < 1 || value > 120)) {
      throw new Error("Usa cantidades de 0 a 30 y duraciones de 1 a 120 minutos.");
    }
    routines[input.dataset.mode][input.dataset.kind][input.dataset.field] = value;
  }
  for (const routineMode of ["long", "short"]) {
    if (![5, 10, 15].some((kind) => routines[routineMode][kind].count > 0)) {
      throw new Error(`Añade al menos un descanso al ${routineMode === "long" ? "día largo" : "día corto"}.`);
    }
  }
  return routines;
}

async function ensureNotificationPermission(checkbox) {
  if (!checkbox.checked) return true;
  // Se pide directamente: si ya estaba concedido, Chrome responde que sí sin preguntar.
  const granted = await chrome.permissions.request({ permissions: ["notifications"] });
  if (!granted) {
    checkbox.checked = false;
    dom.alertsError.textContent = "Para avisarte hace falta el permiso de notificaciones del navegador.";
  }
  return granted;
}

function csvEscape(value) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function download(filename, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportCsv() {
  const header = ["Fecha", "Hora de inicio", "Rutina", "Duracion (min)", "Hora de vuelta", "Tiempo extra (min)"];
  const rows = [...state.records]
    .sort((a, b) => a.startedAt - b.startedAt)
    .map((record) => [
      record.day,
      formatTime(record.startedAt),
      record.mode === "long" ? "Dia largo" : "Dia corto",
      record.plannedMinutes,
      record.completedAt ? formatTime(record.completedAt) : "",
      Core.overtimeMinutes(record)
    ]);
  const content = [header, ...rows].map((row) => row.map(csvEscape).join(",")).join("\r\n");
  download(`pausa-bloom-${todayKey()}.csv`, `﻿${content}`, "text/csv;charset=utf-8");
  showToast("Historial exportado en CSV");
}

function exportBackup() {
  const backup = {
    app: "pausa-bloom",
    version: 3,
    exportedAt: new Date().toISOString(),
    // El código del bot de Telegram no se guarda en la copia.
    settings: { ...state.settings, telegram: undefined },
    records: state.records,
    daysOff: state.daysOff
  };
  download(`pausa-bloom-copia-${todayKey()}.json`, JSON.stringify(backup, null, 2), "application/json");
  showToast("Copia de seguridad creada");
}

function isValidRecord(record) {
  return record && typeof record.id === "string" && /^\d{4}-\d{2}-\d{2}$/.test(record.day)
    && (record.mode === "long" || record.mode === "short")
    && Number.isFinite(record.startedAt) && Number.isInteger(record.plannedMinutes)
    && (record.completedAt === null || record.completedAt === undefined || Number.isFinite(record.completedAt));
}

async function importBackup(file) {
  try {
    const backup = JSON.parse(await file.text());
    if (backup?.app !== "pausa-bloom" || !Array.isArray(backup.records)) throw new Error();
    const valid = backup.records.filter(isValidRecord).map((record) => ({ ...record, completedAt: record.completedAt ?? null }));
    const known = new Set(state.records.map((record) => record.id));
    const added = valid.filter((record) => !known.has(record.id));
    state.records = [...state.records, ...added];
    const importedDaysOff = Array.isArray(backup.daysOff) ? backup.daysOff.filter((day) => /^\d{4}-\d{2}-\d{2}$/.test(day)) : [];
    state.daysOff = [...new Set([...state.daysOff, ...importedDaysOff])];
    if (backup.settings) state.settings = Core.mergeSettings({ ...backup.settings, telegram: state.settings.telegram });
    await persist(["records", "daysOff", "settings"]);
    renderSettings();
    render();
    showToast(`Copia restaurada · ${plural(added.length, "descanso nuevo", "descansos nuevos")}`);
  } catch {
    showToast("Ese archivo no es una copia válida de Pausa Bloom");
  }
}

// ---------- Restablecer ----------

const RESET_MESSAGES = {
  today: "Descansos de hoy reiniciados",
  schedules: "Horarios y rutinas restablecidos",
  settings: "Ajustes restablecidos",
  history: "Historial borrado",
  all: "Todo borrado: la extensión está como nueva"
};

async function runReset(kind) {
  const before = snapshot();
  // "Todo" también borra el tutorial visto, el orden de las frases, etc.: se guarda una copia completa.
  const fullBackup = kind === "all" ? await chrome.storage.local.get(null) : null;

  if (kind === "today") {
    const today = todayKey();
    state.records = state.records.filter((record) => record.day !== today);
    if (state.activeTimer && !state.records.some((record) => record.id === state.activeTimer.recordId)) state.activeTimer = null;
    state.returnQuote = null;
    await persist(["records", "activeTimer", "returnQuote"]);
  } else if (kind === "schedules") {
    Object.assign(state.settings, {
      profiles: [Core.mergeProfile(Core.DEFAULT_PROFILE)],
      defaultProfile: Core.DEFAULT_PROFILE.id,
      weekProfiles: {}
    });
    editingProfileId = Core.DEFAULT_PROFILE.id;
    await persist(["settings"]);
  } else if (kind === "settings") {
    state.settings = Core.mergeSettings({ telegram: state.settings.telegram });
    await persist(["settings"]);
  } else if (kind === "history") {
    Object.assign(state, { records: [], activeTimer: null, daysOff: [], returnQuote: null });
    await persist(["records", "activeTimer", "daysOff", "returnQuote"]);
  } else if (kind === "all") {
    Object.assign(state, { settings: Core.mergeSettings(), records: [], activeTimer: null, daysOff: [], returnQuote: null });
    await chrome.storage.local.clear();
    await persist(["settings"]);
  }

  closeRecordForm();
  renderSettings();
  render();
  const undo = fullBackup
    ? async () => {
      await chrome.storage.local.clear();
      await chrome.storage.local.set(fullBackup);
      await restoreSnapshot(before);
    }
    : () => restoreSnapshot(before);
  showToast(RESET_MESSAGES[kind], undo);
}

function handleResetClick(button) {
  // Las acciones que borran datos piden un segundo clic.
  if (button.dataset.confirm && !button.classList.contains("is-confirming")) {
    const label = button.textContent;
    button.classList.add("is-confirming");
    button.textContent = "¿Seguro?";
    setTimeout(() => {
      button.classList.remove("is-confirming");
      button.textContent = label;
    }, 3500);
    return;
  }
  if (button.classList.contains("is-confirming")) {
    button.classList.remove("is-confirming");
    button.textContent = button.dataset.reset === "all" ? "Borrar todo" : "Borrar";
  }
  runReset(button.dataset.reset);
}

// ---------- Móvil (Telegram) ----------

let linkPoll = null;
let checkingLink = false;

function renderPhone() {
  const telegram = state.settings.telegram;
  const linked = PausaTelegram.isLinked(telegram);
  const waiting = Boolean(telegram.token && telegram.botUsername && !linked);
  $("#phone-setup").hidden = linked || waiting;
  $("#phone-link").hidden = !waiting;
  $("#phone-ready").hidden = !linked;

  const botfatherQr = $("#botfather-qr");
  if (!linked && !waiting && !botfatherQr.firstChild) botfatherQr.append(PausaQR.toSvg("https://t.me/BotFather"));

  if (waiting) {
    const url = PausaTelegram.linkUrl(telegram);
    const box = $("#telegram-qr");
    if (box.dataset.url !== url) {
      box.replaceChildren(PausaQR.toSvg(url));
      box.dataset.url = url;
      box.setAttribute("aria-label", `Código QR para conectar el móvil con @${telegram.botUsername}`);
    }
  }
  if (linked) {
    $("#phone-name").textContent = `Conectado con ${telegram.chatName} · @${telegram.botUsername}`;
    $("#phone-end").checked = telegram.onEnd;
    $("#phone-suggest").checked = telegram.onSuggest;
    $("#phone-overtime").checked = telegram.onOvertime;
  }
  updateLinkPolling();
}

// Mientras se muestra el QR, pregunta a Telegram cada pocos segundos si ya pulsaste "Iniciar".
function updateLinkPolling() {
  const telegram = state.settings.telegram;
  const shouldPoll = view === "settings" && Boolean(telegram.token && telegram.botUsername && !telegram.chatId);
  if (shouldPoll && !linkPoll) linkPoll = setInterval(checkLink, 2500);
  if (!shouldPoll && linkPoll) {
    clearInterval(linkPoll);
    linkPoll = null;
  }
}

async function checkLink() {
  if (checkingLink) return;
  checkingLink = true;
  try {
    const telegram = state.settings.telegram;
    const found = await PausaTelegram.findLink(telegram);
    if (!found) return;
    state.settings.telegram = { ...telegram, ...found, linkCode: "" };
    await persist(["settings"]);
    await PausaTelegram.send(state.settings.telegram, "🌸 ¡Listo! Pausa Bloom ya puede avisarte aquí cuando termine tu descanso o llegue la hora de descansar.");
    $("#phone-error").textContent = "";
    showToast("Móvil conectado");
    renderPhone();
  } catch (error) {
    $("#phone-error").textContent = `No se pudo comprobar la conexión: ${error.message}`;
  } finally {
    checkingLink = false;
  }
}

async function saveTelegramToken() {
  const error = $("#phone-error");
  const button = $("#telegram-save");
  error.textContent = "";
  // El permiso se pide lo primero, mientras Chrome aún considera que viene de tu clic.
  if (!(await PausaTelegram.requestPermission())) {
    error.textContent = "Hace falta permitir la conexión con Telegram para enviarte avisos.";
    return;
  }
  const token = $("#telegram-token").value.trim();
  if (!PausaTelegram.TOKEN_PATTERN.test(token)) {
    error.textContent = "Ese código no parece válido. Cópialo entero desde el mensaje de @BotFather.";
    return;
  }
  button.disabled = true;
  button.textContent = "Comprobando…";
  try {
    const bot = await PausaTelegram.call(token, "getMe");
    state.settings.telegram = {
      ...state.settings.telegram,
      token,
      botUsername: bot.username,
      linkCode: PausaTelegram.newLinkCode(),
      chatId: null,
      chatName: ""
    };
    await persist(["settings"]);
    $("#telegram-token").value = "";
    renderPhone();
  } catch {
    error.textContent = "Telegram no reconoce ese código. Revisa que lo hayas copiado entero.";
  } finally {
    button.disabled = false;
    button.textContent = "Continuar";
  }
}

async function resetTelegram(message) {
  const { onEnd, onSuggest, onOvertime } = state.settings.telegram;
  state.settings.telegram = { ...Core.DEFAULT_SETTINGS.telegram, onEnd, onSuggest, onOvertime };
  $("#phone-error").textContent = "";
  await persist(["settings"]);
  renderPhone();
  if (message) showToast(message);
}

// ---------- Tutorial ----------

const TOUR_STEPS = [
  {
    title: "Te damos la bienvenida a Pausa Bloom",
    text: "Te ayuda a tomar tus descansos a la mejor hora y a llevar un registro sin esfuerzo. Te enseñamos lo básico en menos de un minuto."
  },
  {
    target: ".segmented",
    title: "Elige tu jornada",
    text: "Cambia entre día largo (6 de 5 min y 2 de 10 min) y día corto (5 de 5 min y 1 de 15 min). En Ajustes puedes hacer que se elija sola según el día de la semana."
  },
  {
    target: "#hero",
    title: "Tu progreso de un vistazo",
    text: "Con cada descanso la planta del centro crece hasta florecer al completar la rutina. Durante un descanso, el anillo se convierte en una cuenta atrás."
  },
  {
    demo: true,
    title: "Tu jardín se convierte en bosque",
    text: "Cada día con la rutina completa planta una flor de una especie distinta. Con las semanas se convierte en arbusto y después en árbol, y el paisaje cambia con las estaciones. Así se vería en un año:"
  },
  {
    target: "#suggestion",
    title: "La mejor hora para descansar",
    text: "Según tu horario, repartimos los descansos a lo largo de la jornada y te decimos cuándo tomar el siguiente. Los más largos quedan hacia la mitad del día."
  },
  {
    target: "#choices",
    title: "Un clic y listo",
    text: "Pulsa la duración del descanso que vas a tomar: se guarda la hora y empieza la cuenta atrás. Al volver, pulsa «Ya volví» y te espera una frase para seguir con energía."
  },
  {
    target: "#plan-card",
    title: "Tu plan del día",
    text: "Aquí ves los descansos que ya tomaste y los que te sugerimos, en orden. El plan se recalcula cada vez que descansas."
  },
  {
    target: '[data-view-target="calendar"]',
    title: "Calendario",
    text: "Revisa cualquier día del mes, añade descansos olvidados, corrige horas o marca días libres para no romper tu racha."
  },
  {
    target: '[data-view-target="progress"]',
    title: "Progreso y jardín",
    text: "Mira tus minutos de la semana, tu puntualidad y tu jardín: cada día con la rutina completa florece."
  },
  {
    target: '[data-view-target="settings"]',
    title: "Hazla tuya",
    text: "Ajusta rutinas, horario, tema, iconos, sonido y avisos. Desde aquí también puedes crear copias de seguridad."
  },
  {
    title: "Sin abrir la extensión",
    text: "" // se completa con los atajos reales
  }
];
let tourIndex = 0;
let tourDemoTimer = null;

// Año simulado para la demo del tutorial: unos 8 de cada 10 días laborables con la rutina completa.
function simulatedYear() {
  const start = Core.dateFromKey(todayKey());
  const entries = [];
  for (let offset = 0; offset <= 365; offset += 1) {
    const date = new Date(start);
    date.setDate(start.getDate() + offset);
    if (date.getDay() === 0 || date.getDay() === 6) continue;
    const chance = Math.abs((Math.sin(offset * 12.9898) * 43758.5453) % 1);
    if (chance < 0.94) entries.push({ day: Core.dateKey(date), complete: chance < 0.82 });
  }
  return { start, entries };
}

function startTourDemo() {
  if (tourDemoTimer) return;
  const seasons = { spring: "primavera", summer: "verano", autumn: "otoño", winter: "invierno" };
  const { start, entries } = simulatedYear();
  const scene = $("#tour-demo-scene");
  let offset = 0;
  let pause = 0;
  $("#tour-demo").hidden = false;
  const step = () => {
    if (pause > 0) {
      pause -= 1;
      if (pause === 0) offset = 0;
      return;
    }
    const date = new Date(start);
    date.setDate(start.getDate() + offset);
    const info = PausaGarden.render(scene, entries, Core.dateKey(date));
    const trees = info.counts.young + info.counts.tree;
    $("#tour-demo-day").textContent = `Día ${offset + 1}`;
    $("#tour-demo-info").textContent = `${seasons[info.season]} · ${plural(trees, "árbol", "árboles")}`;
    offset += 3;
    // Al terminar el año se queda un momento quieto y vuelve a empezar.
    if (offset > 365) pause = 25;
  };
  step();
  tourDemoTimer = setInterval(step, 70);
}

function stopTourDemo() {
  clearInterval(tourDemoTimer);
  tourDemoTimer = null;
  $("#tour-demo").hidden = true;
}

function startTour() {
  showView("today");
  tourIndex = 0;
  dom.tour.hidden = false;
  renderTourStep();
}

function endTour() {
  stopTourDemo();
  dom.tour.hidden = true;
  chrome.storage.local.set({ tutorialDone: true });
}

function renderTourStep() {
  const step = TOUR_STEPS[tourIndex];
  const last = tourIndex === TOUR_STEPS.length - 1;
  if (last) {
    const start = shortcuts["start-break"] || "Alt+Shift+B";
    const finish = shortcuts["finish-break"] || "Alt+Shift+V";
    step.text = `Pulsa ${start} para empezar el descanso sugerido y ${finish} cuando vuelvas. El icono de la barra muestra cuántos descansos te quedan o los minutos que faltan.`;
  }
  dom.tourStep.textContent = tourIndex === 0 ? "Tutorial" : `Paso ${tourIndex} de ${TOUR_STEPS.length - 1}`;
  dom.tourTitle.textContent = step.title;
  dom.tourText.textContent = step.text;
  dom.tourLogo.toggleAttribute("hidden", Boolean(step.target || step.demo));
  if (step.demo) startTourDemo();
  else stopTourDemo();
  dom.tourBack.hidden = tourIndex === 0;
  dom.tourSkip.hidden = last;
  dom.tourNext.textContent = tourIndex === 0 ? "Empezar" : last ? "Terminar" : "Siguiente";
  dom.tourDots.replaceChildren(...TOUR_STEPS.map((_, index) => element("i", index === tourIndex ? "is-active" : "")));

  const target = step.target ? $(step.target) : null;
  if (target && !target.hidden) {
    revealInViews(target, true);
    positionTour(target);
  } else {
    positionTour(null);
  }
  dom.tourNext.focus();
}

function positionTour(target) {
  const card = dom.tourCard;
  const viewport = { width: document.body.clientWidth, height: document.body.clientHeight };
  if (!target) {
    dom.tourSpot.classList.add("is-center");
    Object.assign(dom.tourSpot.style, { top: `${viewport.height / 2}px`, left: `${viewport.width / 2}px`, width: "0px", height: "0px" });
    card.classList.add("is-center");
    card.style.top = `${Math.max(16, (viewport.height - card.offsetHeight) / 2)}px`;
    return;
  }
  dom.tourSpot.classList.remove("is-center");
  card.classList.remove("is-center");
  const rect = target.getBoundingClientRect();
  const pad = 6;
  Object.assign(dom.tourSpot.style, {
    top: `${rect.top - pad}px`,
    left: `${rect.left - pad}px`,
    width: `${rect.width + pad * 2}px`,
    height: `${rect.height + pad * 2}px`
  });
  const below = rect.bottom + pad + 12;
  const fitsBelow = below + card.offsetHeight < viewport.height - 8;
  card.style.top = `${fitsBelow ? below : Math.max(8, rect.top - pad - 12 - card.offsetHeight)}px`;
}

// ---------- Eventos ----------

dom.segments.forEach((segment) => segment.addEventListener("click", () => {
  mode = segment.dataset.mode;
  chrome.storage.local.set({ lastMode: mode });
  renderToday();
}));
$$(".tab").forEach((tab) => tab.addEventListener("click", () => showView(tab.dataset.viewTarget)));
$("#help-button").addEventListener("click", startTour);
$("#quote-close").addEventListener("click", () => {
  state.returnQuote = null;
  chrome.storage.local.remove("returnQuote");
  renderQuote();
});
$("#finish-timer").addEventListener("click", finishTimer);
$("#cancel-timer").addEventListener("click", () => state.activeTimer && deleteRecord(state.activeTimer.recordId, "Descanso cancelado"));
$("#extend-timer").addEventListener("click", () => extendTimer(5));
$("#restart-timer").addEventListener("click", restartTimer);
$("#today-off").addEventListener("click", () => toggleDayOff(todayKey()));
$("#tip-next").addEventListener("click", () => {
  tipIndex = (tipIndex + 1) % TIPS.length;
  dom.tipText.textContent = TIPS[tipIndex];
});
dom.breathToggle.addEventListener("click", () => {
  breathing = !breathing;
  breathStart = Date.now();
  renderHero();
  renderChoices();
});

$("#previous-month").addEventListener("click", () => changeMonth(-1));
$("#next-month").addEventListener("click", () => changeMonth(1));
$("#today-button").addEventListener("click", () => {
  visibleMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  selectedDate = todayKey();
  closeRecordForm();
  render();
});
dom.addRecord.addEventListener("click", () => openRecordForm());
$("#record-cancel").addEventListener("click", closeRecordForm);
dom.recordForm.addEventListener("submit", saveRecordForm);
dom.toggleDayOff.addEventListener("click", () => toggleDayOff(selectedDate));
$$("[data-reset]").forEach((button) => button.addEventListener("click", () => handleResetClick(button)));

$$('input[name="theme"]').forEach((input) => input.addEventListener("change", () => {
  state.settings.theme = input.value;
  saveSettings("Tema aplicado");
}));
for (const [select, modeName] of [[dom.longIcon, "long"], [dom.shortIcon, "short"]]) {
  select.addEventListener("change", () => {
    state.settings.icons[modeName] = select.value;
    saveSettings("Icono guardado");
  });
}
$$("[data-hours]").forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  const hours = structuredClone(profile.hours);
  hours[input.dataset.hours][input.dataset.edge] = input.value;
  const range = hours[input.dataset.hours];
  if (!range.start || !range.end || range.start >= range.end) {
    dom.hoursError.textContent = "La hora de fin debe ser posterior a la de inicio.";
    return;
  }
  dom.hoursError.textContent = "";
  profile.hours = hours;
  saveSettings("Jornada guardada");
}));
$$(".routine-row input").forEach((input) => input.addEventListener("change", () => {
  try {
    editingProfile().routines = readRoutineInputs();
    dom.routineError.textContent = "";
    saveSettings("Rutina guardada");
  } catch (error) {
    dom.routineError.textContent = error.message;
  }
}));
$("#reset-routines").addEventListener("click", () => {
  editingProfile().routines = structuredClone(Core.DEFAULT_ROUTINES);
  fillRoutineInputs(editingProfile().routines);
  dom.routineError.textContent = "";
  saveSettings("Rutina original restaurada");
});
$("#profile-select").addEventListener("change", (event) => {
  editingProfileId = event.target.value;
  renderProfiles();
});
$("#profile-add").addEventListener("click", addProfile);
$("#profile-delete").addEventListener("click", deleteProfile);
$("#profile-name").addEventListener("change", (event) => {
  const name = event.target.value.trim();
  if (!name) {
    event.target.value = editingProfile().name;
    return;
  }
  editingProfile().name = name;
  saveSettings("Nombre guardado");
  renderProfiles();
  renderWeeks();
});
$$('input[name="plan-mode"]').forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  profile.plan.mode = input.value;
  // Al pasar a horas fijas por primera vez, se proponen a partir de la rutina actual.
  if (input.value === "fixed") {
    for (const routineMode of ["long", "short"]) {
      if (profile.plan.fixed[routineMode].length) continue;
      const plan = Core.planDay({ ...state, records: [], daysOff: [], settings: { ...state.settings, weekdayModes: Array(7).fill("none"), weekProfiles: {}, defaultProfile: profile.id, profiles: [{ ...profile, plan: { ...profile.plan, mode: "spread" } }] } }, routineMode, Core.timestampFor(todayKey(), profile.hours[routineMode].start));
      profile.plan.fixed[routineMode] = (plan.items || []).map((item) => ({ time: timeInputValue(item.time), minutes: item.minutes }));
    }
  }
  saveSettings("Forma de repartir guardada");
  renderProfiles();
}));
$("#plan-interval").addEventListener("change", (event) => {
  const value = Number(event.target.value);
  if (!Number.isInteger(value) || value < 15 || value > 240) {
    dom.routineError.textContent = "El intervalo debe ser de 15 a 240 minutos.";
    return;
  }
  dom.routineError.textContent = "";
  editingProfile().plan.interval = value;
  saveSettings("Intervalo guardado");
});
$$("[data-fixed-add]").forEach((button) => button.addEventListener("click", () => addFixedSlot(button.dataset.fixedAdd)));
$("#default-profile").addEventListener("change", (event) => {
  state.settings.defaultProfile = event.target.value;
  saveSettings("Horario por defecto guardado");
  renderWeeks();
});
$("#suggest-lead").addEventListener("change", (event) => {
  state.settings.suggestLead = Number(event.target.value);
  saveSettings("Antelación guardada");
});
$("#overtime-alert").addEventListener("change", (event) => {
  state.settings.overtimeAlert = Number(event.target.value);
  saveSettings();
});
dom.timerEnabled.addEventListener("change", () => {
  state.settings.timerEnabled = dom.timerEnabled.checked;
  saveSettings();
});
for (const [checkbox, key] of [[dom.endAlert, "endAlert"], [dom.suggestAlert, "suggestAlert"]]) {
  checkbox.addEventListener("change", async () => {
    dom.alertsError.textContent = "";
    if (!(await ensureNotificationPermission(checkbox))) return;
    state.settings[key] = checkbox.checked;
    saveSettings();
  });
}
PausaSound.OPTIONS.forEach((option) => dom.soundSelect.append(new Option(option.label, option.value)));
dom.soundSelect.addEventListener("change", () => {
  state.settings.sound = dom.soundSelect.value;
  PausaSound.play(state.settings.sound);
  saveSettings("Sonido guardado");
});
$("#sound-test").addEventListener("click", () => PausaSound.play(dom.soundSelect.value));
$("#open-shortcuts").addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));
$("#backup-export").addEventListener("click", exportBackup);
$("#backup-import").addEventListener("click", () => dom.backupFile.click());
dom.backupFile.addEventListener("change", () => {
  const [file] = dom.backupFile.files;
  if (file) importBackup(file);
  dom.backupFile.value = "";
});
$("#csv-export").addEventListener("click", exportCsv);
$("#tour-restart").addEventListener("click", startTour);

$("#open-botfather").addEventListener("click", () => chrome.tabs.create({ url: "https://t.me/BotFather" }));
$("#open-telegram-web").addEventListener("click", () => chrome.tabs.create({ url: "https://web.telegram.org/" }));
$("#telegram-save").addEventListener("click", saveTelegramToken);
$("#telegram-token").addEventListener("keydown", (event) => {
  if (event.key === "Enter") saveTelegramToken();
});
$("#telegram-open-link").addEventListener("click", () => chrome.tabs.create({ url: PausaTelegram.linkUrl(state.settings.telegram) }));
$("#telegram-reset").addEventListener("click", () => resetTelegram());
$("#telegram-unlink").addEventListener("click", () => resetTelegram("Móvil desconectado"));
$("#telegram-test").addEventListener("click", async () => {
  try {
    await PausaTelegram.send(state.settings.telegram, "✅ Prueba de Pausa Bloom: los avisos llegan a tu móvil.");
    showToast("Prueba enviada: mira tu móvil");
  } catch (error) {
    $("#phone-error").textContent = `No se pudo enviar: ${error.message}`;
  }
});
for (const [id, key] of [["#phone-end", "onEnd"], ["#phone-suggest", "onSuggest"], ["#phone-overtime", "onOvertime"]]) {
  $(id).addEventListener("change", () => {
    state.settings.telegram = { ...state.settings.telegram, [key]: $(id).checked };
    saveSettings();
  });
}

dom.tourNext.addEventListener("click", () => {
  if (tourIndex === TOUR_STEPS.length - 1) endTour();
  else {
    tourIndex += 1;
    renderTourStep();
  }
});
dom.tourBack.addEventListener("click", () => {
  tourIndex = Math.max(0, tourIndex - 1);
  renderTourStep();
});
dom.tourSkip.addEventListener("click", endTour);
document.addEventListener("keydown", (event) => {
  if (dom.tour.hidden) return;
  if (event.key === "Escape") endTour();
  else if (event.key === "ArrowRight") dom.tourNext.click();
  else if (event.key === "ArrowLeft" && !dom.tourBack.hidden) dom.tourBack.click();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  let changed = false;
  if (changes.records) { state.records = Array.isArray(changes.records.newValue) ? changes.records.newValue : []; changed = true; }
  if (changes.activeTimer) { state.activeTimer = changes.activeTimer.newValue || null; changed = true; }
  if (changes.returnQuote) { state.returnQuote = changes.returnQuote.newValue || null; changed = true; }
  if (changes.daysOff) { state.daysOff = Array.isArray(changes.daysOff.newValue) ? changes.daysOff.newValue : []; changed = true; }
  // Los cambios guardados desde esta misma ventana ya están en `state`: no se sustituye el objeto.
  if (changes.settings && JSON.stringify(changes.settings.newValue) !== JSON.stringify(state.settings)) {
    state.settings = Core.mergeSettings(changes.settings.newValue);
    changed = true;
  }
  if (changed) render();
});

(async function initialize() {
  const saved = await chrome.storage.local.get(["settings", "records", "activeTimer", "daysOff", "lastMode", "tutorialDone", "returnQuote"]);
  state.settings = Core.mergeSettings(saved.settings);
  state.records = Array.isArray(saved.records) ? saved.records : [];
  state.activeTimer = saved.activeTimer || null;
  state.daysOff = Array.isArray(saved.daysOff) ? saved.daysOff : [];
  state.returnQuote = saved.returnQuote || null;

  // Un descanso olvidado se cierra a su hora prevista.
  const timer = state.activeTimer;
  if (timer && Date.now() >= timer.endAt + Core.STALE_MINUTES * MINUTE) {
    state.records = Core.closeActive(state.records, timer, timer.endAt);
    state.activeTimer = null;
    await persist(["records", "activeTimer"]);
    await drawReturnQuote(timer.recordId);
  }

  const activeRecord = state.activeTimer && state.records.find((record) => record.id === state.activeTimer.recordId);
  mode = activeRecord ? activeRecord.mode : Core.todayMode(state.settings, saved.lastMode);

  if (chrome.commands?.getAll) {
    const commands = await chrome.commands.getAll();
    shortcuts = Object.fromEntries(commands.map((command) => [command.name, command.shortcut]));
  }

  render();
  renderSettings();
  setInterval(() => {
    tickCount += 1;
    if (state.activeTimer) renderHero();
    if (tickCount % 30 === 0) renderToday();
  }, 1000);
  if (!saved.tutorialDone) startTour();
})();
