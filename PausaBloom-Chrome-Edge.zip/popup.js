// Eventos, arranque de la ventana y ajustes finales.
// ---------- Eventos ----------

dom.segments.forEach((segment) => segment.addEventListener("click", () => {
  mode = segment.dataset.mode;
  chrome.storage.local.set({ lastMode: mode });
  scheduleUiStateSave();
  renderToday();
}));
dom.views.addEventListener("scroll", scheduleUiStateSave, { passive: true });
window.addEventListener("pagehide", () => {
  clearTimeout(uiStateTimer);
  saveUiState();
});
$$(".tab").forEach((tab) => tab.addEventListener("click", () => showView(tab.dataset.viewTarget)));
dom.openStandalone.addEventListener("click", () => {
  clearTimeout(uiStateTimer);
  (async () => {
    try {
      await saveUiState();
      await chrome.tabs.create({ url: chrome.runtime.getURL("popup.html?standalone=1") });
    } catch (error) {
      showToast(`No se pudo abrir la pestaña: ${error.message}`);
    }
  })();
});
$("#help-button").addEventListener("click", startTour);
$("#quote-close").addEventListener("click", () => {
  state.returnQuote = null;
  chrome.storage.local.remove("returnQuote");
  renderQuote();
});
$("#finish-timer").addEventListener("click", finishTimer);
$("#cancel-timer").addEventListener("click", () => state.activeTimer && deleteRecord(state.activeTimer.recordId, "Descanso cancelado"));
$("#extend-timer").addEventListener("click", () => extendTimer(5));
$("#restart-timer").addEventListener("click", restartTimer);
$("#today-off").addEventListener("click", () => toggleDayOff(todayKey()));
$("#tip-next").addEventListener("click", () => {
  tipIndex = (tipIndex + 1) % TIPS.length;
  dom.tipText.textContent = TIPS[tipIndex];
});
dom.breathToggle.addEventListener("click", () => {
  breathing = !breathing;
  breathStart = Date.now();
  renderHero();
  renderChoices();
});

$("#previous-month").addEventListener("click", () => changeMonth(-1));
$("#next-month").addEventListener("click", () => changeMonth(1));
$("#today-button").addEventListener("click", () => {
  visibleMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  selectedDate = todayKey();
  closeRecordForm();
  scheduleUiStateSave();
  render();
});
dom.addRecord.addEventListener("click", () => openRecordForm());
$("#record-cancel").addEventListener("click", closeRecordForm);
dom.recordForm.addEventListener("submit", saveRecordForm);
dom.toggleDayOff.addEventListener("click", () => toggleDayOff(selectedDate));
$$("[data-reset]").forEach((button) => button.addEventListener("click", () => handleResetClick(button)));

$$('input[name="theme"]').forEach((input) => input.addEventListener("change", () => {
  state.settings.theme = input.value;
  saveSettings("Tema aplicado");
}));
for (const [select, modeName] of [[dom.longIcon, "long"], [dom.shortIcon, "short"]]) {
  select.addEventListener("change", () => {
    state.settings.icons[modeName] = select.value;
    saveSettings("Icono guardado");
  });
}
$$("[data-routine-step]").forEach((button) => button.addEventListener("click", () => {
  const control = button.closest(".routine-count-control");
  const input = control.querySelector('input[data-field="count"]');
  const next = Number(input.value) + Number(button.dataset.routineStep);
  if (next < 0 || next > 30) return;
  input.value = String(next);
  updateRoutineCountButtons(input);
  input.dispatchEvent(new Event("change", { bubbles: true }));
}));
$$("[data-hours]").forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  const hours = structuredClone(profile.hours);
  const routineMode = input.dataset.hours;
  const followsShiftEnd = input.dataset.edge === "end" && profile.breakUntil[routineMode] === profile.hours[routineMode].end;
  hours[routineMode][input.dataset.edge] = input.value;
  const range = hours[routineMode];
  if (!range.start || !range.end || range.start === range.end) {
    dom.hoursError.textContent = "El inicio y el fin de la jornada no pueden ser iguales (si el fin es anterior, el turno cruza la medianoche).";
    input.value = profile.hours[input.dataset.hours][input.dataset.edge];
    return;
  }
  if (range.end > range.start && range.start >= profile.breakUntil[input.dataset.hours]) {
    dom.hoursError.textContent = "La hora límite debe ser posterior al inicio de la jornada.";
    input.value = profile.hours[input.dataset.hours][input.dataset.edge];
    return;
  }
  dom.hoursError.textContent = "";
  profile.hours = hours;
  if (followsShiftEnd) {
    profile.breakUntil[routineMode] = range.end;
    $(`[data-break-until="${routineMode}"]`).value = range.end;
  }
  saveSettings("Jornada guardada");
}));
$$("[data-break-until]").forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  const routineMode = input.dataset.breakUntil;
  const shift = profile.hours[routineMode];
  if (!input.value || (shift.end > shift.start && input.value <= shift.start)) {
    dom.hoursError.textContent = "La hora límite debe ser posterior al inicio de la jornada.";
    input.value = profile.breakUntil[routineMode];
    return;
  }
  dom.hoursError.textContent = "";
  profile.breakUntil[routineMode] = input.value;
  saveSettings("Hora límite guardada");
}));
$$(".routine-row input").forEach((input) => input.addEventListener("change", () => {
  try {
    editingProfile().routines = readRoutineInputs();
    dom.routineError.textContent = "";
    $$('.routine-row input[data-field="count"]').forEach(updateRoutineCountButtons);
    saveSettings("Rutina guardada");
  } catch (error) {
    dom.routineError.textContent = error.message;
    fillRoutineInputs(editingProfile().routines);
  }
}));
$("#reset-routines").addEventListener("click", () => {
  editingProfile().routines = structuredClone(Core.DEFAULT_ROUTINES);
  fillRoutineInputs(editingProfile().routines);
  dom.routineError.textContent = "";
  saveSettings("Rutina original restaurada");
});
$("#profile-select").addEventListener("change", (event) => {
  editingProfileId = event.target.value;
  renderProfiles();
  scheduleUiStateSave();
});
$("#profile-add").addEventListener("click", addProfile);
$("#profile-delete").addEventListener("click", deleteProfile);
$("#profile-name").addEventListener("change", (event) => {
  const name = event.target.value.trim();
  if (!name) {
    event.target.value = editingProfile().name;
    return;
  }
  editingProfile().name = name;
  saveSettings("Nombre guardado");
  renderProfiles();
  renderWeeks();
});
$$('input[name="plan-mode"]').forEach((input) => input.addEventListener("change", () => {
  const profile = editingProfile();
  profile.plan.mode = input.value;
  // Al pasar a horas fijas por primera vez, se proponen a partir de la rutina actual.
  if (input.value === "fixed") {
    for (const routineMode of ["long", "short"]) {
      if (profile.plan.fixed[routineMode].length) continue;
      const plan = Core.planDay({ ...state, records: [], daysOff: [], settings: { ...state.settings, weekdayModes: Array(7).fill("none"), weekProfiles: {}, defaultProfile: profile.id, profiles: [{ ...profile, weekdayModes: Array(7).fill("none"), plan: { ...profile.plan, mode: "spread" } }] } }, routineMode, Core.timestampFor(todayKey(), profile.hours[routineMode].start));
      profile.plan.fixed[routineMode] = (plan.items || []).map((item) => ({ time: timeInputValue(item.time), minutes: item.minutes }));
    }
  }
  saveSettings("Forma de repartir guardada");
  renderProfiles();
}));
$("#plan-interval").addEventListener("change", (event) => {
  const value = Number(event.target.value);
  if (!Number.isInteger(value) || value < 15 || value > 240) {
    dom.routineError.textContent = "El intervalo debe ser de 15 a 240 minutos.";
    return;
  }
  dom.routineError.textContent = "";
  editingProfile().plan.interval = value;
  saveSettings("Intervalo guardado");
});
$$("[data-fixed-add]").forEach((button) => button.addEventListener("click", () => addFixedSlot(button.dataset.fixedAdd)));
$("#default-profile").addEventListener("change", (event) => {
  state.settings.defaultProfile = event.target.value;
  saveSettings("Horario por defecto guardado");
  renderWeeks();
});
dom.previousWeeks.addEventListener("click", () => {
  weekOffset = Math.max(0, weekOffset - 8);
  renderWeeks();
  scheduleUiStateSave();
});
dom.nextWeeks.addEventListener("click", () => {
  weekOffset += 8;
  renderWeeks();
  scheduleUiStateSave();
});
$("#suggest-lead").addEventListener("change", (event) => {
  state.settings.suggestLead = Number(event.target.value);
  saveSettings("Antelación guardada");
});
$("#overtime-alert").addEventListener("change", (event) => {
  state.settings.overtimeAlert = Number(event.target.value);
  saveSettings();
});
dom.timerEnabled.addEventListener("change", () => {
  state.settings.timerEnabled = dom.timerEnabled.checked;
  saveSettings();
});
for (const [checkbox, key] of [[dom.endAlert, "endAlert"], [dom.suggestAlert, "suggestAlert"]]) {
  checkbox.addEventListener("change", async () => {
    dom.alertsError.textContent = "";
    // El permiso se pide a la vez que se guarda: si el aviso del navegador cierra la ventana, el ajuste ya queda guardado.
    const asking = checkbox.checked ? chrome.permissions.request({ permissions: ["notifications"] }) : null;
    state.settings[key] = checkbox.checked;
    await saveSettings();
    if (asking && !(await asking)) {
      checkbox.checked = false;
      state.settings[key] = false;
      dom.alertsError.textContent = "Para avisarte hace falta el permiso de notificaciones del navegador.";
      await saveSettings();
    }
  });
}
PausaSound.OPTIONS.forEach((option) => dom.soundSelect.append(new Option(option.label, option.value)));
dom.soundSelect.addEventListener("change", () => {
  state.settings.sound = dom.soundSelect.value;
  PausaSound.play(state.settings.sound);
  saveSettings("Sonido guardado");
});
$("#sound-test").addEventListener("click", () => PausaSound.play(dom.soundSelect.value));
$("#open-shortcuts").addEventListener("click", () => chrome.tabs.create({ url: "chrome://extensions/shortcuts" }));
$("#backup-export").addEventListener("click", exportBackup);
$("#backup-import").addEventListener("click", () => dom.backupFile.click());
dom.backupFile.addEventListener("change", () => {
  const [file] = dom.backupFile.files;
  if (file) importBackup(file);
  dom.backupFile.value = "";
});
$("#csv-export").addEventListener("click", exportCsv);
$("#tour-restart").addEventListener("click", startTour);

$("#open-botfather").addEventListener("click", () => chrome.tabs.create({ url: "https://t.me/BotFather" }));
$("#open-telegram-web").addEventListener("click", () => chrome.tabs.create({ url: "https://web.telegram.org/" }));
$("#telegram-save").addEventListener("click", saveTelegramToken);
$("#telegram-token").addEventListener("keydown", (event) => {
  if (event.key === "Enter") saveTelegramToken();
});
$("#telegram-open-link").addEventListener("click", () => chrome.tabs.create({ url: PausaTelegram.linkUrl(state.settings.telegram) }));
$("#telegram-reset").addEventListener("click", () => resetTelegram());
$("#telegram-unlink").addEventListener("click", () => resetTelegram("Móvil desconectado"));
$("#telegram-test").addEventListener("click", async () => {
  try {
    await PausaTelegram.send(state.settings.telegram, "✅ Prueba de Pausa Bloom: los avisos llegan a tu móvil.");
    showToast("Prueba enviada: mira tu móvil");
  } catch (error) {
    $("#phone-error").textContent = `No se pudo enviar: ${error.message}`;
  }
});
for (const [id, key] of [["#phone-end", "onEnd"], ["#phone-suggest", "onSuggest"], ["#phone-overtime", "onOvertime"]]) {
  $(id).addEventListener("change", () => {
    state.settings.telegram = { ...state.settings.telegram, [key]: $(id).checked };
    saveSettings();
  });
}

dom.tourNext.addEventListener("click", () => {
  if (tourIndex === TOUR_STEPS.length - 1) endTour();
  else {
    tourIndex += 1;
    renderTourStep();
  }
});
dom.tourBack.addEventListener("click", () => {
  tourIndex = Math.max(0, tourIndex - 1);
  renderTourStep();
});
dom.tourSkip.addEventListener("click", endTour);
document.addEventListener("keydown", (event) => {
  if (dom.tour.hidden) return;
  if (event.key === "Escape") endTour();
  else if (event.key === "ArrowRight") dom.tourNext.click();
  else if (event.key === "ArrowLeft" && !dom.tourBack.hidden) dom.tourBack.click();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  let changed = false;
  if (changes.records) { state.records = Array.isArray(changes.records.newValue) ? changes.records.newValue.filter(isValidRecord) : []; changed = true; }
  if (changes.activeTimer) { state.activeTimer = changes.activeTimer.newValue || null; changed = true; }
  if (changes.returnQuote) { state.returnQuote = changes.returnQuote.newValue || null; changed = true; }
  if (changes.daysOff) { state.daysOff = Array.isArray(changes.daysOff.newValue) ? changes.daysOff.newValue : []; changed = true; }
  // Los cambios guardados desde esta misma ventana ya están en `state`: no se sustituye el objeto.
  if (changes.settings && JSON.stringify(changes.settings.newValue) !== JSON.stringify(state.settings)) {
    state.settings = Core.mergeSettings(changes.settings.newValue);
    changed = true;
  }
  if (changed) render();
});

(async function initialize() {
  const saved = await chrome.storage.local.get(["settings", "records", "activeTimer", "daysOff", "lastMode", "tutorialDone", "returnQuote", "uiState", "telegramDraft", "wizardDone"]);
  state.settings = Core.mergeSettings(saved.settings);
  state.records = Array.isArray(saved.records) ? saved.records.filter(isValidRecord) : [];
  state.activeTimer = saved.activeTimer || null;
  state.daysOff = Array.isArray(saved.daysOff) ? saved.daysOff : [];
  state.returnQuote = saved.returnQuote || null;
  $("#telegram-token").value = saved.telegramDraft || "";
  const savedUi = saved.uiState || {};
  const validViews = ["today", "calendar", "progress", "settings"];
  if (/^\d{4}-\d{2}-\d{2}$/.test(savedUi.selectedDate || "")) selectedDate = savedUi.selectedDate;
  if (/^\d{4}-\d{2}-\d{2}$/.test(savedUi.visibleMonth || "")) {
    const savedMonth = Core.dateFromKey(savedUi.visibleMonth);
    visibleMonth = new Date(savedMonth.getFullYear(), savedMonth.getMonth(), 1);
  }
  if (Number.isInteger(savedUi.weekOffset) && savedUi.weekOffset >= 0) weekOffset = Math.floor(savedUi.weekOffset / 8) * 8;
  if (typeof savedUi.editingProfileId === "string" && state.settings.profiles.some((profile) => profile.id === savedUi.editingProfileId)) {
    editingProfileId = savedUi.editingProfileId;
  }

  // Un descanso olvidado se cierra a su hora prevista.
  const timer = state.activeTimer;
  if (timer && Date.now() >= timer.endAt + Core.STALE_MINUTES * MINUTE) {
    state.records = Core.closeActive(state.records, timer, timer.endAt);
    state.activeTimer = null;
    await persist(["records", "activeTimer"]);
    await drawReturnQuote(timer.recordId);
  }

  const activeRecord = state.activeTimer && state.records.find((record) => record.id === state.activeTimer.recordId);
  mode = activeRecord ? activeRecord.mode : ["long", "short"].includes(savedUi.mode) ? savedUi.mode : Core.todayMode(state.settings, saved.lastMode);

  if (chrome.commands?.getAll) {
    const commands = await chrome.commands.getAll();
    shortcuts = Object.fromEntries(commands.map((command) => [command.name, command.shortcut]));
  }

  render();
  renderSettings();
  showView(validViews.includes(savedUi.view) ? savedUi.view : "today", { save: false });
  dom.views.scrollTop = Number.isFinite(savedUi.scrollTop) ? Math.max(0, savedUi.scrollTop) : 0;
  clearTimeout(uiStateTimer);
  setInterval(() => {
    tickCount += 1;
    if (state.activeTimer) renderHero();
    const planStatus = state.activeTimer ? lastPlanStatus : Core.planDay(state, mode).status;
    if (tickCount % 30 === 0 || planStatus !== lastPlanStatus) renderToday();
  }, 1000);
  // Instalación nueva: primero el asistente de configuración y después el tutorial.
  if (!saved.wizardDone && !saved.tutorialDone) startWizard();
  else if (!saved.tutorialDone) startTour();
})();

// El código del bot se guarda mientras lo escribes: si Chrome cierra la ventana al pedir el permiso, no se pierde.
$("#telegram-token").addEventListener("input", (event) => chrome.storage.local.set({ telegramDraft: event.target.value.trim() }));

// Ventana propia: no se cierra al hacer clic fuera ni cuando sale un aviso del navegador.
if (new URLSearchParams(location.search).has("window")) {
  document.documentElement.classList.add("is-window");
  $("#pop-out").hidden = true;
} else {
  $("#pop-out").addEventListener("click", async () => {
    await chrome.windows.create({ url: chrome.runtime.getURL("popup.html?window=1"), type: "popup", width: 400, height: 680 });
    window.close();
  });
}

addEventListener("unhandledrejection", (event) => {
  console.warn(event.reason);
  showToast("Algo no salió bien. Inténtalo de nuevo.");
});