// Traducción de la interfaz al inglés. Los textos del programa están en español; este módulo
// los traduce con un diccionario y unas reglas para los textos con números, sin tocar el resto del código.
(function (global) {
  const DICT = {
    // --- Cabecera, pestañas, Hoy ---
    "Apariencia": "Appearance", "Horarios y semanas": "Schedules and weeks", "Avisos": "Alerts", "Atajos y datos": "Shortcuts and data", "Móvil sin conectar": "Phone not connected",
    "Copia automática activada": "Automatic backup on", "Copia automática desactivada": "Automatic backup off", "Pausa de comida (opcional)": "Lunch break (optional)", "Jornada partida: en esa franja no se sugieren descansos. Deja las dos horas vacías si no tienes pausa.": "Split shift: no breaks are suggested in that slot. Leave both times empty if you have no lunch break.",
    "Alternar dos horarios cada semana": "Alternate two schedules every week", "Semana A": "Week A", "Semana B": "Week B", "Esta semana es la": "This week is",
    "Las semanas que elijas a mano en la lista de abajo ganan a la rotación.": "Weeks you pick by hand in the list below override the rotation.",
    "Cambiar las horas de este día": "Change this day's hours", "Horas de este día": "This day's hours", "Inicio": "Start", "Fin": "End", "Quitar el cambio": "Remove the change",
    "Automático": "Automatic", "Semana libre": "Week off", "libre": "off", "Pausa guardada": "Break saved", "Rotación activada": "Rotation on", "Rotación desactivada": "Rotation off", "Rotación guardada": "Rotation saved",
    "Horas de este día guardadas": "This day's hours saved", "El día vuelve a su horario normal": "The day is back to its normal schedule", "Crea otro horario para poder alternar semanas": "Create another schedule to alternate weeks",
    "Escribe el inicio y el fin de la pausa (el fin, después del inicio) o deja las dos horas vacías.": "Enter the start and end of the break (end after start) or leave both empty.", "La pausa tiene que quedar dentro de la jornada.": "The break must fall inside the workday.",
    "Indica el inicio y el fin (distintos). Si el fin es anterior, el turno cruza la medianoche.": "Enter a start and end (different). If the end is earlier, the shift crosses midnight.",
    "El inicio y el fin de la jornada no pueden ser iguales (si el fin es anterior, el turno cruza la medianoche).": "Start and end of the workday can't be the same (if the end is earlier, the shift crosses midnight).",
    "Ahora": "Now", "Hoy": "Today", "Calendario": "Calendar", "Progreso": "Progress", "Ajustes": "Settings",
    "Día largo": "Long day", "Día corto": "Short day", "Dia largo": "Long day", "Dia corto": "Short day",
    "día largo": "long day", "día corto": "short day", "Largo": "Long", "Corto": "Short", "largo": "long", "corto": "short",
    "Libre": "Off", "Completo": "Complete", "Pausa Bloom": "Pausa Bloom",
    "Listo para empezar": "Ready to start", "Buen ritmo": "Good pace", "Rutina completa": "Routine complete",
    "Has cuidado tus descansos hoy.": "You took care of your breaks today.", "Desconecta un momento": "Disconnect for a moment",
    "Es hora de volver": "Time to get back", "tiempo extra": "overtime", "Tiempo extra": "Overtime", "Tiempo extra (min)": "Overtime (min)",
    "descansos": "breaks", "Siguiente descanso": "Next break", "Buen momento para descansar": "Good time for a break",
    "Empezar": "Start", "Quitar": "Remove", "Empezar ahora": "Start now", "Ya volví": "I'm back", "Respirar": "Breathe", "Parar": "Stop",
    "Inhala": "Inhale", "Exhala": "Exhale", "Cancelar": "Cancel", "Reiniciar": "Restart", "+5 min": "+5 min", "Hoy no trabajo": "Not working today",
    "Día libre": "Day off", "Día libre.": "Day off.", "Sin sugerencias ni avisos hoy. ¡Disfruta!": "No suggestions or alerts today. Enjoy!",
    "Jornada terminada": "Workday over", "Ya no quedan horas de trabajo hoy.": "No work hours left today.",
    "Ya tomaste todos tus descansos.": "You took all your breaks.", "Sin configurar": "Not set up", "Sin descansos programados": "No breaks scheduled",
    "Revisa tu horario y tus rutinas en Ajustes.": "Check your schedule and routines in Settings.", "Revisa el plan": "Review the plan",
    "Hora límite alcanzada": "Time limit reached", "No se iniciarán más descansos hoy.": "No more breaks will start today.",
    "Plan de hoy": "Today's plan", "Tu plan del día": "Your plan for the day", "En curso": "In progress", "Hecho": "Done", "Sugerido": "Suggested", "Siguiente": "Next",
    "Otra idea": "Another idea", "En camino": "On its way", "Racha de 5+": "5+ streak", "Tu jardín": "Your garden",
    "Completa una rutina para plantar tu primera flor.": "Complete a routine to plant your first flower.",
    "brote, rutina en camino": "sprout, routine on its way", "flor, rutina completa": "flower, routine complete", "flor especial por racha": "special flower for a streak", "sin descansos": "no breaks",
    "Cerrar": "Close", "Cerrar frase": "Close quote", "Ver tutorial": "View tutorial", "Secciones": "Sections", "Tipo de jornada": "Type of day",
    "Abrir en ventana (no se cierra sola)": "Open in a window (stays open)", "Abrir en una pestaña": "Open in a tab", "Abrir Pausa Bloom": "Open Pausa Bloom", "Abrir Pausa Bloom en una pestaña": "Open Pausa Bloom in a tab",
    // --- Consejos durante el descanso ---
    "Levántate y estira los brazos por encima de la cabeza durante 20 segundos.": "Stand up and stretch your arms above your head for 20 seconds.",
    "Mira algo que esté a más de 6 metros durante 20 segundos para descansar la vista.": "Look at something more than 6 meters away for 20 seconds to rest your eyes.",
    "Bebe un vaso de agua: la hidratación también es descanso.": "Drink a glass of water: hydration is rest too.",
    "Gira los hombros hacia atrás diez veces, despacio.": "Roll your shoulders back ten times, slowly.",
    "Inclina la cabeza hacia cada lado y mantén la postura 15 segundos.": "Tilt your head to each side and hold for 15 seconds.",
    "Da un pequeño paseo, aunque sea hasta la ventana.": "Take a short walk, even if it's just to the window.",
    "Abre y cierra las manos y estira los dedos uno a uno.": "Open and close your hands and stretch your fingers one by one.",
    "Prueba la respiración guiada: inhala 4 segundos y exhala 6.": "Try guided breathing: inhale for 4 seconds and exhale for 6.",
    "Aléjate de la pantalla: este rato es solo para ti.": "Step away from the screen: this time is just for you.",
    // --- Calendario y registros ---
    "Añadir": "Add", "Añadir descanso": "Add break", "Editar descanso": "Edit break", "Tipo de día": "Type of day", "Duración (min)": "Duration (min)", "Duracion (min)": "Duration (min)",
    "Hora de inicio": "Start time", "Hora de vuelta": "Return time", "Vuelta": "Return", "(opcional)": "(optional)", "Guardar": "Save",
    "Marcar como día libre": "Mark as day off", "Quitar día libre": "Remove day off", "Sin descansos registrados.": "No breaks logged.", "Todavía no ha llegado.": "It hasn't arrived yet.",
    "Mes anterior": "Previous month", "Mes siguiente": "Next month", "Calendario mensual": "Monthly calendar", "El día": "The day",
    "Indica la hora de inicio.": "Enter the start time.", "La duración debe ser de 1 a 120 minutos.": "Duration must be 1 to 120 minutes.",
    "La hora de inicio no puede estar en el futuro.": "The start time can't be in the future.", "La hora de vuelta no puede estar en el futuro.": "The return time can't be in the future.",
    "La vuelta debe ser posterior al inicio.": "The return must be after the start.",
    "L": "M", "M": "T", "X": "W", "J": "T", "V": "F", "S": "S", "D": "S",
    // --- Progreso ---
    "Últimos 7 días": "Last 7 days", "Minutos de descanso por día": "Minutes of rest per day", "de descanso": "of rest", "días con descansos": "days with breaks", "día con descansos": "day with breaks",
    "rutinas completas": "routines completed", "rutina completa": "routine completed", "vuelves a tiempo": "on time", "hora media": "average time", "de tiempo extra": "of overtime",
    "Retos": "Challenges", "Tres días seguidos": "Three days in a row", "Una semana entera": "A whole week", "Dos semanas": "Two weeks", "Siempre puntual": "Always on time",
    "100 descansos": "100 breaks", "30 días completos": "30 complete days",
    "Completa la rutina 3 días seguidos": "Complete the routine 3 days in a row", "Completa la rutina 7 días seguidos": "Complete the routine 7 days in a row",
    "Completa la rutina 14 días seguidos": "Complete the routine 14 days in a row", "5 días seguidos sin pasarte del tiempo": "5 days in a row without going over time",
    "Registra 100 descansos": "Log 100 breaks", "Completa la rutina 30 días": "Complete the routine 30 days",
    "Cada reto superado planta una flor dorada en tu jardín.": "Each challenge you complete plants a golden flower in your garden.",
    // --- Ajustes: general ---
    "Los cambios se guardan solos": "Changes are saved automatically", "Tema": "Theme", "Idioma": "Language",
    "Peonía": "Peony", "Rosa claro": "Light pink", "Porcelana": "Porcelain", "Clásico": "Classic", "Medianoche": "Midnight", "Oscuro lavanda": "Dark lavender", "Rosa Noir": "Rosa Noir", "Oscuro rosa": "Dark pink",
    "Icono del botón de descanso": "Break button icon", "Puedes usar un icono distinto para cada jornada.": "You can use a different icon for each day type.",
    "🌸 Flor": "🌸 Flower", "💣 Bomba": "💣 Bomb", "💖 Corazón": "💖 Heart", "⏰ Reloj": "⏰ Clock", "☕ Café": "☕ Coffee", "🪴 Planta": "🪴 Plant", "🦋 Mariposa": "🦋 Butterfly", "✨ Brillo": "✨ Sparkle", "🍓 Fresa": "🍓 Strawberry", "🐱 Gato": "🐱 Cat",
    "Horarios": "Schedules", "Guarda varios horarios (por ejemplo, uno normal y otro para semanas de 6 h) y elige en «Semanas» cuál usar cada semana.": "Save several schedules (for example, a normal one and one for 6-hour weeks) and choose in «Weeks» which to use each week.",
    "Nuevo": "New", "Nombre": "Name", "Borrar este horario": "Delete this schedule", "Horario que estás editando": "Schedule you are editing",
    "Jornada": "Workday", "Cuándo descansar": "When to rest", "Repartir": "Spread out", "Cada X min": "Every X min", "Horas fijas": "Fixed times", "Cómo repartir los descansos": "How to spread the breaks",
    "Repartimos los descansos de forma equilibrada hasta el final de la jornada; los más largos, hacia la mitad.": "We spread your breaks evenly until the end of the day, with the longest ones around the middle.",
    "Te toca un descanso cada cierto tiempo de trabajo, contando desde el último descanso (o desde el inicio de la jornada).": "You get a break after a set amount of work, counted from your last break (or the start of the day).",
    "Escribe tú a qué hora va cada descanso y cuánto dura. La rutina del día será esta lista.": "Write what time each break is and how long it lasts. This list becomes the day's routine.",
    "Un descanso cada": "A break every", "min de trabajo": "min of work", "Minutos entre descansos": "Minutes between breaks",
    "＋ Añadir hora": "＋ Add time", "Sin horas todavía": "No times yet", "Última hora para iniciar descansos": "Last time to start breaks",
    "Después de esta hora ya no se sugerirán ni se podrán iniciar descansos.": "After this time, breaks are no longer suggested or allowed to start.",
    "Ajustar a mis hábitos": "Adjust to my habits", "Acerca las horas sugeridas a las horas en las que sueles descansar.": "Moves suggested times closer to the times you usually rest.",
    "Rutinas": "Routines", "Usa +/− o escribe la cantidad. Pon 0 para omitir un grupo.": "Use +/− or type the amount. Enter 0 to skip a group.", "Restaurar rutina original": "Restore original routine",
    "Semanas": "Weeks", "Horario por defecto": "Default schedule", "Por defecto": "Default", "Esta semana": "This week", "La próxima": "Next week",
    "Asigna un perfil a cada semana. El perfil incluye horarios, rutinas y días laborables.": "Assign a schedule to each week. A schedule includes hours, routines and working days.",
    "Jornada de cada día para este horario": "Day type for each weekday in this schedule",
    "Este patrón se aplica a las semanas que asignes a este perfil. Pulsa un día para alternar entre largo, corto y libre.": "This pattern applies to the weeks you assign to this schedule. Tap a day to switch between long, short and off.",
    "Semanas anteriores": "Previous weeks", "Semanas siguientes": "Next weeks", "Ver ocho semanas anteriores": "See eight previous weeks", "Ver ocho semanas siguientes": "See eight next weeks",
    "Horario creado: cámbiale el nombre y ajústalo": "Schedule created: rename it and adjust it", "Horario de la semana guardado": "Week schedule saved", "La semana usa el horario por defecto": "The week uses the default schedule",
    "Horario por defecto guardado": "Default schedule saved", "Jornada guardada": "Workday saved", "Hora límite guardada": "Time limit saved", "Rutina guardada": "Routine saved", "Rutina original restaurada": "Original routine restored",
    "Forma de repartir guardada": "Spread mode saved", "Intervalo guardado": "Interval saved", "Horas fijas guardadas": "Fixed times saved", "Hora fija añadida": "Fixed time added", "Hora fija quitada": "Fixed time removed",
    "Nombre guardado": "Name saved", "Icono guardado": "Icon saved", "Tema aplicado": "Theme applied", "Antelación guardada": "Lead time saved", "Sonido guardado": "Sound saved", "Cambios guardados": "Changes saved",
    "Usa cantidades de 0 a 30 y duraciones de 1 a 120 minutos.": "Use amounts from 0 to 30 and durations from 1 to 120 minutes.", "El intervalo debe ser de 15 a 240 minutos.": "The interval must be 15 to 240 minutes.",
    "Cada hora fija necesita una hora y una duración de 1 a 120 minutos.": "Each fixed time needs a time and a duration of 1 to 120 minutes.", "La hora de fin debe ser posterior a la de inicio.": "The end time must be after the start time.",
    "La hora límite debe ser posterior al inicio de la jornada.": "The time limit must be after the start of the day.",
    "Temporizador y avisos": "Timer and alerts", "Cuenta atrás al empezar un descanso": "Countdown when starting a break", "Notificar cuando termine el descanso": "Notify when the break ends", "Notificar a la hora sugerida": "Notify at the suggested time",
    "Avisos de la hora sugerida (ordenador y móvil)": "Suggested-time alerts (computer and phone)", "A la hora justa": "Right on time", "1 min antes": "1 min before", "2 min antes": "2 min before", "5 min antes": "5 min before", "10 min antes": "10 min before",
    "Resumen semanal (domingo por la noche)": "Weekly summary (Sunday night)", "Recordatorio para la vista (20-20-20)": "Eye rest reminder (20-20-20)", "Sonido al terminar": "Sound when finished", "Probar": "Test",
    "Campana": "Bell", "Acorde suave": "Soft chord", "Gota": "Drop", "Sin sonido": "No sound",
    "Para avisarte hace falta el permiso de notificaciones del navegador.": "Alerts need the browser's notification permission.",
    // --- Móvil ---
    "Avisos en el móvil": "Phone alerts", "Recibe los avisos en tu iPhone o Android a través de Telegram. Solo hay que hacerlo una vez.": "Get alerts on your iPhone or Android through Telegram. You only need to do this once.",
    "Escanea con el móvil para abrir": "Scan with your phone to open", ", o": ", or", "ábrelo aquí": "open it here", "Escríbele": "Send it", "y elige un nombre para tu bot (por ejemplo, «Mis descansos»).": "and choose a name for your bot (for example, «My breaks»).",
    "Te responderá con un código largo. Si lo creaste en el móvil, abre": "It will reply with a long code. If you created it on your phone, open", "Telegram Web": "Telegram Web", "en el ordenador para copiarlo.": "on your computer to copy it.",
    "Pega ese código aquí:": "Paste that code here:", "Continuar": "Continue", "Código del bot": "Bot code", "Código QR para abrir @BotFather en Telegram": "QR code to open @BotFather in Telegram",
    "Escanea con la cámara del móvil": "Scan with your phone's camera", "Se abrirá Telegram: pulsa": "Telegram will open: tap", "Iniciar": "Start", "y tu móvil quedará conectado.": "and your phone will be connected.",
    "Esperando a tu móvil…": "Waiting for your phone…", "Abrir en este ordenador": "Open on this computer", "Usar otro bot": "Use another bot",
    "Cuando termine el descanso": "When the break ends", "A la hora sugerida": "At the suggested time", "Si me paso del tiempo": "If I go over time", "Avisar cuando lleve de más": "Alert me when I'm over by",
    "Enviar prueba": "Send test", "Desconectar": "Disconnect", "Móvil conectado": "Phone connected", "Móvil desconectado": "Phone disconnected", "Prueba enviada: mira tu móvil": "Test sent: check your phone",
    "Hace falta permitir la conexión con Telegram para enviarte avisos.": "Telegram access is needed to send you alerts.", "Ese código no parece válido. Cópialo entero desde el mensaje de @BotFather.": "That code doesn't look valid. Copy it whole from @BotFather's message.",
    "Telegram no reconoce ese código. Revisa que lo hayas copiado entero.": "Telegram doesn't recognize that code. Check you copied it whole.",
    // --- Atajos, datos, restablecer ---
    "Atajos de teclado": "Keyboard shortcuts", "Empezar el descanso sugerido": "Start the suggested break", "Cambiar atajos": "Change shortcuts", "Sin asignar": "Unassigned",
    "Tus datos": "Your data", "Tu historial vive en este navegador. La copia incluye todo, también tu cuenta de Telegram: no la compartas.": "Your history lives in this browser. The backup includes everything, including your Telegram account: don't share it.",
    "Crear copia": "Create backup", "Restaurar copia": "Restore backup", "Exportar CSV": "Export CSV", "Copia automática diaria en Descargas": "Daily automatic backup in Downloads",
    "Copia completa creada (incluye tu cuenta de Telegram)": "Full backup created (includes your Telegram account)", "Ese archivo no es una copia válida de Pausa Bloom": "That file is not a valid Pausa Bloom backup",
    "Historial exportado en CSV": "History exported as CSV", "Restablecer": "Reset", "Después de cada acción tienes unos segundos para deshacerla.": "After each action you have a few seconds to undo it.",
    "Descansos de hoy": "Today's breaks", "Empieza el día de nuevo.": "Start the day over.", "Horarios y rutinas": "Schedules and routines",
    "Un único horario «Normal» (9:00–19:00 y 9:00–15:00, 6×5 + 2×10 y 5×5 + 1×15) y sin horarios por semana.": "A single «Normal» schedule (9:00–19:00 and 9:00–15:00, 6×5 + 2×10 and 5×5 + 1×15) with no weekly schedules.",
    "Todos los ajustes": "All settings", "Tema, horario, rutinas, sonido y avisos. Conserva tu historial y tu móvil.": "Theme, schedule, routines, sound and alerts. Keeps your history and your phone.",
    "Historial": "History", "Borra todos los descansos y días libres.": "Deletes all breaks and days off.", "Borrar": "Delete", "Todo": "Everything", "Deja la extensión como recién instalada.": "Leaves the extension as if just installed.", "Borrar todo": "Delete everything",
    "¿Seguro?": "Sure?", "¿Borrar?": "Delete?", "Hecho: se ha deshecho": "Done: undone", "Deshacer": "Undo", "Ayuda": "Help", "Ver el tutorial otra vez": "See the tutorial again",
    "Descanso borrado": "Break deleted", "Descanso cancelado": "Break cancelled", "Descanso actualizado": "Break updated", "Descanso añadido": "Break added", "Descansos de hoy reiniciados": "Today's breaks restarted",
    "Horarios y rutinas restablecidos": "Schedules and routines reset", "Ajustes restablecidos": "Settings reset", "Historial borrado": "History deleted", "Todo borrado: la extensión está como nueva": "Everything deleted: the extension is like new",
    "De vuelta a tiempo": "Back on time", "Algo no salió bien. Inténtalo de nuevo.": "Something went wrong. Please try again.", "No se pudo guardar:": "Could not save:",
    // --- Tutorial ---
    "Tutorial": "Tutorial", "Saltar": "Skip", "Atrás": "Back", "Te damos la bienvenida a Pausa Bloom": "Welcome to Pausa Bloom",
    "Te ayuda a tomar tus descansos a la mejor hora y a llevar un registro sin esfuerzo. Te enseñamos lo básico en menos de un minuto.": "It helps you take your breaks at the best time and keep a record effortlessly. We'll show you the basics in under a minute.",
    "Elige tu jornada": "Choose your day type", "Cambia entre día largo (6 de 5 min y 2 de 10 min) y día corto (5 de 5 min y 1 de 15 min). En Ajustes puedes hacer que se elija sola según el día de la semana.": "Switch between a long day (6 × 5 min and 2 × 10 min) and a short day (5 × 5 min and 1 × 15 min). In Settings you can have it chosen automatically by weekday.",
    "Tu progreso de un vistazo": "Your progress at a glance", "Con cada descanso la planta del centro crece hasta florecer al completar la rutina. Durante un descanso, el anillo se convierte en una cuenta atrás.": "With each break the plant in the center grows until it blooms when you complete the routine. During a break, the ring becomes a countdown.",
    "Tu jardín se convierte en bosque": "Your garden becomes a forest", "Cada día con la rutina completa planta una flor de una especie distinta. Con las semanas se convierte en arbusto y después en árbol, y el paisaje cambia con las estaciones. Así se vería en un año:": "Each day with the full routine plants a flower of a different species. Over the weeks it becomes a bush and then a tree, and the scenery changes with the seasons. Here's how it would look in a year:",
    "La mejor hora para descansar": "The best time to rest", "Según tu horario, repartimos los descansos a lo largo de la jornada y te decimos cuándo tomar el siguiente. Los más largos quedan hacia la mitad del día.": "Based on your schedule, we spread your breaks across the day and tell you when to take the next one. The longest ones land around the middle of the day.",
    "Un clic y listo": "One click and done", "Pulsa la duración del descanso que vas a tomar: se guarda la hora y empieza la cuenta atrás. Al volver, pulsa «Ya volví» y te espera una frase para seguir con energía.": "Tap the length of the break you're taking: the time is saved and the countdown starts. When you're back, tap «I'm back» and a quote awaits to keep you going.",
    "Aquí ves los descansos que ya tomaste y los que te sugerimos, en orden. El plan se recalcula cada vez que descansas.": "Here you see the breaks you've taken and the ones we suggest, in order. The plan is recalculated every time you rest.",
    "Revisa cualquier día del mes, añade descansos olvidados, corrige horas o marca días libres para no romper tu racha.": "Review any day of the month, add forgotten breaks, fix times or mark days off so you don't break your streak.",
    "Progreso y jardín": "Progress and garden", "Mira tus minutos de la semana, tu puntualidad y tu jardín: cada día con la rutina completa florece.": "See your minutes this week, your punctuality and your garden: every day with the full routine blooms.",
    "Hazla tuya": "Make it yours", "Ajusta rutinas, horario, tema, iconos, sonido y avisos. Desde aquí también puedes crear copias de seguridad.": "Adjust routines, schedule, theme, icons, sound and alerts. You can also create backups from here.",
    "Sin abrir la extensión": "Without opening the extension", "Siguiente descanso": "Next break",
    // --- Varios dinámicos ---
    "según tus hábitos": "based on your habits", "Añadir al calendario": "Add to calendar", "No hay descansos pendientes que añadir": "No pending breaks to add",
    "Plan descargado: ábrelo en el móvil para añadirlo al calendario": "Plan downloaded: open it on your phone to add it to your calendar",
    "Horas ajustadas a tus hábitos": "Times adjusted to your habits", "Se guarda una copia al día en la carpeta «Pausa Bloom» de Descargas (los siete últimos días).": "One backup a day is saved in the «Pausa Bloom» folder inside Downloads (the last seven days).",
    "Prueba de Pausa Bloom": "Pausa Bloom test", "descanso nuevo": "new break", "descansos nuevos": "new breaks", "descanso pendiente": "break left", "descansos pendientes": "breaks left",
    "día seguido": "day in a row", "días seguidos": "days in a row", "árbol": "tree", "árboles": "trees", "tulipán": "tulip", "otoño": "autumn", "primavera": "spring", "verano": "summer", "invierno": "winter",
    "a horas fijas": "at fixed times", "repartidos": "spread out", "sin jornada": "no workday", "Quedan": "Left", "Completado": "Completed", "listo ✓": "done ✓", "Día": "Day"
  };

  const plural = (count, one, many) => `${count} ${Number(count) === 1 ? one : many}`;
  // Reglas para textos con números o nombres dentro: [expresión, función que devuelve el texto en inglés].
  const RULES = [
    [/^(\d+) descansos? pendientes?$/, (m) => plural(m[1], "break left", "breaks left")],
    [/^(\d+) descansos? (repartidos|a horas fijas)$/, (m, T) => `${plural(m[1], "break", "breaks")} ${T(m[2])}`],
    [/^(\d+) descansos? cada (\d+) min$/, (m) => `${plural(m[1], "break", "breaks")} every ${m[2]} min`],
    [/^(\d+) (descanso|descansos)$/, (m) => plural(m[1], "break", "breaks")],
    [/^(\d+) (descanso nuevo|descansos nuevos)$/, (m) => plural(m[1], "new break", "new breaks")],
    [/^(\d+) (árbol|árboles)$/, (m) => plural(m[1], "tree", "trees")],
    [/^(\d+) (flor|flores) en (.+)\. Cada rutina completa florece\.$/, (m, T) => `${plural(m[1], "flower", "flowers")} in ${T(m[3])}. Every completed routine blooms.`],
    [/^(\d+) de (\d+)$/, (m) => `${m[1]} of ${m[2]}`],
    [/^de (\d+) min$/, (m) => `of ${m[1]} min`],
    [/^Quedan (\d+)$/, (m) => `${m[1]} left`],
    [/^Descanso de (\d+) min$/, (m) => `${m[1]}-min break`],
    [/^dentro de (.+)$/, (m) => `in ${m[1]}`],
    [/^Termina a las (.+)\.$/, (m) => `Ends at ${m[1]}.`],
    [/^Tu descanso terminó a las (.+)\.$/, (m) => `Your break ended at ${m[1]}.`],
    [/^Hasta las (.+)$/, (m) => `Until ${m[1]}`],
    [/^Ya pasó la hora límite de las (.+)$/, (m) => `The time limit of ${m[1]} has passed`],
    [/^No hay descansos programados antes de las (.+)\.$/, (m) => `No breaks scheduled before ${m[1]}.`],
    [/^Descanso de (\d+) min iniciado a las (.+)$/, (m) => `${m[1]}-min break started at ${m[2]}`],
    [/^Descanso alargado (\d+) min$/, (m) => `Break extended by ${m[1]} min`],
    [/^Cuenta atrás reiniciada a las (.+)$/, (m) => `Countdown restarted at ${m[1]}`],
    [/^De vuelta$/, () => "Back"],
    [/^(\d+) min más de lo previsto$/, (m) => `${m[1]} min more than planned`],
    [/^Horario «(.+)» borrado$/, (m) => `Schedule «${m[1]}» deleted`],
    [/^Conectado con (.+)$/, (m) => `Connected to ${m[1]}`],
    [/^Paso (\d+) de (\d+)$/, (m) => `Step ${m[1]} of ${m[2]}`],
    [/^Día (\d+)$/, (m) => `Day ${m[1]}`],
    [/^Semana (\d+)$/, (m) => `Week ${m[1]}`],
    [/^(\d+) por tomar$/, (m) => `${m[1]} to take`],
    [/^Meta (\d+) min$/, (m) => `Goal ${m[1]} min`],
    [/^(largo|corto|Largo|Corto) (\d+\/\d+)$/, (m, T) => `${T(m[1])} ${m[2]}`],
    [/^Hoy, (.+)$/, (m) => `Today, ${m[1]}`],
    [/^Racha: (\d+) (día seguido|días seguidos) completando tu rutina$/, (m) => `Streak: ${plural(m[1], "day", "days")} in a row completing your routine`],
    [/^(.+) queda como día libre$/, (m, T) => `${T(m[1])} is now a day off`],
    [/^(.+) vuelve a ser laborable$/, (m, T) => `${T(m[1])} is a working day again`],
    [/^(.+) \(copia\)$/, (m) => `${m[1]} (copy)`],
    [/^Editar descanso de las (.+)$/, (m) => `Edit break at ${m[1]}`],
    [/^Borrar descanso de las (.+)$/, (m) => `Delete break at ${m[1]}`],
    [/^Quitar el descanso de las (.+)$/, (m) => `Remove the break at ${m[1]}`],
    [/^Empezar descanso de (\d+) minutos\. Quedan (\d+)\.$/, (m) => `Start a ${m[1]}-minute break. ${m[2]} left.`],
    [/^Código QR para conectar el móvil con @(.+)$/, (m) => `QR code to connect your phone to @${m[1]}`],
    [/^No se pudo abrir la pestaña: (.+)$/, (m) => `Could not open the tab: ${m[1]}`],
    [/^Pulsa (.+) para empezar el descanso sugerido y (.+) cuando vuelvas\. El icono de la barra muestra cuántos descansos te quedan o los minutos que faltan\.$/, (m) => `Press ${m[1]} to start the suggested break and ${m[2]} when you're back. The toolbar icon shows how many breaks you have left or the minutes remaining.`],
    [/^Última copia automática: (.+)$/, (m) => `Last automatic backup: ${m[1]}`],
    [/^Semana del (.+)$/, (m) => `Week of ${m[1]}`],
    [/^(d+) horarios$/, (m) => `${m[1]} schedules`],
    [/^rotación: (.+)$/, (m) => `rotation: ${m[1]}`],
    [/^Horas de este día: (.+)$/, (m) => `This day's hours: ${m[1]}`],
    [/^(.+) (pausa (.+))$/, (m) => `${m[1]} (lunch ${m[2]})`],
    [/^Copia restaurada$/, () => "Backup restored"]
  ];

  // Para textos largos (tutorial) se tolera que el final haya cambiado: se busca por el principio.
  const byPrefix = new Map(Object.keys(DICT).filter((key) => key.length >= 50).map((key) => [key.slice(0, 36), DICT[key]]));

  function translate(text) {
    const trimmed = text.trim();
    if (!trimmed) return text;
    const lead = text.slice(0, text.indexOf(trimmed));
    const trail = text.slice(lead.length + trimmed.length);
    const out = translateCore(trimmed);
    return out === trimmed ? text : lead + out + trail;
  }

  function translateCore(text) {
    if (Object.hasOwn(DICT, text)) return DICT[text];
    for (const [pattern, build] of RULES) {
      const match = text.match(pattern);
      if (match) return build(match, translateCore);
    }
    if (text.includes(" · ")) return text.split(" · ").map(translateCore).join(" · ");
    if (text.length >= 50 && byPrefix.has(text.slice(0, 36))) return byPrefix.get(text.slice(0, 36));
    // Frases con el nombre capitalizado al empezar (p. ej. "Largo 2/8" / "Día libre").
    const lower = text.charAt(0).toLowerCase() + text.slice(1);
    if (lower !== text && Object.hasOwn(DICT, lower)) {
      const out = DICT[lower];
      return out.charAt(0).toUpperCase() + out.slice(1);
    }
    return text;
  }

  const seen = new WeakMap();
  function translateTextNode(node) {
    const known = seen.get(node);
    if (known && node.data === known) return;
    const out = translate(node.data);
    seen.set(node, out);
    if (out !== node.data) node.data = out;
  }

  const ATTRIBUTES = ["title", "aria-label", "placeholder", "alt"];
  function translateTree(root) {
    if (root.nodeType === Node.TEXT_NODE) return translateTextNode(root);
    if (root.nodeType !== Node.ELEMENT_NODE) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let node = walker.currentNode; node; node = walker.nextNode()) {
      if (node.nodeType === Node.TEXT_NODE) {
        const tag = node.parentElement?.tagName;
        if (tag !== "SCRIPT" && tag !== "STYLE") translateTextNode(node);
      } else {
        for (const name of ATTRIBUTES) {
          const value = node.getAttribute(name);
          if (value) {
            const out = translate(value);
            if (out !== value) node.setAttribute(name, out);
          }
        }
      }
    }
  }

  // Traduce la página y todo lo que el programa vaya escribiendo después.
  function start() {
    translateTree(document.body);
    new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "characterData") translateTextNode(mutation.target);
        else mutation.addedNodes.forEach((node) => translateTree(node));
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  global.PausaI18n = { translate, start };
})(globalThis);
