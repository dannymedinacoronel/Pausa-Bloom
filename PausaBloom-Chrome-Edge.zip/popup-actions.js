// Render general y acciones: registrar, terminar, editar y borrar descansos.
// ---------- Render general ----------

function render() {
  dom.body.dataset.theme = state.settings.theme;
  renderHeader();
  renderToday();
  renderCalendar();
  renderDay();
  renderProgress();
  renderGardenBackground();
  renderGroupSummaries();
}

function showView(name, { save = true } = {}) {
  view = name;
  dom.body.dataset.view = name;
  $$(".view").forEach((section) => {
    const active = section.id === `view-${name}`;
    section.hidden = !active;
    section.classList.toggle("is-active", active);
  });
  $$(".tab").forEach((tab) => {
    const active = tab.dataset.viewTarget === name;
    tab.classList.toggle("is-active", active);
    if (active) tab.setAttribute("aria-current", "page");
    else tab.removeAttribute("aria-current");
  });
  dom.views.scrollTop = 0;
  if (name === "settings") renderSettings();
  updateLinkPolling();
  if (save) saveUiState();
}

function saveUiState() {
  return chrome.storage.local.set({
    uiState: {
      view,
      scrollTop: dom.views.scrollTop,
      mode,
      selectedDate,
      visibleMonth: Core.dateKey(visibleMonth),
      editingProfileId,
      weekOffset
    }
  });
}

function scheduleUiStateSave() {
  clearTimeout(uiStateTimer);
  uiStateTimer = setTimeout(saveUiState, 150);
}

function celebrate() {
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const layer = element("div", "confetti");
  layer.setAttribute("aria-hidden", "true");
  for (let index = 0; index < 36; index += 1) {
    const piece = element("i");
    piece.style.left = `${Math.random() * 100}%`;
    piece.style.animationDelay = `${Math.random() * 0.4}s`;
    piece.style.setProperty("--drift", `${(Math.random() - 0.5) * 140}px`);
    piece.style.setProperty("--spin", `${Math.random() * 720 - 360}deg`);
    piece.dataset.tone = String(index % 3);
    layer.append(piece);
  }
  document.body.append(layer);
  setTimeout(() => layer.remove(), 2400);
}

// ---------- Acciones ----------

// Los guardados van en cola y con una copia del estado, para que dos cambios seguidos no se pisen.
let writeChain = Promise.resolve();
function persist(keys) {
  const payload = {};
  for (const key of keys) payload[key] = structuredClone(state[key]);
  writeChain = writeChain.then(() => chrome.storage.local.set(payload)).catch((error) => console.warn("No se pudo guardar:", error));
  return writeChain;
}

async function registerBreak(minutes) {
  if (state.activeTimer) return;
  const plan = Core.planDay(state, mode);
  if (plan.status === "after") {
    showToast(`Ya pasó la hora límite de las ${formatTime(plan.end)}`);
    return;
  }
  const wasComplete = Core.progressFor(state, mode, todayKey()).complete;
  const { record, activeTimer } = Core.createBreak(mode, minutes, state.settings.timerEnabled, Date.now(), Core.workDay(state.settings));
  state.records = [...state.records, record];
  state.activeTimer = activeTimer;
  state.returnQuote = null;
  breathing = false;
  tipIndex = (tipIndex + 1) % TIPS.length;
  await persist(["records", "activeTimer", "returnQuote"]);
  // Sin cuenta atrás no hay "Ya volví": la frase aparece al registrar.
  if (!activeTimer) await drawReturnQuote(record.id);
  showToast(`Descanso de ${minutes} min iniciado a las ${formatTime(record.startedAt)}`);
  render();
  if (!wasComplete && Core.progressFor(state, mode, todayKey()).complete) celebrate();
}

// Si el móvil ya recibió una frase para este descanso, se muestra la misma.
async function drawReturnQuote(recordId) {
  if (state.returnQuote?.recordId === recordId) return;
  const { quoteDeck } = await chrome.storage.local.get("quoteDeck");
  const { index, deck } = PausaQuotes.drawQuote(quoteDeck);
  state.returnQuote = { index, recordId, at: Date.now() };
  await chrome.storage.local.set({ quoteDeck: deck, returnQuote: state.returnQuote });
}

function renderQuote() {
  const quote = state.returnQuote && !state.activeTimer ? PausaQuotes.QUOTES[state.returnQuote.index] : null;
  dom.quoteCard.hidden = !quote;
  if (!quote) return;
  dom.quoteText.textContent = quoteText(quote);
  dom.quoteAuthor.textContent = quoteAuthor(quote);
}

async function finishTimer() {
  const timer = state.activeTimer;
  if (!timer) return;
  const now = Date.now();
  state.records = Core.closeActive(state.records, timer, now);
  state.activeTimer = null;
  breathing = false;
  await persist(["records", "activeTimer"]);
  await drawReturnQuote(timer.recordId);
  dom.views.scrollTop = 0;
  const record = state.records.find((item) => item.id === timer.recordId);
  const overtime = record ? Core.overtimeMinutes(record) : 0;
  showToast(overtime ? `De vuelta · ${overtime} min más de lo previsto` : "De vuelta a tiempo");
  render();
}

async function deleteRecord(id, message = "Descanso borrado") {
  const before = snapshot();
  state.records = state.records.filter((item) => item.id !== id);
  if (state.activeTimer?.recordId === id) state.activeTimer = null;
  if (editingId === id) closeRecordForm();
  await persist(["records", "activeTimer"]);
  showToast(message, () => restoreSnapshot(before));
  render();
}

// Alarga el descanso en curso sin cambiar su duración prevista (la rutina sigue contando igual).
async function extendTimer(minutes) {
  if (!state.activeTimer) return;
  const before = snapshot();
  const timer = state.activeTimer;
  // Si ya te habías pasado, los minutos se cuentan desde ahora.
  const endAt = Math.max(timer.endAt, Date.now()) + minutes * MINUTE;
  state.activeTimer = { ...timer, endAt, extraMinutes: Math.round((endAt - timer.startedAt) / MINUTE) - timer.minutes };
  await persist(["activeTimer"]);
  showToast(`Descanso alargado ${minutes} min`, () => restoreSnapshot(before));
  renderToday();
}

// Vuelve a empezar la cuenta atrás desde ahora (por ejemplo, si lo pulsaste antes de levantarte).
async function restartTimer() {
  if (!state.activeTimer) return;
  const before = snapshot();
  const now = Date.now();
  const timer = state.activeTimer;
  state.activeTimer = { ...timer, startedAt: now, endAt: now + timer.minutes * MINUTE, extraMinutes: 0 };
  state.records = state.records.map((record) => (record.id === timer.recordId ? { ...record, startedAt: now } : record));
  await persist(["records", "activeTimer"]);
  showToast(`Cuenta atrás reiniciada a las ${formatTime(now)}`, () => restoreSnapshot(before));
  render();
}

function openRecordForm(record = null) {
  editingId = record?.id || null;
  dom.recordFormTitle.textContent = record ? "Editar descanso" : "Añadir descanso";
  dom.recordMode.value = record?.mode || mode;
  if (record) {
    dom.recordMinutes.value = record.plannedMinutes;
    dom.recordStart.value = timeInputValue(record.startedAt);
    dom.recordEnd.value = record.completedAt ? timeInputValue(record.completedAt) : "";
  } else {
    const progress = Core.progressFor(state, dom.recordMode.value, selectedDate);
    const next = progress.groups.find((group) => group.remaining > 0) || progress.groups[0];
    dom.recordMinutes.value = next?.minutes || 5;
    dom.recordStart.value = selectedDate === todayKey() ? timeInputValue(Date.now()) : "12:00";
    dom.recordEnd.value = "";
  }
  dom.recordFormMessage.textContent = "";
  dom.recordForm.hidden = false;
  revealInViews(dom.recordForm, false);
  dom.recordMinutes.focus();
}

function closeRecordForm() {
  editingId = null;
  dom.recordForm.hidden = true;
  dom.recordFormMessage.textContent = "";
}

async function saveRecordForm(event) {
  event.preventDefault();
  const fail = (message) => { dom.recordFormMessage.textContent = message; };
  const minutes = Number(dom.recordMinutes.value);
  if (!Number.isInteger(minutes) || minutes < 1 || minutes > 120) return fail("La duración debe ser de 1 a 120 minutos.");
  if (!dom.recordStart.value) return fail("Indica la hora de inicio.");
  const startedAt = Core.timestampFor(selectedDate, dom.recordStart.value);
  if (startedAt > Date.now()) return fail("La hora de inicio no puede estar en el futuro.");
  let completedAt = null;
  if (dom.recordEnd.value) {
    completedAt = Core.timestampFor(selectedDate, dom.recordEnd.value);
    if (completedAt <= startedAt) return fail("La vuelta debe ser posterior al inicio.");
    if (completedAt > Date.now()) return fail("La hora de vuelta no puede estar en el futuro.");
  }

  const fields = { day: selectedDate, mode: dom.recordMode.value, startedAt, plannedMinutes: minutes, completedAt };
  const wasEditing = Boolean(editingId);
  if (editingId) {
    state.records = state.records.map((record) => (record.id === editingId ? { ...record, ...fields } : record));
    if (state.activeTimer?.recordId === editingId) {
      state.activeTimer = completedAt ? null : { ...state.activeTimer, startedAt, endAt: startedAt + minutes * MINUTE, minutes };
    }
  } else {
    state.records = [...state.records, { id: crypto.randomUUID(), ...fields }];
  }
  closeRecordForm();
  await persist(["records", "activeTimer"]);
  showToast(wasEditing ? "Descanso actualizado" : "Descanso añadido");
  render();
}

async function toggleDayOff(day = selectedDate) {
  const before = snapshot();
  const off = state.daysOff.includes(day);
  state.daysOff = off ? state.daysOff.filter((item) => item !== day) : [...state.daysOff, day];
  await persist(["daysOff"]);
  const label = day === todayKey() ? "Hoy" : "El día";
  showToast(off ? `${label} vuelve a ser laborable` : `${label} queda como día libre`, () => restoreSnapshot(before));
  render();
}

function changeMonth(step) {
  visibleMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + step, 1);
  if (selectedDate.slice(0, 7) !== Core.dateKey(visibleMonth).slice(0, 7)) selectedDate = Core.dateKey(visibleMonth);
  closeRecordForm();
  scheduleUiStateSave();
  renderCalendar();
  renderDay();
  renderProgress();
}

