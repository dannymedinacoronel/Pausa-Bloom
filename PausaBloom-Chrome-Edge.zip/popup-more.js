// Funciones añadidas: asistente de inicio, ejercicios guiados, galería del jardín, imagen para compartir y ventana flotante.
// Los textos se escriben con L("español", "english"), así que no necesitan pasar por i18n.js.
const L = (es, en) => (state.settings.language === "en" ? en : es);
const SVG_NS = "http://www.w3.org/2000/svg";
let moreUiReady = false;

// Crea (una sola vez) los elementos que se añaden por código; se llama desde render().
function ensureMoreUi() {
  if (moreUiReady) return;
  moreUiReady = true;

  const wizardButton = element("button", "btn btn-secondary btn-sm", L("Asistente de configuración", "Setup wizard"));
  wizardButton.type = "button";
  wizardButton.style.marginLeft = "8px";
  wizardButton.addEventListener("click", startWizard);
  $("#g-help .settings-card").append(wizardButton);

  const floatButton = element("button", "icon-btn");
  floatButton.type = "button";
  floatButton.title = L("Mini ventana flotante", "Floating mini window");
  floatButton.setAttribute("aria-label", floatButton.title);
  floatButton.append(icon("i-clock"));
  floatButton.addEventListener("click", openFloating);
  $("#pop-out").before(floatButton);

  const exercise = element("div", "card exercise");
  exercise.innerHTML = `<div class="ex-idle"><select id="ex-select" aria-label="${L("Ejercicio", "Exercise")}"></select><button id="ex-start" class="btn btn-secondary btn-sm" type="button">${L("Guiarme", "Guide me")}</button></div>
    <div class="ex-live" hidden><div class="ex-circle" id="ex-circle"></div><div class="ex-text"><strong id="ex-step"></strong><span id="ex-count"></span></div><div class="ex-bar"><i id="ex-fill"></i></div><button id="ex-stop" class="btn-link" type="button">${L("Parar", "Stop")}</button></div>`;
  EXERCISES.forEach((item, index) => exercise.querySelector("#ex-select").append(new Option(`${L(item.es, item.en)} · ${exerciseSeconds(item)} s`, String(index))));
  exercise.querySelector("#ex-start").addEventListener("click", () => startExercise(EXERCISES[Number($("#ex-select").value)]));
  exercise.querySelector("#ex-stop").addEventListener("click", stopExercise);
  $("#running .running-actions").before(exercise);

  const gallery = element("section", "card");
  gallery.id = "gallery-card";
  gallery.innerHTML = `<div class="card-head"><div><h3>${L("Galería", "Gallery")}</h3><p class="muted small">${L("Tu jardín mes a mes. Toca uno para guardarlo como imagen.", "Your garden month by month. Tap one to save it as an image.")}</p></div><button id="share-now" class="btn btn-secondary btn-sm" type="button">${L("Compartir", "Share")}</button></div><div class="gallery" id="gallery"></div>`;
  $("#garden-card").before(gallery);
  gallery.querySelector("#share-now").addEventListener("click", () => shareGardenImage(todayKey(), L("Mi jardín", "My garden")));
}

// ---------- Asistente de inicio ----------

function startWizard() {
  const d = { start: "09:00", end: "19:00", mode: "spread", interval: 60, five: 6, ten: 2, pause: false, pauseStart: "14:00", pauseEnd: "15:00", endAlert: true, suggestAlert: true, theme: state.settings.theme };
  const themes = { pink: "Peonía", classic: "Porcelana", night: "Medianoche", noir: "Rosa Noir" };
  const switchRow = (id, label, checked) => `<label class="wz-switch"><span>${label}</span><input id="${id}" type="checkbox" class="switch" ${checked ? "checked" : ""}></label>`;
  const pages = [
    {
      html: () => `<h2>${L("¿Cómo es tu jornada?", "What does your workday look like?")}</h2><p>${L("Con esto calculamos a qué hora te toca descansar.", "We use this to work out when you should rest.")}</p>
        <div class="wz-row"><label>${L("Empiezo a las", "I start at")}<input id="wz-start" type="time" value="${d.start}"></label><label>${L("Termino a las", "I finish at")}<input id="wz-end" type="time" value="${d.end}"></label></div>
        <p class="small">${L("Si terminas antes de la hora de inicio (turno de noche), también funciona.", "A finish time earlier than the start (night shift) works too.")}</p>`,
      read(root) {
        d.start = $("#wz-start", root).value;
        d.end = $("#wz-end", root).value;
        return !d.start || !d.end || d.start === d.end ? L("Indica una hora de inicio y otra de fin distintas.", "Enter a start and an end time that differ.") : "";
      }
    },
    {
      html: () => `<h2>${L("¿Cómo quieres descansar?", "How do you want to rest?")}</h2>
        <label class="wz-choice"><input type="radio" name="wz-mode" value="spread" ${d.mode === "spread" ? "checked" : ""}><span><strong>${L("Repartidos", "Spread out")}</strong><small>${L("Los repartimos a lo largo de tu jornada.", "We spread them across your day.")}</small></span></label>
        <label class="wz-choice"><input type="radio" name="wz-mode" value="interval" ${d.mode === "interval" ? "checked" : ""}><span><strong>${L("Cada cierto tiempo", "At a fixed interval")}</strong><small>${L("Uno cada", "One every")} <input id="wz-interval" type="number" min="15" max="240" step="5" value="${d.interval}"> min</small></span></label>
        <div class="wz-row"><label>${L("Descansos de 5 min", "5-min breaks")}<input id="wz-five" type="number" min="0" max="30" value="${d.five}"></label><label>${L("Descansos de 10 min", "10-min breaks")}<input id="wz-ten" type="number" min="0" max="30" value="${d.ten}"></label></div>`,
      read(root) {
        d.mode = root.querySelector('input[name="wz-mode"]:checked').value;
        d.interval = Number($("#wz-interval", root).value);
        d.five = Number($("#wz-five", root).value);
        d.ten = Number($("#wz-ten", root).value);
        const valid = [d.five, d.ten].every((n) => Number.isInteger(n) && n >= 0 && n <= 30) && d.five + d.ten > 0 && Number.isInteger(d.interval) && d.interval >= 15 && d.interval <= 240;
        return valid ? "" : L("Pon al menos un descanso (0 a 30) y un intervalo de 15 a 240 minutos.", "Enter at least one break (0 to 30) and an interval of 15 to 240 minutes.");
      }
    },
    {
      html: () => `<h2>${L("¿Tienes pausa de comida?", "Do you have a lunch break?")}</h2><p>${L("En esa franja no te sugeriremos descansos.", "We won't suggest breaks during it.")}</p>
        ${switchRow("wz-pause", L("Tengo pausa de comida", "I have a lunch break"), d.pause)}
        <div class="wz-row"><label>${L("De", "From")}<input id="wz-pause-start" type="time" value="${d.pauseStart}"></label><label>${L("a", "to")}<input id="wz-pause-end" type="time" value="${d.pauseEnd}"></label></div>`,
      read(root) {
        d.pause = $("#wz-pause", root).checked;
        d.pauseStart = $("#wz-pause-start", root).value;
        d.pauseEnd = $("#wz-pause-end", root).value;
        return d.pause && (!d.pauseStart || !d.pauseEnd || d.pauseStart >= d.pauseEnd) ? L("La pausa necesita un inicio y un fin (el fin, después).", "The break needs a start and an end (end after start).") : "";
      }
    },
    {
      html: () => `<h2>${L("Avisos y aspecto", "Alerts and look")}</h2>
        ${switchRow("wz-end-alert", L("Avisarme cuando termine el descanso", "Alert me when the break ends"), d.endAlert)}
        ${switchRow("wz-suggest-alert", L("Avisarme a la hora sugerida", "Alert me at the suggested time"), d.suggestAlert)}
        <label style="margin-top:10px">${L("Tema", "Theme")}<select id="wz-theme">${Object.entries(themes).map(([id, name]) => `<option value="${id}" ${d.theme === id ? "selected" : ""}>${name}</option>`).join("")}</select></label>`,
      read(root) {
        d.endAlert = $("#wz-end-alert", root).checked;
        d.suggestAlert = $("#wz-suggest-alert", root).checked;
        d.theme = $("#wz-theme", root).value;
        return "";
      }
    }
  ];

  const overlay = element("div", "wizard");
  overlay.innerHTML = `<div class="wizard-card" role="dialog" aria-modal="true"><span class="overline" id="wz-step"></span><div id="wz-body"></div><p class="form-error" id="wz-error" role="alert"></p>
    <div class="tour-footer"><div class="tour-dots" id="wz-dots"></div><div class="tour-buttons"><button id="wz-skip" class="btn btn-ghost btn-sm" type="button">${L("Saltar", "Skip")}</button><button id="wz-back" class="btn btn-secondary btn-sm" type="button">${L("Atrás", "Back")}</button><button id="wz-next" class="btn btn-primary btn-sm" type="button"></button></div></div></div>`;
  document.body.append(overlay);

  let index = 0;
  const show = () => {
    $("#wz-body", overlay).innerHTML = pages[index].html();
    $("#wz-step", overlay).textContent = L(`Configuración · paso ${index + 1} de ${pages.length}`, `Setup · step ${index + 1} of ${pages.length}`);
    $("#wz-error", overlay).textContent = "";
    $("#wz-back", overlay).hidden = index === 0;
    $("#wz-next", overlay).textContent = index === pages.length - 1 ? L("Terminar", "Finish") : L("Siguiente", "Next");
    $("#wz-dots", overlay).replaceChildren(...pages.map((_, position) => element("i", position === index ? "is-active" : "")));
  };
  const close = async () => {
    overlay.remove();
    await chrome.storage.local.set({ wizardDone: true });
    const { tutorialDone } = await chrome.storage.local.get("tutorialDone");
    if (!tutorialDone) startTour();
  };
  $("#wz-skip", overlay).addEventListener("click", close);
  $("#wz-back", overlay).addEventListener("click", () => { pages[index].read(overlay); index -= 1; show(); });
  $("#wz-next", overlay).addEventListener("click", async () => {
    const error = pages[index].read(overlay);
    if (error) { $("#wz-error", overlay).textContent = error; return; }
    if (index < pages.length - 1) { index += 1; show(); return; }
    const profile = state.settings.profiles[0];
    profile.hours.long = { start: d.start, end: d.end };
    profile.breakUntil.long = d.end;
    profile.routines.long = { 5: { count: d.five, minutes: 5 }, 10: { count: d.ten, minutes: 10 }, 15: { count: 0, minutes: 15 } };
    profile.plan.mode = d.mode;
    profile.plan.interval = d.interval;
    profile.pause.long = d.pause ? { start: d.pauseStart, end: d.pauseEnd } : { start: "", end: "" };
    Object.assign(state.settings, { endAlert: d.endAlert, suggestAlert: d.suggestAlert, theme: d.theme });
    mode = "long";
    await saveSettings(L("¡Todo listo!", "All set!"));
    close();
  });
  show();
}

// ---------- Ejercicios guiados (durante el descanso) ----------

// Cada paso: [español, inglés, segundos, fase de respiración opcional].
const EXERCISES = [
  { es: "Cuello", en: "Neck", steps: [["Inclina la cabeza a la derecha", "Tilt your head to the right", 15], ["Inclina la cabeza a la izquierda", "Tilt your head to the left", 15], ["Mira hacia abajo, barbilla al pecho", "Look down, chin to chest", 10]] },
  { es: "Hombros", en: "Shoulders", steps: [["Sube los hombros hacia las orejas", "Raise your shoulders to your ears", 5], ["Suéltalos de golpe y exhala", "Drop them and breathe out", 5], ["Gíralos hacia atrás, despacio", "Roll them back, slowly", 20]] },
  { es: "Muñecas y manos", en: "Wrists and hands", steps: [["Gira las muñecas hacia un lado", "Rotate your wrists one way", 15], ["Ahora hacia el otro", "Now the other way", 15], ["Abre y cierra las manos", "Open and close your hands", 15]] },
  { es: "Espalda", en: "Back", steps: [["Siéntate recto y estira los brazos arriba", "Sit tall and reach your arms up", 15], ["Gira el tronco a la derecha", "Twist your torso to the right", 15], ["Gira el tronco a la izquierda", "Twist to the left", 15]] },
  { es: "Vista (20-20-20)", en: "Eyes (20-20-20)", steps: [["Mira algo a más de 6 metros", "Look at something 20 ft away", 20], ["Parpadea despacio 10 veces", "Blink slowly 10 times", 10], ["Cierra los ojos y descansa", "Close your eyes and rest", 15]] },
  { es: "Respiración 4-7-8", en: "4-7-8 breathing", rounds: 4, steps: [["Inhala por la nariz", "Inhale through your nose", 4, "in"], ["Mantén el aire", "Hold your breath", 7], ["Exhala despacio por la boca", "Exhale slowly through your mouth", 8, "out"]] },
  { es: "Respiración cuadrada", en: "Box breathing", rounds: 4, steps: [["Inhala", "Inhale", 4, "in"], ["Mantén", "Hold", 4], ["Exhala", "Exhale", 4, "out"], ["Mantén", "Hold", 4]] },
  { es: "Caminata", en: "Walk", steps: [["Levántate y camina un poco", "Stand up and walk a little", 60]] }
];
const exerciseSeconds = (item) => item.steps.reduce((sum, step) => sum + step[2], 0) * (item.rounds || 1);
let exerciseTimer = null;

function stopExercise() {
  clearInterval(exerciseTimer);
  exerciseTimer = null;
  $(".ex-idle").hidden = false;
  $(".ex-live").hidden = true;
}

function startExercise(item) {
  const steps = Array.from({ length: item.rounds || 1 }, () => item.steps).flat().map(([es, en, seconds, phase]) => ({ text: L(es, en), seconds, phase }));
  const total = steps.reduce((sum, step) => sum + step.seconds, 0) * 1000;
  const begin = Date.now();
  const circle = $("#ex-circle");
  let current = 0;
  let stepEnd = begin;
  const apply = () => {
    const step = steps[current];
    stepEnd = Date.now() + step.seconds * 1000;
    $("#ex-step").textContent = step.text;
    // Solo la respiración anima el círculo; en las pausas (sin fase) conserva su tamaño.
    circle.hidden = !item.rounds;
    if (step.phase) {
      circle.style.transitionDuration = `${step.seconds}s`;
      circle.dataset.phase = step.phase;
    }
  };
  $(".ex-idle").hidden = true;
  $(".ex-live").hidden = false;
  circle.dataset.phase = "out";
  apply();
  clearInterval(exerciseTimer);
  exerciseTimer = setInterval(() => {
    const now = Date.now();
    if (!state.activeTimer) return stopExercise();
    if (now >= stepEnd) {
      current += 1;
      if (current >= steps.length) {
        $("#ex-step").textContent = L("¡Bien hecho!", "Well done!");
        $("#ex-count").textContent = "✓";
        clearInterval(exerciseTimer);
        setTimeout(stopExercise, 3000);
        return;
      }
      apply();
    }
    $("#ex-count").textContent = `${Math.ceil((stepEnd - now) / 1000)} s`;
    $("#ex-fill").style.width = `${Math.min(100, ((now - begin) / total) * 100)}%`;
  }, 250);
}

// ---------- Galería del jardín e imagen para compartir ----------

function renderGallery() {
  ensureMoreUi();
  const box = $("#gallery");
  box.replaceChildren();
  const entries = gardenEntries();
  if (!entries.length) {
    box.append(element("p", "muted small", L("Aún no hay meses que mostrar.", "No months to show yet.")));
    return;
  }
  const first = entries.map((entry) => entry.day).sort()[0].slice(0, 7);
  const now = new Date();
  for (let cursor = new Date(now.getFullYear(), now.getMonth(), 1), shown = 0; shown < 12 && Core.dateKey(cursor).slice(0, 7) >= first; cursor = new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1), shown += 1) {
    const lastDay = Core.dateKey(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0));
    const endDay = lastDay < todayKey() ? lastDay : todayKey();
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 380 110");
    svg.setAttribute("preserveAspectRatio", "xMidYMax slice");
    const info = PausaGarden.render(svg, entries.filter((entry) => entry.day <= endDay), endDay, { decor: false });
    const trees = info.counts.young + info.counts.tree;
    const label = formatDate(cursor, { month: "long", year: "numeric" });
    const tile = element("button", "gallery-tile");
    tile.type = "button";
    tile.title = L("Guardar como imagen", "Save as image");
    tile.append(svg, element("strong", "", label), element("span", "", L(`${info.completeDays} días completos · ${trees} árboles`, `${info.completeDays} full days · ${trees} trees`)));
    tile.addEventListener("click", () => shareGardenImage(endDay, label));
    box.append(tile);
  }
}

// Atributos de estilo que hay que copiar a mano para que el SVG se vea igual fuera de la página.
const INLINE_PROPS = ["fill", "fill-opacity", "stroke", "stroke-width", "stroke-linecap", "stroke-opacity", "opacity", "stop-color", "stop-opacity"];

async function shareGardenImage(endDay, title) {
  try {
    const entries = gardenEntries().filter((entry) => entry.day <= endDay);
    const extras = Core.challenges(state).filter((challenge) => challenge.done).length;
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 380 110");
    svg.setAttribute("width", "1080");
    svg.setAttribute("height", "313");
    svg.style.cssText = "position:fixed;left:-9999px;top:0";
    const info = PausaGarden.render(svg, entries, endDay, { decor: false, extras });
    document.body.append(svg);
    for (const node of svg.querySelectorAll("*")) {
      const computed = getComputedStyle(node);
      for (const prop of INLINE_PROPS) node.style.setProperty(prop, computed.getPropertyValue(prop));
    }
    // El SVG estaba fuera de pantalla para medir estilos; para la imagen debe quedar en su sitio.
    svg.removeAttribute("style");
    const xml = new XMLSerializer().serializeToString(svg);
    svg.remove();
    const image = new Image();
    image.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(xml)}`;
    await image.decode();

    const css = getComputedStyle(document.body);
    const canvas = document.createElement("canvas");
    canvas.width = 1080;
    canvas.height = 1350;
    const ctx = canvas.getContext("2d");
    const background = ctx.createLinearGradient(0, 0, 0, 1350);
    background.addColorStop(0, css.getPropertyValue("--accent-soft").trim() || "#fff");
    background.addColorStop(0.5, css.getPropertyValue("--bg").trim() || "#fff");
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, 1080, 1350);
    ctx.fillStyle = css.getPropertyValue("--text").trim() || "#222";
    ctx.font = "700 72px 'Segoe UI', sans-serif";
    ctx.fillText(title, 72, 170);
    ctx.fillStyle = css.getPropertyValue("--text-2").trim() || "#555";
    ctx.font = "400 38px 'Segoe UI', sans-serif";
    ctx.fillText(L("Mi jardín de descansos", "My garden of breaks"), 72, 232);
    ctx.drawImage(image, 0, 430, 1080, 313);
    const trees = info.counts.young + info.counts.tree;
    ctx.fillStyle = css.getPropertyValue("--text").trim() || "#222";
    ctx.font = "600 52px 'Segoe UI', sans-serif";
    ctx.fillText(L(`${info.completeDays} días con la rutina completa`, `${info.completeDays} days with the full routine`), 72, 900);
    ctx.fillStyle = css.getPropertyValue("--text-2").trim() || "#555";
    ctx.font = "400 42px 'Segoe UI', sans-serif";
    ctx.fillText(L(`${info.counts.flower} flores · ${info.counts.bush} arbustos · ${trees} árboles`, `${info.counts.flower} flowers · ${info.counts.bush} bushes · ${trees} trees`), 72, 980);
    ctx.fillText(L(`Racha actual: ${Core.currentStreak(state)} días`, `Current streak: ${Core.currentStreak(state)} days`), 72, 1050);
    ctx.fillStyle = css.getPropertyValue("--accent-text").trim() || "#c33";
    ctx.font = "700 40px 'Segoe UI', sans-serif";
    ctx.fillText("Pausa Bloom", 72, 1260);

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `pausa-bloom-jardin-${endDay}.png`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast(L("Imagen guardada en Descargas", "Image saved to Downloads"));
  } catch (error) {
    showToast(L("No se pudo crear la imagen", "Could not create the image"));
  }
}

// ---------- Ventana flotante (siempre visible encima de las demás) ----------

async function openFloating() {
  if (!window.documentPictureInPicture) {
    showToast(L("Tu navegador no admite la ventana flotante", "Your browser doesn't support the floating window"));
    return;
  }
  // En la ventana emergente normal se cerraría al perder el foco: se abre antes la ventana propia.
  if (!document.documentElement.classList.contains("is-window")) {
    await chrome.windows.create({ url: chrome.runtime.getURL("popup.html?window=1"), type: "popup", width: 400, height: 680 });
    window.close();
    return;
  }
  const pip = await documentPictureInPicture.requestWindow({ width: 230, height: 150 });
  const link = pip.document.createElement("link");
  link.rel = "stylesheet";
  link.href = new URL("popup.css", location.href).href;
  pip.document.head.append(link);
  pip.document.documentElement.classList.add("pip-doc");
  pip.document.body.dataset.theme = state.settings.theme;
  pip.document.body.dataset.view = "today";
  const box = pip.document.createElement("div");
  box.className = "pip";
  box.innerHTML = `<strong></strong><span></span><div class="pip-actions"></div>`;
  pip.document.body.append(box);
  const actions = box.querySelector(".pip-actions");
  const makeButton = (label, handler, primary) => {
    const button = pip.document.createElement("button");
    button.className = `btn btn-sm ${primary ? "btn-primary" : "btn-secondary"}`;
    button.textContent = label;
    button.addEventListener("click", handler);
    return button;
  };
  const draw = () => {
    const timer = state.activeTimer;
    actions.replaceChildren();
    if (timer) {
      const remaining = timer.endAt - Date.now();
      box.classList.toggle("is-over", remaining <= 0);
      box.querySelector("strong").textContent = (remaining <= 0 ? "+" : "") + formatClock(Math.abs(remaining <= 0 ? Math.floor(remaining / 1000) : Math.ceil(remaining / 1000)));
      box.querySelector("span").textContent = remaining <= 0 ? L("tiempo extra", "overtime") : L("descanso en curso", "break in progress");
      actions.append(makeButton(L("Ya volví", "I'm back"), finishTimer, true), makeButton("+5", () => extendTimer(5)));
    } else {
      const plan = Core.planDay(state, mode);
      box.classList.remove("is-over");
      box.querySelector("strong").textContent = plan.status === "ok" ? (plan.late ? L("Ahora", "Now") : formatTime(plan.next.time)) : "–";
      box.querySelector("span").textContent = plan.status === "ok" ? L(`siguiente: ${plan.next.minutes} min`, `next: ${plan.next.minutes} min`) : L("sin descansos pendientes", "no breaks left");
      if (plan.status === "ok") actions.append(makeButton(L("Empezar", "Start"), () => registerBreak(plan.next.minutes), true));
    }
  };
  draw();
  const ticker = setInterval(draw, 1000);
  pip.addEventListener("pagehide", () => clearInterval(ticker));
}
