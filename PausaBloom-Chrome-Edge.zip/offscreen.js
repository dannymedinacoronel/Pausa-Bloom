// Documento invisible que reproduce el sonido de fin de descanso con la ventana cerrada.
chrome.runtime.onMessage.addListener((message) => {
  if (message?.target === "offscreen" && message.type === "play") PausaSound.play(message.sound);
});
