// Pantalla Hoy: anillo, sugerencia, botones de descanso y plan del día.
// ---------- Hoy ----------

function setRing(fraction) {
  const clamped = Math.max(0, Math.min(1, fraction));
  dom.ringFill.style.strokeDasharray = String(RING_CIRCUMFERENCE);
  dom.ringFill.style.strokeDashoffset = String(RING_CIRCUMFERENCE * (1 - clamped));
}

function renderHeader() {
  dom.headerDate.textContent = formatDate(new Date());
  const streak = Core.currentStreak(state);
  dom.streak.hidden = streak === 0;
  dom.streakCount.textContent = String(streak);
  dom.streak.title = `Racha: ${plural(streak, "día seguido", "días seguidos")} completando tu rutina`;
}

function renderSegments() {
  dom.segments.forEach((segment) => {
    const selected = segment.dataset.mode === mode;
    segment.classList.toggle("is-active", selected);
    segment.setAttribute("aria-selected", String(selected));
  });
  const profile = Core.profileFor(state.settings, todayKey());
  const hours = Core.hoursFor(state.settings, mode, todayKey());
  const lunch = profile.pause?.[mode]?.start ? ` (pausa ${profile.pause[mode].start}–${profile.pause[mode].end})` : "";
  const planLabel = { spread: "repartidos", interval: `cada ${profile.plan.interval} min`, fixed: "a horas fijas" }[profile.plan.mode];
  const progress = Core.progressFor(state, mode, todayKey());
  dom.scheduleLine.replaceChildren(
    icon("i-clock"),
    `${state.settings.profiles.length > 1 ? `${profile.name} · ` : ""}${hours.start}–${hours.end}${lunch} · ${plural(progress.total, "descanso", "descansos")} ${planLabel}`
  );
}

function renderHero() {
  const progress = Core.progressFor(state, mode, todayKey());
  const timer = state.activeTimer;
  dom.hero.classList.toggle("is-running", Boolean(timer));
  dom.hero.classList.toggle("is-breathing", Boolean(timer) && breathing);
  dom.hero.classList.toggle("is-complete", !timer && progress.complete);

  if (timer) {
    const remaining = timer.endAt - Date.now();
    const overtime = remaining <= 0;
    dom.hero.classList.toggle("is-overtime", overtime);
    const totalMinutes = timer.minutes + (timer.extraMinutes || 0);
    setRing(overtime ? 1 : remaining / (totalMinutes * MINUTE));
    dom.ringValue.textContent = overtime
      ? `+${formatClock(Math.floor(-remaining / 1000))}`
      : formatClock(Math.ceil(remaining / 1000));
    dom.ringLabel.textContent = "";
    if (breathing) {
      const phase = ((Date.now() - breathStart) / 1000) % (BREATH_IN + BREATH_OUT);
      dom.ringCaption.textContent = phase < BREATH_IN ? "Inhala" : "Exhala";
    } else {
      dom.ringCaption.textContent = overtime ? "tiempo extra" : `de ${totalMinutes} min`;
    }
    // Mientras descansas, la planta sigue creciendo segundo a segundo.
    const activeRecord = state.records.find((record) => record.id === timer.recordId);
    const counted = activeRecord?.mode === mode && activeRecord.day === todayKey() && progress.done > 0 ? 1 : 0;
    const fraction = Math.min(1, (Date.now() - timer.startedAt) / (totalMinutes * MINUTE));
    growPlantTo(progress.total ? (progress.done - counted + fraction) / progress.total : 0, 1000);
    dom.heroTitle.textContent = overtime ? "Es hora de volver" : "Desconecta un momento";
    dom.heroMessage.textContent = overtime
      ? `Tu descanso terminó a las ${formatTime(timer.endAt)}.`
      : `Termina a las ${formatTime(timer.endAt)}.`;
  } else {
    dom.hero.classList.remove("is-overtime");
    setRing(progress.total ? progress.done / progress.total : 0);
    dom.ringLabel.textContent = "";
    dom.ringValue.textContent = `${progress.done}/${progress.total}`;
    dom.ringCaption.textContent = `${progress.done} de ${progress.total}`;
    growPlantTo(progress.total ? progress.done / progress.total : 0);
    const remainingMinutes = progress.groups.reduce((sum, group) => sum + group.remaining * group.minutes, 0);
    dom.heroTitle.textContent = progress.complete
      ? "Rutina completa"
      : progress.done > 0 ? "Buen ritmo" : "Listo para empezar";
    dom.heroMessage.textContent = progress.complete
      ? "Has cuidado tus descansos hoy."
      : `${capitalize(plural(progress.total - progress.done, "descanso pendiente", "descansos pendientes"))} · ${remainingMinutes} min`;
  }

  dom.tokens.replaceChildren();
  progress.groups.forEach((group) => {
    const row = element("div", "token-row");
    row.setAttribute("aria-label", `${group.minutes} minutos: ${group.taken} de ${group.count}`);
    const dots = element("span", "token-dots");
    for (let index = 0; index < group.count; index += 1) dots.append(element("i", index < group.taken ? "is-filled" : ""));
    row.append(element("span", "token-label", `${group.minutes} min`), dots);
    dom.tokens.append(row);
  });
  if (progress.extra > 0) dom.tokens.append(element("span", "token-extra", `+${progress.extra} extra`));
}

function renderSuggestion(plan) {
  const timer = state.activeTimer;
  dom.suggestion.hidden = Boolean(timer) || plan.status === "complete";
  if (timer) return;

  const set = (iconName, label, time, detail, action) => {
    dom.suggestionLabel.textContent = label;
    dom.suggestionTime.textContent = time;
    dom.suggestionDetail.textContent = detail;
    dom.suggestionAction.hidden = !action;
    dom.suggestionAction.replaceChildren();
    if (action) {
      const actionIcon = plan.status === "ok" ? element("span", "choice-icon", state.settings.icons[mode]) : icon(iconName);
      actionIcon.setAttribute("aria-hidden", "true");
      dom.suggestionAction.append(actionIcon, document.createTextNode(action));
    }
  };
  dom.suggestion.classList.toggle("is-now", plan.status === "ok" && plan.late);
  dom.suggestion.classList.toggle("is-done", plan.status === "complete");

  if (plan.status === "ok") {
    const wait = Math.round((plan.next.time - Date.now()) / MINUTE);
    if (plan.late || wait <= 0) {
      set("i-clock", "Buen momento para descansar", "Ahora", `Descanso de ${plan.next.minutes} min`, "Empezar");
    } else {
      set("i-clock", "Siguiente descanso", formatTime(plan.next.time), `${plan.next.minutes} min · dentro de ${formatDuration(wait)}`, "Empezar");
    }
  } else if (plan.status === "complete") {
    set("i-check", "Hoy", "Rutina completa", "Ya tomaste todos tus descansos.", null);
  } else if (plan.status === "after") {
    const cutoffReached = plan.end === plan.limit && plan.limit < plan.shiftEnd;
    set("i-moon", cutoffReached ? "Hora límite alcanzada" : "Jornada terminada", `Hasta las ${formatTime(plan.end)}`, "No se iniciarán más descansos hoy.", null);
  } else if (plan.status === "no-slots") {
    set("i-clock", "Sin descansos programados", "Revisa el plan", `No hay descansos programados antes de las ${formatTime(plan.end)}.`, null);
  } else if (plan.status === "off") {
    set("i-cup", "Hoy", "Día libre", "Sin sugerencias ni avisos hoy. ¡Disfruta!", plan.markedOff ? "Quitar" : "Ajustes");
  } else {
    set("i-sliders", "Horario", "Sin configurar", "Revisa tu horario y tus rutinas en Ajustes.", "Ajustes");
  }
  dom.suggestionAction.onclick = () => {
    if (plan.status === "ok") registerBreak(plan.next.minutes);
    else if (plan.status === "off" && plan.markedOff) toggleDayOff(todayKey());
    else showView("settings");
  };
}

function renderChoices(plan = Core.planDay(state, mode)) {
  const progress = Core.progressFor(state, mode, todayKey());
  const timer = state.activeTimer;
  dom.choices.hidden = Boolean(timer) || plan.status === "after";
  dom.running.hidden = !timer;
  $("#today-off").hidden = Core.isRestDay(state, todayKey());
  dom.tipText.textContent = TIPS[tipIndex];
  dom.breathToggle.setAttribute("aria-pressed", String(breathing));
  dom.breathToggle.querySelector("span").textContent = breathing ? "Parar" : "Respirar";
  if (timer) return;

  dom.breakChoices.replaceChildren();
  progress.groups.forEach((group) => {
    const button = element("button", "choice");
    button.type = "button";
    button.disabled = group.remaining === 0;
    const choiceIcon = element("span", "choice-icon", state.settings.icons[mode]);
    choiceIcon.setAttribute("aria-hidden", "true");
    button.append(choiceIcon);
    const amount = element("span", "choice-amount");
    amount.append(element("strong", "", String(group.minutes)), element("span", "", "min"));
    button.append(amount, element("span", "choice-left", group.remaining ? `Quedan ${group.remaining}` : "Completado"));
    button.setAttribute("aria-label", `Empezar descanso de ${group.minutes} minutos. Quedan ${group.remaining}.`);
    button.addEventListener("click", () => registerBreak(group.minutes));
    dom.breakChoices.append(button);
  });
}

function renderPlan(plan) {
  const taken = plan.taken.map((record) => ({ time: record.startedAt, minutes: record.plannedMinutes, record }));
  const upcoming = plan.status === "ok" ? plan.items : [];
  const entries = [...taken, ...upcoming].sort((a, b) => a.time - b.time);
  dom.planCard.hidden = entries.length === 0;
  dom.planNote.textContent = upcoming.length ? `${upcoming.length} por tomar${plan.learned ? " · según tus hábitos" : ""}` : "";
  $("#plan-ics").hidden = !upcoming.length;
  dom.planList.replaceChildren();

  entries.forEach((entry) => {
    const item = element("li", "plan-item");
    const isActive = entry.record && state.activeTimer?.recordId === entry.record.id;
    const isNext = !entry.record && entry === upcoming[0];
    if (entry.record) item.classList.add(isActive ? "is-active" : "is-done");
    if (isNext) item.classList.add("is-next");
    const marker = element("span", "plan-marker");
    if (entry.record && !isActive) marker.append(icon("i-check"));
    const time = element("span", "plan-time", isNext && plan.late ? "Ahora" : formatTime(entry.time));
    const label = element("span", "plan-label", `Descanso de ${entry.minutes} min`);
    const status = element("span", "plan-status", isActive ? "En curso" : entry.record ? "Hecho" : isNext ? "Siguiente" : "Sugerido");
    item.append(marker, time, label, status);
    dom.planList.append(item);
  });
}

function renderToday() {
  renderQuote();
  const plan = Core.planDay(state, mode);
  lastPlanStatus = plan.status;
  renderSegments();
  renderHero();
  renderSuggestion(plan);
  renderChoices(plan);
  renderPlan(plan);
}

