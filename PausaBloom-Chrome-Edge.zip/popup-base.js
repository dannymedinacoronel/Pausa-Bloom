// Base de la ventana: estado, elementos de la página y utilidades de formato.
const Core = PausaCore;
const { MINUTE, MODE_NAMES } = Core;
const WEEKDAY_LETTERS = ["L", "M", "X", "J", "V", "S", "D"];
const WEEKDAY_CYCLE = { none: "long", long: "short", short: "none" };
const WEEKDAY_VALUE_LABEL = { none: "—", long: "Largo", short: "Corto" };
const RING_CIRCUMFERENCE = 2 * Math.PI * 54;
const BREATH_IN = 4;
const BREATH_OUT = 6;
const TIPS = [
  "Levántate y estira los brazos por encima de la cabeza durante 20 segundos.",
  "Mira algo que esté a más de 6 metros durante 20 segundos para descansar la vista.",
  "Bebe un vaso de agua: la hidratación también es descanso.",
  "Gira los hombros hacia atrás diez veces, despacio.",
  "Inclina la cabeza hacia cada lado y mantén la postura 15 segundos.",
  "Da un pequeño paseo, aunque sea hasta la ventana.",
  "Abre y cierra las manos y estira los dedos uno a uno.",
  "Prueba la respiración guiada: inhala 4 segundos y exhala 6.",
  "Aléjate de la pantalla: este rato es solo para ti."
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const dom = {
  body: document.body,
  views: $("#views"),
  headerDate: $("#header-date"),
  streak: $("#streak"),
  streakCount: $("#streak-count"),
  segments: $$(".segment[data-mode]"),
  scheduleLine: $("#schedule-line"),
  longIcon: $("#long-icon"),
  shortIcon: $("#short-icon"),
  hero: $("#hero"),
  quoteCard: $("#quote-card"),
  quoteText: $("#quote-text"),
  quoteAuthor: $("#quote-author"),
  ringFill: $("#ring-fill"),
  growPlant: $("#grow-plant"),
  gardenBg: $("#garden-bg"),
  ringLabel: $("#ring-label"),
  ringValue: $("#ring-value"),
  ringCaption: $("#ring-caption"),
  breath: $("#breath"),
  heroTitle: $("#hero-title"),
  heroMessage: $("#hero-message"),
  tokens: $("#tokens"),
  suggestion: $("#suggestion"),
  suggestionLabel: $("#suggestion-label"),
  suggestionTime: $("#suggestion-time"),
  suggestionDetail: $("#suggestion-detail"),
  suggestionAction: $("#suggestion-action"),
  choices: $("#choices"),
  breakChoices: $("#break-choices"),
  running: $("#running"),
  tipText: $("#tip-text"),
  breathToggle: $("#breath-toggle"),
  planCard: $("#plan-card"),
  planNote: $("#plan-note"),
  planList: $("#plan-list"),
  monthLabel: $("#month-label"),
  calendarDays: $("#calendar-days"),
  selectedDateLabel: $("#selected-date-label"),
  daySummary: $("#day-summary"),
  addRecord: $("#add-record"),
  timeline: $("#timeline"),
  timelineTrack: $("#timeline-track"),
  timelineFrom: $("#timeline-from"),
  timelineMid: $("#timeline-mid"),
  timelineTo: $("#timeline-to"),
  dayRecords: $("#day-records"),
  recordForm: $("#record-form"),
  recordFormTitle: $("#record-form-title"),
  recordMode: $("#record-mode"),
  recordMinutes: $("#record-minutes"),
  recordStart: $("#record-start"),
  recordEnd: $("#record-end"),
  recordFormMessage: $("#record-form-message"),
  toggleDayOff: $("#toggle-day-off"),
  weekTotal: $("#week-total"),
  weekChart: $("#week-chart"),
  monthStatsTitle: $("#month-stats-title"),
  garden: $("#garden"),
  gardenCaption: $("#garden-caption"),
  weekdayModes: $("#weekday-modes"),
  weekList: $("#week-list"),
  previousWeeks: $("#previous-weeks"),
  nextWeeks: $("#next-weeks"),
  hoursError: $("#hours-error"),
  routineError: $("#routine-error"),
  alertsError: $("#alerts-error"),
  openStandalone: $("#open-standalone"),
  timerEnabled: $("#timer-enabled"),
  endAlert: $("#end-alert"),
  suggestAlert: $("#suggest-alert"),
  soundSelect: $("#sound-select"),
  shortcutList: $("#shortcut-list"),
  backupFile: $("#backup-file"),
  toast: $("#toast"),
  tour: $("#tour"),
  tourSpot: $("#tour-spot"),
  tourCard: $("#tour-card"),
  tourLogo: $("#tour-logo"),
  tourStep: $("#tour-step"),
  tourTitle: $("#tour-title"),
  tourText: $("#tour-text"),
  tourDots: $("#tour-dots"),
  tourBack: $("#tour-back"),
  tourNext: $("#tour-next"),
  tourSkip: $("#tour-skip")
};

const state = {
  settings: Core.mergeSettings(),
  records: [],
  activeTimer: null,
  daysOff: [],
  returnQuote: null
};
let mode = "long";
let view = "today";
let selectedDate = Core.dateKey(new Date());
let visibleMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let editingId = null;
let breathing = false;
let breathStart = 0;
let tipIndex = Math.floor(Math.random() * TIPS.length);
let tickCount = 0;
let toastTimer = null;
let uiStateTimer = null;
let lastPlanStatus = null;
let weekOffset = 0;
let shortcuts = {};
const standalone = new URLSearchParams(location.search).get("standalone") === "1";
if (standalone) {
  document.documentElement.dataset.standalone = "true";
  document.body.dataset.standalone = "true";
  dom.openStandalone.hidden = true;
}

// ---------- Formato ----------

// Día de trabajo actual: en un turno de noche, la madrugada sigue contando como el día en que empezó.
function todayKey() {
  return Core.workDay(state.settings);
}

function capitalize(text) {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function formatTime(timestamp) {
  return new Intl.DateTimeFormat(locale(), { hour: "2-digit", minute: "2-digit" }).format(new Date(timestamp));
}

function formatDate(date, options = { weekday: "long", day: "numeric", month: "long" }) {
  return capitalize(new Intl.DateTimeFormat(locale(), options).format(date));
}

function formatClock(totalSeconds) {
  return `${String(Math.floor(totalSeconds / 60)).padStart(2, "0")}:${String(totalSeconds % 60).padStart(2, "0")}`;
}

function formatDuration(minutes) {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? `${hours} h ${rest} min` : `${hours} h`;
}

function timeInputValue(timestamp) {
  const date = new Date(timestamp);
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

function plural(count, singular, pluralWord) {
  return `${count} ${count === 1 ? singular : pluralWord}`;
}

function icon(name, className = "icon") {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", className);
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#${name}`);
  svg.append(use);
  return svg;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// Aviso flotante. Con `undo`, muestra un botón "Deshacer" durante unos segundos.
function showToast(message, undo) {
  dom.toast.replaceChildren(element("span", "", message));
  if (undo) {
    const button = element("button", "toast-action", "Deshacer");
    button.type = "button";
    button.addEventListener("click", async () => {
      dom.toast.classList.remove("is-visible");
      await undo();
      showToast("Hecho: se ha deshecho");
    });
    dom.toast.append(button);
  }
  dom.toast.classList.toggle("has-action", Boolean(undo));
  dom.toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => dom.toast.classList.remove("is-visible"), undo ? 6000 : 2600);
}

// Copia del estado para poder deshacer borrados y restablecimientos.
function snapshot() {
  return structuredClone({
    settings: state.settings,
    records: state.records,
    activeTimer: state.activeTimer,
    daysOff: state.daysOff,
    returnQuote: state.returnQuote
  });
}

async function restoreSnapshot(saved, extra = {}) {
  Object.assign(state, structuredClone(saved));
  await chrome.storage.local.set({ ...saved, ...extra });
  renderSettings();
  render();
}

// Desplaza solo el área de contenido; scrollIntoView movería también la ventana entera.
function revealInViews(target, center) {
  document.scrollingElement.scrollTop = 0;
  if (!dom.views.contains(target)) return;
  const area = dom.views.getBoundingClientRect();
  const rect = target.getBoundingClientRect();
  if (center) {
    dom.views.scrollTop += rect.top - area.top - Math.max(0, (area.height - rect.height) / 2);
  } else if (rect.bottom > area.bottom) {
    dom.views.scrollTop += rect.bottom - area.bottom + 12;
  }
}

function actualMinutes(record) {
  if (record.completedAt) return (record.completedAt - record.startedAt) / MINUTE;
  if (state.activeTimer?.recordId === record.id) return (Date.now() - record.startedAt) / MINUTE;
  return record.plannedMinutes;
}

