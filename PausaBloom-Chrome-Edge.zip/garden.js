// Jardín que evoluciona hasta bosque: cada día completo planta una flor que madura con el tiempo.
//   0–6 días: flor · 7–29: arbusto · 30–89: árbol joven · 90+: árbol grande.
// Las plantas se colocan a los lados (x 0–110 y 270–380 en un lienzo de 380×110) para dejar libre el centro.
(function (global) {
  const SPECIES = ["tulip", "daisy", "lavender", "sunflower", "poppy"];
  const SPECIES_NAMES = { tulip: "tulipán", daisy: "margarita", lavender: "lavanda", sunflower: "girasol", poppy: "amapola" };
  const STAGE_ORDER = { tree: 0, young: 1, bush: 2, flower: 3, sprout: 4 };
  const LIMITS = { tree: 10, young: 10, bush: 14, flower: 20, sprout: 8 };
  const DAY = 86_400_000;

  function seeded(key, salt) {
    let hash = 2166136261;
    for (const char of `${key}${salt}`) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return ((hash >>> 0) % 10000) / 10000;
  }

  function dateFromKey(key) {
    const [year, month, day] = key.split("-").map(Number);
    return new Date(year, month - 1, day);
  }

  function daysBetween(fromKey, toKey) {
    return Math.round((dateFromKey(toKey) - dateFromKey(fromKey)) / DAY);
  }

  function seasonOf(key) {
    const month = dateFromKey(key).getMonth();
    if (month === 11 || month <= 1) return "winter";
    if (month <= 4) return "spring";
    if (month <= 7) return "summer";
    return "autumn";
  }

  function speciesOf(day) {
    return SPECIES[Math.floor(seeded(day, "species") * SPECIES.length)];
  }

  function stageOf(age) {
    if (age < 7) return "flower";
    if (age < 30) return "bush";
    if (age < 90) return "young";
    return "tree";
  }

  // Altura aproximada del montículo a `offset` píxeles del borde.
  function moundSurface(offset) {
    return 82 + Math.pow((offset - 58) / 50, 2) * 9;
  }

  // entries: [{ day: "2026-11-02", complete: true|false }] — un elemento por día con descansos.
  function describe(entries, today) {
    const sorted = [...entries].filter((entry) => entry.day <= today).sort((a, b) => (a.day < b.day ? 1 : -1));
    const complete = sorted.filter((entry) => entry.complete);
    const all = [];
    for (const entry of sorted) {
      const age = daysBetween(entry.day, today);
      const stage = entry.complete ? stageOf(age) : age < 14 ? "sprout" : null;
      if (stage) all.push({ day: entry.day, stage, age, species: speciesOf(entry.day) });
    }
    const counts = { tree: 0, young: 0, bush: 0, flower: 0, sprout: 0 };
    all.forEach((plant) => { counts[plant.stage] += 1; });

    // Lo más reciente de cada tipo se ve; los árboles que no caben forman el bosque lejano.
    const shown = { tree: 0, young: 0, bush: 0, flower: 0, sprout: 0 };
    const visible = all.filter((plant) => {
      if (shown[plant.stage] >= LIMITS[plant.stage]) return false;
      shown[plant.stage] += 1;
      return true;
    });
    return {
      visible,
      counts,
      completeDays: complete.length,
      farTrees: Math.max(0, counts.tree - LIMITS.tree) + Math.max(0, counts.young - LIMITS.young),
      season: seasonOf(today),
      oldestTreeDay: complete.length ? complete[complete.length - 1].day : null
    };
  }

  const f = (value) => value.toFixed(1);

  function flowerShape(x, top, species, scale) {
    const r = 2.6 * scale;
    let head = "";
    if (species === "tulip") {
      head = `<path class="gs-tulip" d="M${f(x - r)} ${f(top - r * 0.4)}q0 ${f(r * 1.8)} ${f(r)} ${f(r * 1.8)}q${f(r)} 0 ${f(r)} ${f(-r * 1.8)}l${f(-r * 0.5)} ${f(r * 0.7)}l${f(-r * 0.5)} ${f(-r * 1.1)}l${f(-r * 0.5)} ${f(r * 1.1)}z"/>`;
    } else if (species === "lavender") {
      for (let i = 0; i < 4; i += 1) head += `<ellipse class="gs-lavender" cx="${f(x)}" cy="${f(top + i * r * 0.9)}" rx="${f(r * 0.55)}" ry="${f(r * 0.6)}"/>`;
    } else {
      const petals = species === "poppy" ? 4 : species === "sunflower" ? 8 : 6;
      const petalClass = { daisy: "gs-daisy", sunflower: "gs-sunflower", poppy: "gs-poppy" }[species];
      for (let i = 0; i < petals; i += 1) {
        const angle = (i / petals) * Math.PI * 2;
        const distance = r * (species === "poppy" ? 0.7 : 1.05);
        const size = species === "poppy" ? r * 0.95 : r * 0.62;
        head += `<circle class="${petalClass}" cx="${f(x + Math.cos(angle) * distance)}" cy="${f(top + Math.sin(angle) * distance)}" r="${f(size)}"/>`;
      }
      head += `<circle class="gs-center-${species}" cx="${f(x)}" cy="${f(top)}" r="${f(r * (species === "sunflower" ? 0.75 : 0.55))}"/>`;
    }
    return head;
  }

  function plantShape(plant, options) {
    const { day, stage, species } = plant;
    const offset = 12 + seeded(day, "x") * (stage === "tree" || stage === "young" ? 84 : 92);
    const x = seeded(day, "side") < 0.5 ? offset : 380 - offset;
    const ground = moundSurface(offset) + 3 + seeded(day, "y") * 12;
    const depth = 0.8 + ((ground - 85) / 20) * 0.4;
    const isNew = plant.age === 0 && options.animateNew;
    let shape = `<g class="gs-plant gs-${stage}${isNew ? " is-new" : ""}" style="transform-origin:${f(x)}px ${f(ground)}px">`;

    if (stage === "sprout") {
      const h = (6 + seeded(day, "h") * 3) * depth;
      shape += `<path class="gs-stem" d="M${f(x)} ${f(ground)}v${f(-h)}"/>`;
      shape += `<path class="gs-leaf" d="M${f(x)} ${f(ground - h)}q${f(4 * depth)} -1 ${f(5 * depth)} ${f(-4 * depth)}q${f(-4 * depth)} 0 ${f(-5 * depth)} ${f(4 * depth)}z"/>`;
      shape += `<path class="gs-leaf" d="M${f(x)} ${f(ground - h * 0.5)}q${f(-4 * depth)} -1 ${f(-5 * depth)} ${f(-4 * depth)}q${f(4 * depth)} 0 ${f(5 * depth)} ${f(4 * depth)}z"/>`;
    } else if (stage === "flower") {
      const h = (15 + seeded(day, "h") * 12) * depth;
      const top = ground - h;
      shape += `<path class="gs-stem" d="M${f(x)} ${f(ground)}Q${f(x + 2)} ${f(ground - h / 2)} ${f(x)} ${f(top)}"/>`;
      shape += `<path class="gs-leaf" d="M${f(x)} ${f(ground - h * 0.4)}q${f(-5 * depth)} -1 ${f(-6 * depth)} ${f(-5 * depth)}q${f(5 * depth)} 0 ${f(6 * depth)} ${f(5 * depth)}z"/>`;
      shape += flowerShape(x, top, species, depth);
    } else if (stage === "bush") {
      const r = (5 + seeded(day, "h") * 3) * depth;
      shape += `<circle class="gs-bush" cx="${f(x - r * 0.7)}" cy="${f(ground - r * 0.7)}" r="${f(r * 0.8)}"/>`;
      shape += `<circle class="gs-bush gs-bush-light" cx="${f(x + r * 0.6)}" cy="${f(ground - r * 0.75)}" r="${f(r * 0.85)}"/>`;
      shape += `<circle class="gs-bush" cx="${f(x)}" cy="${f(ground - r * 1.15)}" r="${f(r)}"/>`;
      // Algunos arbustos conservan flores de su especie.
      if (seeded(day, "bloom") > 0.45) shape += flowerShape(x + r * 0.3, ground - r * 1.5, species, depth * 0.7);
    } else {
      const big = stage === "tree";
      const pine = seeded(day, "pine") < 0.3;
      const trunk = (big ? 18 + seeded(day, "h") * 8 : 10 + seeded(day, "h") * 5) * depth;
      const crown = (big ? 11 + seeded(day, "c") * 3 : 7 + seeded(day, "c") * 2) * depth;
      const tone = seeded(day, "tone") < 0.5 ? "gs-crown" : "gs-crown gs-crown-alt";
      const blossom = options.blossomDay === day ? " is-blossom" : "";
      shape += `<rect class="gs-trunk" x="${f(x - (big ? 1.6 : 1.1) * depth)}" y="${f(ground - trunk)}" width="${f((big ? 3.2 : 2.2) * depth)}" height="${f(trunk)}" rx="1"/>`;
      if (pine) {
        const top = ground - trunk - crown * 2.2;
        shape += `<path class="${tone} gs-pine${blossom}" d="M${f(x)} ${f(top)}L${f(x + crown)} ${f(ground - trunk * 0.55)}H${f(x - crown)}Z"/>`;
        shape += `<path class="gs-snow" d="M${f(x)} ${f(top)}l${f(crown * 0.35)} ${f(crown * 0.75)}q${f(-crown * 0.35)} ${f(-crown * 0.2)} ${f(-crown * 0.7)} 0z"/>`;
      } else {
        const cy = ground - trunk - crown * 0.55;
        shape += `<circle class="${tone}${blossom}" cx="${f(x - crown * 0.55)}" cy="${f(cy + crown * 0.25)}" r="${f(crown * 0.7)}"/>`;
        shape += `<circle class="${tone}${blossom}" cx="${f(x + crown * 0.55)}" cy="${f(cy + crown * 0.2)}" r="${f(crown * 0.72)}"/>`;
        shape += `<circle class="${tone}${blossom}" cx="${f(x)}" cy="${f(cy - crown * 0.3)}" r="${f(crown * 0.85)}"/>`;
        shape += `<ellipse class="gs-snow" cx="${f(x)}" cy="${f(cy - crown * 0.95)}" rx="${f(crown * 0.6)}" ry="${f(crown * 0.22)}"/>`;
        // Flores de primavera (o del árbol en flor de los 30 días) sobre la copa.
        for (let i = 0; i < 5; i += 1) {
          const angle = seeded(day, `b${i}`) * Math.PI * 2;
          const distance = seeded(day, `d${i}`) * crown * 0.8;
          shape += `<circle class="gs-blossom${blossom}" cx="${f(x + Math.cos(angle) * distance)}" cy="${f(cy - crown * 0.1 + Math.sin(angle) * distance * 0.7)}" r="${f(1.1 * depth)}"/>`;
        }
      }
    }
    return `${shape}</g>`;
  }

  function goldenTree() {
    const x = 58;
    const ground = moundSurface(58) + 4;
    return `<g class="gs-plant gs-golden"><rect class="gs-trunk" x="${x - 2}" y="${f(ground - 30)}" width="4" height="30" rx="1.5"/>`
      + `<circle class="gs-gold" cx="${x - 9}" cy="${f(ground - 33)}" r="10"/><circle class="gs-gold" cx="${x + 9}" cy="${f(ground - 34)}" r="10.5"/>`
      + `<circle class="gs-gold gs-gold-light" cx="${x}" cy="${f(ground - 44)}" r="12"/></g>`;
  }

  function farForest(count) {
    // Siluetas lejanas: cuantos más árboles antiguos, más denso el bosque del fondo.
    let shapes = "";
    const total = Math.min(18, count);
    for (let i = 0; i < total; i += 1) {
      const offset = 6 + (i / Math.max(1, total - 1)) * 100;
      const x = i % 2 ? offset : 380 - offset;
      const height = 16 + seeded(`far${i}`, "h") * 14;
      const base = moundSurface(offset) - 2;
      shapes += `<path class="gs-far" d="M${f(x)} ${f(base - height)}L${f(x + 6)} ${f(base)}H${f(x - 6)}Z"/>`;
    }
    return shapes;
  }

  function butterflies() {
    return '<g class="gs-butterfly" style="--fly-x: 14px"><ellipse cx="34" cy="48" rx="2.6" ry="1.8"/><ellipse cx="38" cy="48" rx="2.6" ry="1.8"/></g>'
      + '<g class="gs-butterfly gs-butterfly-2" style="--fly-x: -12px"><ellipse cx="338" cy="40" rx="2.4" ry="1.6"/><ellipse cx="342" cy="40" rx="2.4" ry="1.6"/></g>';
  }

  // Dibuja el jardín dentro de un <svg viewBox="0 0 380 110">.
  function render(svg, entries, today, options = {}) {
    const info = describe(entries, today);
    const blossomDay = info.completeDays >= 30
      ? info.visible.filter((plant) => plant.stage === "tree" || plant.stage === "young").map((plant) => plant.day).sort()[0]
      : null;
    const parts = [
      '<defs><linearGradient id="gs-ground" x1="0" y1="0" x2="0" y2="1"><stop offset="0" class="gs-ground-top"/><stop offset="1" class="gs-ground-bottom"/></linearGradient></defs>',
      farForest(info.farTrees),
      '<path class="gs-mound" d="M-24 110C8 74 104 70 140 110Z"/>',
      '<path class="gs-mound" d="M404 110C372 74 276 70 240 110Z"/>'
    ];
    for (let blade = 0; blade < 14; blade += 1) {
      const offset = 6 + blade * 7.5 + seeded(`blade${blade}`, "x") * 4;
      const base = moundSurface(offset) + 1;
      const lean = (seeded(`blade${blade}`, "l") - 0.5) * 3;
      const height = 3 + seeded(`blade${blade}`, "h") * 3;
      for (const x of [offset, 380 - offset]) parts.push(`<path class="gs-blade" d="M${f(x)} ${f(base)}q${f(lean)} ${f(-height / 2)} ${f(lean * 1.6)} ${f(-height)}"/>`);
    }
    if (info.completeDays >= 100) parts.push(goldenTree());
    const ordered = [...info.visible].sort((a, b) => STAGE_ORDER[a.stage] - STAGE_ORDER[b.stage] || seeded(a.day, "y") - seeded(b.day, "y"));
    ordered.forEach((plant) => parts.push(plantShape(plant, { blossomDay, animateNew: options.animateNew })));
    if (info.completeDays >= 10) parts.push(butterflies());
    svg.innerHTML = parts.join("");
    svg.setAttribute("class", `garden-scene season-${info.season}`);
    return info;
  }

  global.PausaGarden = { render, describe, speciesOf, seasonOf, SPECIES_NAMES };
})(globalThis);
