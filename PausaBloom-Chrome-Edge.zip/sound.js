// Sonidos sintetizados con Web Audio: no hace falta ningún archivo de audio.
(function (global) {
  const PATTERNS = {
    bell: [
      { type: "sine", freq: 880, at: 0, dur: 1.6, vol: 0.22 },
      { type: "sine", freq: 1320, at: 0, dur: 1.1, vol: 0.06 },
      { type: "sine", freq: 659.25, at: 0.38, dur: 1.9, vol: 0.18 }
    ],
    soft: [
      { type: "triangle", freq: 523.25, at: 0, dur: 0.9, vol: 0.16 },
      { type: "triangle", freq: 659.25, at: 0.22, dur: 0.9, vol: 0.16 },
      { type: "triangle", freq: 783.99, at: 0.44, dur: 1.5, vol: 0.16 }
    ],
    drop: [
      { type: "sine", freq: 1150, to: 480, at: 0, dur: 0.24, vol: 0.22 },
      { type: "sine", freq: 980, to: 420, at: 0.3, dur: 0.3, vol: 0.18 }
    ]
  };

  const OPTIONS = [
    { value: "bell", label: "Campana" },
    { value: "soft", label: "Acorde suave" },
    { value: "drop", label: "Gota" },
    { value: "none", label: "Sin sonido" }
  ];

  function play(name) {
    const notes = PATTERNS[name];
    const AudioContextClass = global.AudioContext || global.webkitAudioContext;
    if (!notes || !AudioContextClass) return;
    const context = new AudioContextClass();
    const now = context.currentTime;
    for (const note of notes) {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const start = now + note.at;
      oscillator.type = note.type;
      oscillator.frequency.setValueAtTime(note.freq, start);
      if (note.to) oscillator.frequency.exponentialRampToValueAtTime(note.to, start + note.dur);
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(note.vol, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + note.dur);
      oscillator.connect(gain).connect(context.destination);
      oscillator.start(start);
      oscillator.stop(start + note.dur + 0.05);
    }
    setTimeout(() => context.close(), 3000);
  }

  global.PausaSound = { play, OPTIONS };
})(globalThis);
